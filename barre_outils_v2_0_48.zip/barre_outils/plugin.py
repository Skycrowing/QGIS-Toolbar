import importlib
import os
import traceback

from qgis.PyQt.QtCore import QTimer
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMenu, QToolBar
from qgis.core import Qgis, QgsMessageLog

HERE = os.path.dirname(__file__)
TITLE = "Barre d'outils"

# Ordre des boutons dans la barre : (sous-dossier dans outils/, nom affiché)
TOOLS = [
    ("geometry_parser", "Geometry_Parser"),
    ("recherche_adresse", "Recherche Adresse"),
    ("icar_geocoder", "ICAR Géocodeur"),
    ("recherche_resa", "Recherche objet"),
    ("floating_info_tool", "Floating Info Tool"),
    ("arrondir_champs", "Arrondir Champs"),
    ("rename_layers_groups", "Rename Layers & Groups"),
    ("spatial_index_manager", "Spatial Index Manager"),
    ("osm_tracer", "OSM Tracer"),
    ("network_tracer", "Network Tracer"),
    ("toujours_affiche", "Toujours affiché"),
    ("detecteur_doublons", "Détecteur de doublons"),
    ("compteur_entites", "Compteur d'entités"),
]

# Version QGIS minimale propre à certains outils (sinon celle de la barre)
MIN_QGIS = {"osm_tracer": 32800, "network_tracer": 32800}

_MSG = getattr(Qgis, "MessageLevel", Qgis)


class _ToolIface:
    """Interface QGIS vue par un outil : ses boutons et menus sont redirigés
    vers la barre et le menu communs ; tout le reste passe à la vraie iface."""

    def __init__(self, iface, host, key, title):
        self._iface = iface
        self._host = host
        self._key = key
        self._title = title

    def __getattr__(self, name):
        return getattr(self._iface, name)

    def addToolBarIcon(self, action):
        self._host.toolbar.addAction(action)
        return 0

    def removeToolBarIcon(self, action):
        if self._host.toolbar is not None:
            self._host.toolbar.removeAction(action)

    def addPluginToMenu(self, _name, action):
        self._host.submenu(self._key, self._title).addAction(action)

    def removePluginMenu(self, _name, action):
        menu = self._host.submenus.get(self._key)
        if menu is not None:
            menu.removeAction(action)

    addPluginToVectorMenu = addPluginToMenu
    removePluginVectorMenu = removePluginMenu
    addPluginToRasterMenu = addPluginToMenu
    removePluginRasterMenu = removePluginMenu
    addPluginToDatabaseMenu = addPluginToMenu
    removePluginDatabaseMenu = removePluginMenu
    addPluginToWebMenu = addPluginToMenu
    removePluginWebMenu = removePluginMenu


class BarreOutilsPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.toolbar = None
        self.menu = None
        self.submenus = {}
        self.tools = []          # (clé, instance)

    # --- cycle de vie ---------------------------------------------------
    def initGui(self):
        win = self.iface.mainWindow()
        self.toolbar = QToolBar(TITLE, win)
        self.toolbar.setObjectName("BarreOutilsExtensions")
        self.iface.addToolBar(self.toolbar)

        self.menu = QMenu(TITLE, win)
        self.menu.setIcon(QIcon(os.path.join(HERE, "icon.png")))
        self.iface.pluginMenu().addMenu(self.menu)

        failed = []
        skipped = []
        for key, title in TOOLS:
            if Qgis.QGIS_VERSION_INT < MIN_QGIS.get(key, 0):
                skipped.append(title)
                continue
            try:
                module = importlib.import_module(f"{__package__}.outils.{key}")
                tool = module.classFactory(_ToolIface(self.iface, self, key, title))
                tool.initGui()
                self.tools.append((key, tool))
            except Exception:
                failed.append(title)
                QgsMessageLog.logMessage(f"{title} :\n{traceback.format_exc()}", TITLE, _MSG.Critical)

        if failed:
            self.iface.messageBar().pushWarning(
                TITLE, f"Non chargé : {', '.join(failed)} (détails dans le journal des messages)."
            )
        if skipped:
            QgsMessageLog.logMessage(
                f"Non disponible avec cette version de QGIS : {', '.join(skipped)}.", TITLE, _MSG.Info)
        # après le chargement des autres extensions
        QTimer.singleShot(0, self._warn_duplicates)

    def unload(self):
        for key, tool in reversed(self.tools):
            try:
                tool.unload()
            except Exception:
                QgsMessageLog.logMessage(f"{key} :\n{traceback.format_exc()}", TITLE, _MSG.Warning)
        self.tools = []
        if self.menu is not None:
            self.iface.pluginMenu().removeAction(self.menu.menuAction())
            self.menu.deleteLater()
            self.menu = None
        self.submenus = {}
        if self.toolbar is not None:
            self.iface.mainWindow().removeToolBar(self.toolbar)
            self.toolbar.deleteLater()
            self.toolbar = None

    # --- utilitaires ------------------------------------------------------
    def submenu(self, key, title):
        menu = self.submenus.get(key)
        if menu is None:
            menu = self.menu.addMenu(title)
            self.submenus[key] = menu
        return menu

    def _warn_duplicates(self):
        if self.toolbar is None:
            return
        from qgis import utils
        active = [title for key, title in TOOLS if key in utils.plugins]
        if active:
            self.iface.messageBar().pushWarning(
                TITLE,
                "Déjà inclus dans la Barre d'outils, à désactiver dans le gestionnaire "
                f"d'extensions : {', '.join(active)}.",
            )
