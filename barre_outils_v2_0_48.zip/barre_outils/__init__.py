def classFactory(iface):
    from .plugin import BarreOutilsPlugin
    return BarreOutilsPlugin(iface)
