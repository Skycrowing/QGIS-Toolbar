"""
Plugin QGIS "Recherche objet"
Point d'entrée standard requis par QGIS.
"""


def classFactory(iface):
    from .recherche_resa import RechercheResaPlugin
    return RechercheResaPlugin(iface)
