from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtGui import QPixmap, QColor
from qgis.PyQt.QtWidgets import (
    QApplication,
    QDockWidget,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QComboBox,
    QCheckBox,
    QListWidget,
    QLineEdit,
    QPushButton,
    QPlainTextEdit,
    QProgressBar,
    QSplitter,
)
from qgis.core import (
    QgsProject,
    QgsMapLayer,
    QgsFeatureRequest,
    QgsExpression,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsRectangle,
)
from qgis.core import Qgis

try:
    _NO_GEOMETRY = Qgis.FeatureRequestFlag.NoGeometry
except AttributeError:  # QGIS < 3.36
    _NO_GEOMETRY = QgsFeatureRequest.NoGeometry


def _is_vector(lyr):
    try:
        return lyr.type() == Qgis.LayerType.Vector
    except AttributeError:  # QGIS < 3.30
        return lyr.type() == QgsMapLayer.VectorLayer
from qgis.gui import QgsHighlight, QgsCheckableComboBox

# Systèmes de coordonnées belges
LAMBERT72_AUTHID = "EPSG:31370"    # Lambert belge 72 (ancien système)
LAMBERT2008_AUTHID = "EPSG:3812"   # Lambert belge 2008 (système officiel actuel)


class RechercheResaDialog(QDockWidget):
    """Panneau ancrable (dock widget) générique : choix d'une couche
    vectorielle du projet et d'un champ quelconque, affichage des valeurs
    uniques de ce champ, filtre optionnel sur un second champ,
    sélection/zoom sur la carte.

    Étant un QDockWidget, ce panneau peut être ancré par l'utilisateur sur
    le côté droit (ou gauche/bas) de la fenêtre QGIS, comme les panneaux
    natifs (Couches, Navigateur...), simplement en le faisant glisser."""

    # Répartition initiale : liste / champs à afficher / bas du panneau.
    # Les deux fenêtres occupent 37,5 % (= ancienne taille réduite de 25 %).
    SPLIT_RATIO = (6, 3, 15)

    def __init__(self, iface, parent=None):
        super().__init__("Recherche objet", parent)
        self.setObjectName("RechercheResaDockWidget")
        self.iface = iface
        self.highlights = []  # références aux surbrillances actives (QgsHighlight)
        self.all_values = []  # toutes les valeurs uniques calculées (avant filtre texte)

        # Le contenu du panneau doit être un widget distinct, posé via
        # setWidget() : un QDockWidget ne prend pas de layout directement.
        content = QWidget(self)

        self.layer_combo = QComboBox(content)
        self.visible_only_checkbox = QCheckBox(
            "Ne montrer que les couches visibles", content
        )
        self.visible_only_checkbox.setChecked(True)  # coché par défaut
        self.field_combo = QComboBox(content)
        self.filter_field_combo = QComboBox(content)
        self.filter_value_combo = QComboBox(content)
        self.list_widget = QListWidget(content)
        self.info_field_combo = QgsCheckableComboBox(content)
        self.info_field_combo.setDefaultText("(aucun)")

        refresh_btn = QPushButton("Actualiser", content)
        zoom_btn = QPushButton("Zoomer / sélectionner", content)
        reset_btn = QPushButton("Réinitialiser la mise en évidence", content)

        layout = QVBoxLayout(content)

        layout.addWidget(QLabel("Couche :"))
        layout.addWidget(self.layer_combo)
        layout.addWidget(self.visible_only_checkbox)

        layout.addWidget(QLabel("Champ à lister :"))
        layout.addWidget(self.field_combo)

        filter_row = QHBoxLayout()
        filter_col1 = QVBoxLayout()
        filter_col1.addWidget(QLabel("Filtrer par champ (optionnel) :"))
        filter_col1.addWidget(self.filter_field_combo)
        filter_col2 = QVBoxLayout()
        filter_col2.addWidget(QLabel("Valeur :"))
        filter_col2.addWidget(self.filter_value_combo)
        filter_row.addLayout(filter_col1)
        filter_row.addLayout(filter_col2)
        layout.addLayout(filter_row)

        layout.addWidget(QLabel("Champs à afficher (valeurs liées à l'entité sélectionnée) :"))
        layout.addWidget(self.info_field_combo)

        layout.addWidget(QLabel("Valeurs uniques :"))

        self.search_edit = QLineEdit(content)
        self.search_edit.setPlaceholderText("Rechercher dans les résultats...")
        layout.addWidget(self.search_edit)

        self.count_label = QLabel(content)
        layout.addWidget(self.count_label)

        # Fenêtre des champs à afficher, sous les résultats (lecture seule, sélectionnable/copiable)
        self.info_value_label = QPlainTextEdit(content)
        self.info_value_label.setReadOnly(True)
        self.info_value_label.setStyleSheet("font-weight: bold;")
        self.info_value_label.setMinimumHeight(40)

        # Bas du panneau : progression, boutons, message ; l'espace libre
        # restant se place sous les boutons.
        bottom = QWidget(content)
        bottom_layout = QVBoxLayout(bottom)
        bottom_layout.setContentsMargins(0, 0, 0, 0)

        self.progress_bar = QProgressBar(bottom)
        self.progress_bar.setVisible(False)
        self.progress_bar.setTextVisible(True)
        bottom_layout.addWidget(self.progress_bar)

        btn_row = QHBoxLayout()
        btn_row.addWidget(refresh_btn)
        btn_row.addWidget(zoom_btn)
        bottom_layout.addLayout(btn_row)

        btn_row2 = QHBoxLayout()
        btn_row2.addWidget(reset_btn)
        bottom_layout.addLayout(btn_row2)

        self.status_label = QLabel(bottom)
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet("color: #b35300;")  # ton orange RESA
        bottom_layout.addWidget(self.status_label)
        bottom_layout.addStretch(1)
        bottom.setMinimumHeight(bottom_layout.sizeHint().height())

        # Séparateur vertical : les poignées entre les zones permettent
        # d'ajuster manuellement la hauteur des deux fenêtres de résultat.
        self.splitter = QSplitter(Qt.Orientation.Vertical, content)
        self.list_widget.setMinimumHeight(60)
        self.splitter.addWidget(self.list_widget)
        self.splitter.addWidget(self.info_value_label)
        self.splitter.addWidget(bottom)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(6)
        for i, f in enumerate(self.SPLIT_RATIO):
            self.splitter.setStretchFactor(i, f)
        self._splitter_initialized = False
        layout.addWidget(self.splitter, 1)

        self.layer_combo.currentIndexChanged.connect(self.on_layer_changed)
        self.visible_only_checkbox.toggled.connect(lambda checked: self.refresh_layers())
        self.field_combo.currentIndexChanged.connect(self.populate_values)
        self.filter_field_combo.currentIndexChanged.connect(self.on_filter_field_changed)
        self.filter_value_combo.currentIndexChanged.connect(self.populate_values)
        self.search_edit.textChanged.connect(self.apply_text_filter)
        self.info_field_combo.checkedItemsChanged.connect(lambda _items: self.update_info_label())
        refresh_btn.clicked.connect(self.refresh_layers)
        zoom_btn.clicked.connect(self.zoom_to_selected)
        reset_btn.clicked.connect(self.reset_highlight)
        # Zoom à chaque clic sur un résultat (y compris un re-clic sur le
        # résultat déjà actif) et à la navigation clavier ; le minuteur
        # regroupe les deux signaux pour ne zoomer qu'une fois.
        self._zoom_timer = QTimer(self)
        self._zoom_timer.setSingleShot(True)
        self._zoom_timer.setInterval(0)
        self._zoom_timer.timeout.connect(self.zoom_to_selected)
        self.list_widget.itemClicked.connect(lambda _item: self._zoom_timer.start())
        self.list_widget.itemSelectionChanged.connect(self._zoom_timer.start)
        self.list_widget.itemSelectionChanged.connect(self.update_info_label)

        self.setWidget(content)

        # Le panneau peut être ancré à gauche ou à droite de la fenêtre
        # QGIS, ou laissé flottant si l'utilisateur le préfère.
        self.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)
        self.setFeatures(
            QDockWidget.DockWidgetClosable
            | QDockWidget.DockWidgetMovable
            | QDockWidget.DockWidgetFloatable
        )

        self.refresh_layers()

    def showEvent(self, event):
        super().showEvent(event)
        if not self._splitter_initialized:
            self._splitter_initialized = True
            QTimer.singleShot(0, self._apply_split_ratio)

    def _apply_split_ratio(self):
        total = sum(self.splitter.sizes())
        if total <= 0:
            return
        r = sum(self.SPLIT_RATIO)
        self.splitter.setSizes([total * f // r for f in self.SPLIT_RATIO])

    def closeEvent(self, event):
        self._clear_highlights()
        super().closeEvent(event)

    # ------------------------------------------------------------------
    # Barre de progression / verrouillage de l'interface
    # ------------------------------------------------------------------

    def _set_busy(self, busy, total=0):
        """Affiche/masque la barre de progression et verrouille les
        contrôles pendant un chargement potentiellement long."""
        self.progress_bar.setVisible(busy)
        if busy:
            self.progress_bar.setRange(0, total if total > 0 else 0)  # 0 => mode indéterminé
            self.progress_bar.setValue(0)
        for w in (
            self.layer_combo,
            self.field_combo,
            self.filter_field_combo,
            self.filter_value_combo,
            self.list_widget,
            self.info_field_combo,
        ):
            w.setEnabled(not busy)

    def _update_progress(self, value):
        self.progress_bar.setValue(value)
        # Garde l'interface réactive pendant les traitements longs
        QApplication.processEvents()

    # ------------------------------------------------------------------
    # Population des combos
    # ------------------------------------------------------------------

    def _is_layer_visible(self, layer):
        """Indique si la couche est actuellement visible (case cochée)
        dans le panneau des couches de QGIS, en tenant compte des groupes
        parents éventuellement décochés."""
        node = QgsProject.instance().layerTreeRoot().findLayer(layer.id())
        if node is None:
            return True  # par sécurité, on ne cache pas une couche sans nœud trouvé
        return node.isVisible()

    def refresh_layers(self):
        """Recharge la liste des couches vectorielles présentes dans le
        projet. Aucune couche ni aucun champ n'est privilégié : l'utilisateur
        choisit librement, ce qui rend le plugin utilisable avec n'importe
        quelle donnée (communes, clients RESA, postes, compteurs, etc.).
        Si la case 'Ne montrer que les couches visibles' est cochée, seules
        les couches actuellement cochées dans le panneau des couches sont
        proposées. Au tout premier démarrage (ou si la couche précédemment
        choisie n'est plus disponible), aucune couche n'est présélectionnée :
        le panneau reste vide tant que l'utilisateur n'a rien choisi."""
        current_layer_id = self.layer_combo.currentData()

        self.layer_combo.blockSignals(True)
        self.layer_combo.clear()
        self.layer_combo.addItem("-- Sélectionner une couche --", None)

        all_vector_layers = [
            lyr
            for lyr in QgsProject.instance().mapLayers().values()
            if _is_vector(lyr)
        ]

        if self.visible_only_checkbox.isChecked():
            self.vector_layers = [
                lyr for lyr in all_vector_layers if self._is_layer_visible(lyr)
            ]
        else:
            self.vector_layers = all_vector_layers

        restore_index = 0  # placeholder par défaut : rien de sélectionné
        for i, lyr in enumerate(self.vector_layers):
            self.layer_combo.addItem(lyr.name(), lyr.id())
            if current_layer_id and lyr.id() == current_layer_id:
                restore_index = i + 1  # +1 car le placeholder occupe l'index 0

        self.layer_combo.setCurrentIndex(restore_index)
        self.layer_combo.blockSignals(False)

        self.on_layer_changed()

    def current_layer(self):
        layer_id = self.layer_combo.currentData()
        if not layer_id:
            return None
        return QgsProject.instance().mapLayer(layer_id)

    def on_layer_changed(self):
        self._clear_highlights()
        layer = self.current_layer()

        self.field_combo.blockSignals(True)
        self.filter_field_combo.blockSignals(True)
        self.info_field_combo.blockSignals(True)

        self.field_combo.clear()
        self.filter_field_combo.clear()
        self.filter_field_combo.addItem("(aucun)", None)
        self.info_field_combo.clear()

        if layer is not None:
            self.field_combo.addItem("-- Sélectionner un champ --", None)
            names = [f.name() for f in layer.fields()]
            self.field_combo.addItems(names)
            self.filter_field_combo.addItems(names)
            self.info_field_combo.addItems(names)

        self.field_combo.blockSignals(False)
        self.filter_field_combo.blockSignals(False)
        self.info_field_combo.blockSignals(False)

        self.info_value_label.setPlainText("")
        self.status_label.setText("")
        self.list_widget.clear()
        self.all_values = []
        self.count_label.setText("")

        self.on_filter_field_changed()

    def on_filter_field_changed(self):
        layer = self.current_layer()
        self.filter_value_combo.blockSignals(True)
        self.filter_value_combo.clear()
        self.filter_value_combo.addItem("(toutes)", None)

        filter_field = self.filter_field_combo.currentText()
        if layer is not None and filter_field and self.filter_field_combo.currentIndex() > 0:
            idx = layer.fields().indexOf(filter_field)
            if idx != -1:
                values = self._collect_unique_values(layer, idx)
                for v in values:
                    self.filter_value_combo.addItem(str(v), v)

        self.filter_value_combo.blockSignals(False)
        self.populate_values()

    # ------------------------------------------------------------------
    # Calcul de la liste de valeurs (avec barre de progression)
    # ------------------------------------------------------------------

    def _collect_unique_values(self, layer, field_idx, request=None):
        """Parcourt les entités de la couche pour extraire les valeurs
        uniques du champ demandé, en affichant une barre de progression.
        Utile quand la couche compte beaucoup d'entités/attributs."""
        total = layer.featureCount()

        req = QgsFeatureRequest(request) if request is not None else QgsFeatureRequest()
        req.setSubsetOfAttributes([field_idx])
        req.setFlags(_NO_GEOMETRY)

        self._set_busy(True, total=total)

        values = set()
        step = max(1, total // 100) if total else 1  # limite les rafraîchissements UI
        try:
            for i, feat in enumerate(layer.getFeatures(req)):
                values.add(feat[field_idx])
                if i % step == 0:
                    self._update_progress(min(i, total) if total else 0)
        finally:
            self._set_busy(False)

        return sorted((v for v in values if v not in (None, "")), key=str)

    def populate_values(self):
        self.list_widget.clear()
        self.all_values = []
        layer = self.current_layer()
        field_name = self.field_combo.currentText()

        if layer is None or not field_name or self.field_combo.currentIndex() <= 0:
            self.count_label.setText("")
            return

        field_idx = layer.fields().indexOf(field_name)
        if field_idx == -1:
            self.count_label.setText("")
            return

        filter_field = self.filter_field_combo.currentText()
        filter_value = self.filter_value_combo.currentData()

        request = None
        if self.filter_field_combo.currentIndex() > 0 and filter_value is not None:
            expr = QgsExpression(
                f'"{filter_field}" = {QgsExpression.quotedValue(filter_value)}'
            )
            request = QgsFeatureRequest(expr)

        values = self._collect_unique_values(layer, field_idx, request)
        self.all_values = [str(v) for v in values]
        self.apply_text_filter()

    def apply_text_filter(self):
        """Filtre la liste affichée selon le texte saisi (recherche
        insensible à la casse sur une partie du nom) et met à jour le
        compteur de résultats."""
        text = self.search_edit.text().strip().lower()

        if text:
            filtered = [v for v in self.all_values if text in v.lower()]
        else:
            filtered = self.all_values

        self.list_widget.clear()
        self.list_widget.addItems(filtered)

        total = len(self.all_values)
        shown = len(filtered)
        if text:
            self.count_label.setText(f"{shown} résultat(s) sur {total}")
        else:
            self.count_label.setText(f"{total} résultat(s)")

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def _clear_highlights(self):
        """Retire les surbrillances actuellement affichées sur la carte."""
        for hl in self.highlights:
            hl.hide()
        self.highlights = []

    def show_temporary_message(self, text, duration_ms=5000):
        """Affiche un message sous les boutons, qui disparaît automatiquement
        après `duration_ms` millisecondes (5 secondes par défaut)."""
        self.status_label.setText(text)
        QTimer.singleShot(duration_ms, lambda: self.status_label.setText(""))

    def reset_highlight(self):
        """Efface la mise en évidence (surbrillance) et la sélection
        d'entités active, sans changer de couche ni de recherche, et
        rafraîchit la carte."""
        self._clear_highlights()

        layer = self.current_layer()
        if layer is not None:
            layer.removeSelection()

        # blockSignals évite que la désélection ne redéclenche
        # le zoom (connecté à itemSelectionChanged).
        self.list_widget.blockSignals(True)
        self.list_widget.clearSelection()
        self.list_widget.setCurrentItem(None)
        self.list_widget.blockSignals(False)

        self.info_value_label.setPlainText("")
        self.iface.mapCanvas().refresh()

    def _selected_request(self, value):
        """Requête ciblant l'objet choisi : valeur du champ listé, en tenant
        compte du filtre actif (sinon on zoomerait aussi sur des objets de
        même valeur situés hors du filtre)."""
        field_name = self.field_combo.currentText()
        expr = f'"{field_name}" = {QgsExpression.quotedValue(value)}'
        filter_value = self.filter_value_combo.currentData()
        if self.filter_field_combo.currentIndex() > 0 and filter_value is not None:
            filter_field = self.filter_field_combo.currentText()
            expr += f' AND "{filter_field}" = {QgsExpression.quotedValue(filter_value)}'
        return QgsFeatureRequest(QgsExpression(expr))

    def update_info_label(self):
        """Affiche, pour l'entité actuellement sélectionnée dans la liste,
        les valeurs des champs cochés par l'utilisateur (une ligne par champ)."""
        layer = self.current_layer()
        item = self.list_widget.currentItem()
        info_fields = self.info_field_combo.checkedItems() if layer is not None else []

        if layer is None or item is None or not info_fields:
            self.info_value_label.setPlainText("")
            return

        fields = layer.fields()
        pairs = [(n, fields.indexOf(n)) for n in info_fields]
        pairs = [(n, i) for n, i in pairs if i != -1]
        if not pairs:
            self.info_value_label.setPlainText("")
            return

        request = self._selected_request(item.text())
        request.setSubsetOfAttributes([i for _, i in pairs])
        request.setFlags(_NO_GEOMETRY)

        found = {n: [] for n, _ in pairs}
        for feat in layer.getFeatures(request):
            for n, i in pairs:
                v = feat[i]
                sv = str(v) if v not in (None, "") else None
                if sv and sv not in found[n]:
                    found[n].append(sv)

        lines = [
            f"{n} : " + (", ".join(found[n]) if found[n] else "(aucune valeur)")
            for n, _ in pairs
        ]
        self.info_value_label.setPlainText("\n".join(lines))

    def zoom_to_selected(self):
        layer = self.current_layer()
        item = self.list_widget.currentItem()
        if layer is None or item is None:
            return

        request = self._selected_request(item.text())

        features = list(layer.getFeatures(request))
        if not features:
            return

        layer.selectByIds([f.id() for f in features])

        canvas = self.iface.mapCanvas()
        layer_crs = layer.crs()

        # ------------------------------------------------------------
        # Surbrillance : on dessine une surbrillance dédiée (rouge) par
        # dessus la carte, indépendante du style de la couche, donc
        # toujours visible quel que soit le rendu (polygones, lignes,
        # points, couleurs de sélection personnalisées, etc.).
        # ------------------------------------------------------------
        self._clear_highlights()
        for feat in features:
            geom = feat.geometry()
            if geom is None or geom.isNull():
                continue
            hl = QgsHighlight(canvas, geom, layer)
            hl.setColor(QColor(255, 0, 0, 255))
            hl.setFillColor(QColor(255, 0, 0, 60))
            hl.setWidth(3)
            hl.setBuffer(0.5)
            hl.show()
            self.highlights.append(hl)

        # ------------------------------------------------------------
        # Cadrage : emprise calculée sur les géométries réelles des
        # entités trouvées (plus précis qu'une emprise de sélection),
        # avec une marge fixe et resserrée pour un zoom proche.
        # ------------------------------------------------------------
        extent = QgsRectangle()
        extent.setMinimal()
        has_geom = False
        for feat in features:
            geom = feat.geometry()
            if geom is not None and not geom.isNull():
                extent.combineExtentWith(geom.boundingBox())
                has_geom = True

        # Pas de test isEmpty() ici : il renvoie vrai pour l'emprise d'un
        # point (largeur/hauteur nulles), ce qui empêchait le zoom.
        if not has_geom:
            canvas.refresh()
            return

        etrs_transform_done = False

        if layer_crs.authid() == LAMBERT72_AUTHID:
            # Couche en Lambert belge 72 : conversion en Lambert belge 2008
            # (rattaché à ETRS89) pour la localisation, et bascule du
            # canevas sur ce système.
            target_crs = QgsCoordinateReferenceSystem(LAMBERT2008_AUTHID)
            transform = QgsCoordinateTransform(layer_crs, target_crs, QgsProject.instance())
            try:
                extent = transform.transformBoundingBox(extent)
                etrs_transform_done = True
            except Exception:
                pass
            if canvas.mapSettings().destinationCrs().authid() != target_crs.authid():
                canvas.setDestinationCrs(target_crs)
        else:
            canvas_crs = canvas.mapSettings().destinationCrs()
            if layer_crs != canvas_crs:
                transform = QgsCoordinateTransform(layer_crs, canvas_crs, QgsProject.instance())
                try:
                    extent = transform.transformBoundingBox(extent)
                except Exception:
                    pass

        if extent.width() == 0 or extent.height() == 0:
            # Point (ou ligne parfaitement horizontale/verticale) : emprise
            # minimale autour de l'objet pour un cadrage lisible (~50 m en
            # système métrique, ~50 m également en degrés).
            if canvas.mapSettings().destinationCrs().isGeographic():
                buffer = 0.0005
            else:
                buffer = 25
            extent.grow(max(buffer, max(extent.width(), extent.height()) * 0.15))
        else:
            # Marge resserrée (15%) autour de l'entité pour un cadrage
            # proche, au lieu d'un zoom arrière plus large.
            extent.scale(1.15)

        canvas.setExtent(extent)
        canvas.refresh()

        if etrs_transform_done:
            self.show_temporary_message(
                f"Transformation ETRS effectuée pour la couche « {layer.name()} » "
                "(Lambert 72 → Lambert 2008)."
            )
