import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon

try:
    from qgis.PyQt.QtWidgets import QAction
except ImportError:  # Qt6
    from qgis.PyQt.QtGui import QAction

from .recherche_resa_dialog import RechercheResaDialog

MENU = "&Recherche objet"


class RechercheResaPlugin:
    """Liste les valeurs uniques d'un champ, pour n'importe quelle couche."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dlg = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()
        self.action = QAction(icon, "Recherche objet...", self.iface.mainWindow())
        self.action.setToolTip("Ouvrir la recherche objet")
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(MENU, self.action)

    def unload(self):
        if self.action is not None:
            self.iface.removePluginMenu(MENU, self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None
        if self.dlg is not None:
            self.iface.removeDockWidget(self.dlg)
            self.dlg.deleteLater()
            self.dlg = None

    def run(self):
        if self.dlg is None:
            self.dlg = RechercheResaDialog(self.iface)
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dlg)
        else:
            self.dlg.refresh_layers()
        self.dlg.show()
        self.dlg.raise_()
