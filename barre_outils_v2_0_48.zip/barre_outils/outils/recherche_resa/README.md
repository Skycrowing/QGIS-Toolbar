# Plugin QGIS – Recherche objet

Plugin générique : fonctionne avec **n'importe quelle couche vectorielle**
du projet et **n'importe lequel de ses champs**. Rien n'est câblé sur les
communes ou sur `NAME1` — c'est un outil de recherche/liste réutilisable.

## Installation

1. Ouvrez QGIS.
2. Menu **Extensions > Installer/Gérer les extensions...**
3. Onglet **Installer depuis un ZIP**.
4. Sélectionnez `recherche_resa.zip`.
5. Cliquez sur **Installer le plugin**.
6. Un menu **RESA** apparaît dans la barre de menu (à côté de Fichier,
   Édition, Vue... juste avant Aide), avec l'entrée **Recherche objet...**.
   Une **barre d'outils dédiée "RESA"** apparaît également, avec l'icône
   de lancement du plugin (visible/masquable via **Affichage > Barres
   d'outils > RESA**).
   Le panneau s'ouvre **ancré sur le côté droit** de la fenêtre QGIS (comme
   les panneaux natifs Couches ou Navigateur). Vous pouvez le faire glisser
   pour le déplacer à gauche, en bas, le détacher en fenêtre flottante, ou
   le refermer — sa position est mémorisée par QGIS d'une session à
   l'autre.

Si une version précédente (ex. "Liste des Communes") était installée,
désinstallez-la d'abord pour éviter tout conflit de menu.

## Utilisation

1. Chargez n'importe quelle couche vectorielle dans le projet.
2. Ouvrez **RESA > Recherche objet...**. Au premier démarrage, le panneau
   s'ouvre **entièrement vide** : aucune couche ni champ n'est
   présélectionné, jusqu'à ce que vous fassiez un choix.
3. Choisissez :
   - la **couche** à interroger (cochez **Ne montrer que les couches
     visibles** pour ne lister que celles actuellement cochées dans le
     panneau des couches de QGIS — cochée par défaut),
   - le **champ à lister**,
   - éventuellement un **champ de filtre** et une **valeur** précise.
4. La liste des valeurs uniques (filtrées ou non) s'affiche, avec le
   **nombre de résultats** au-dessus.
5. Utilisez le champ **Rechercher dans les résultats...** pour taper une
   partie du nom recherché : la liste se filtre en direct (insensible à
   la casse) et le compteur indique le nombre de résultats trouvés sur le
   total (ex. `3 résultat(s) sur 73`).
6. Cliquez sur une valeur pour **sélectionner et zoomer** sur les entités
   correspondantes.
   - Si la couche est en **Lambert belge 72 (EPSG:31370)**, l'emprise est
     automatiquement convertie en **Lambert belge 2008 (EPSG:3812)** et le
     canevas de la carte bascule sur ce système pour la localisation.
   - Pour tout autre système, l'emprise est simplement transformée vers le
     CRS actuel du canevas si nécessaire (aucun changement forcé de CRS).
   - L'entité est mise en **surbrillance rouge** sur la carte (contour +
     remplissage semi-transparent), indépendamment du style de la couche.
   - Le cadrage se resserre sur l'entité (marge de 15%, ou une emprise
     minimale pour les entités ponctuelles) plutôt que de zoomer en arrière.
   - Si une conversion **Lambert 72 → Lambert 2008 (ETRS89)** a dû être
     effectuée pour cette localisation, un **message temporaire** s'affiche
     pendant 5 secondes sous les boutons, précisant le nom de la couche
     concernée, puis disparaît automatiquement. Aucun message n'apparaît si
     la couche était déjà dans un système compatible.
7. Le bouton **Réinitialiser la mise en évidence** efface la surbrillance
   rouge et la sélection d'entités sur la carte, sans changer de couche ni
   de recherche en cours.
8. Le champ **Champ à afficher (valeur liée à l'entité sélectionnée)**
   permet de choisir n'importe quel autre champ de la couche : dès qu'une
   valeur est sélectionnée dans la liste, la valeur correspondante de ce
   second champ s'affiche dans la fenêtre située sous la liste des résultats (plusieurs champs peuvent être cochés, une ligne par champ). Les poignées entre les fenêtres permettent d'en ajuster la hauteur (ex. sélectionner une commune
   dans `NAME1` et afficher sa valeur de `COMMUNES_R`). Si plusieurs
   entités partagent la même valeur mais ont des valeurs différentes pour
   ce second champ, toutes sont listées.

## Performance sur les grosses couches

Le calcul des valeurs uniques parcourt les entités de la couche (en ne
chargeant que le champ nécessaire, sans géométrie, pour rester rapide) et
affiche une **barre de progression** pendant l'opération. L'interface reste
réactive même sur des couches comportant beaucoup d'entités ou d'attributs.
Les contrôles (couches, champs, liste) sont désactivés le temps du calcul
pour éviter tout conflit.

## Fichiers du plugin

- `metadata.txt` – informations requises par QGIS
- `__init__.py` – point d'entrée (`classFactory`)
- `recherche_resa.py` – intégration dans l'interface QGIS (menu top-level, action)
- `recherche_resa_dialog.py` – logique et interface de la boîte de dialogue
- `logo.png` – logo RESA (fond transparent), affiché en en-tête de la boîte de dialogue
- `icon.png` – icône carrée dérivée du logo, utilisée dans la barre d'outils, le menu et le gestionnaire d'extensions
