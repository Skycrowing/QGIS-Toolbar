def classFactory(iface):
    from .plugin import PointReviewPlugin
    return PointReviewPlugin(iface)
