import html
import os
from functools import reduce
from operator import or_

from qgis.PyQt.QtCore import QSize, Qt, QTimer, QUrl
from qgis.PyQt.QtGui import QColor, QDesktopServices, QIcon, QPalette
from qgis.PyQt.QtWidgets import (
    QCheckBox, QComboBox, QDockWidget, QToolButton, QFormLayout, QFrame, QHBoxLayout, QLabel,
    QPushButton, QSpinBox, QSplitter, QTabWidget, QTextBrowser, QVBoxLayout, QWidget,
)
from qgis.core import (
    NULL, Qgis, QgsApplication, QgsCoordinateTransform, QgsExpression, QgsExpressionContext,
    QgsExpressionContextUtils, QgsFeatureRequest, QgsRectangle,
    QgsMapLayerProxyModel, QgsProject, QgsRasterLayer, QgsCoordinateReferenceSystem,
)
from qgis.gui import (
    QgsCheckableComboBox, QgsExpressionLineEdit, QgsMapCanvas, QgsMapToolPan, QgsFieldComboBox, QgsFilterLineEdit, QgsMapLayerComboBox, QgsRubberBand,
    QgsScaleWidget, QgsVertexMarker,
)

from .map_overlay import MapOverlay

TITLE = "Geometry_Parser"
MINI_SCALE = 10000
ICON_DIR = os.path.join(os.path.dirname(__file__), "icons")


def _filter_enum():
    try:
        return Qgis.LayerFilter
    except AttributeError:
        return QgsMapLayerProxyModel


DOC_PATH = os.path.join(os.path.dirname(__file__), "doc", "index.html")


def open_help():
    QDesktopServices.openUrl(QUrl.fromLocalFile(DOC_PATH))


def _nav_icon(kind):
    return QIcon(os.path.join(ICON_DIR, f"{kind}.png"))


def _is_url(text):
    return text.startswith(("http://", "https://", "www."))


def _is_point(geom):
    try:
        return geom.type() == Qgis.GeometryType.Point
    except AttributeError:
        from qgis.core import QgsWkbTypes
        return geom.type() == QgsWkbTypes.PointGeometry


def _circle_icon():
    try:
        return QgsVertexMarker.IconType.ICON_CIRCLE
    except AttributeError:
        return QgsVertexMarker.ICON_CIRCLE


def _is_empty(value):
    return value is None or value == NULL


class _ClickPanTool(QgsMapToolPan):
    """Glisser = deplacer la carte OSM ; simple clic = appel de on_click(point)."""

    def __init__(self, canvas, on_click):
        super().__init__(canvas)
        self._on_click = on_click
        self._press_pos = None

    def canvasPressEvent(self, e):
        self._press_pos = e.pos()
        super().canvasPressEvent(e)

    def canvasReleaseEvent(self, e):
        is_click = (
            e.button() == Qt.MouseButton.LeftButton
            and self._press_pos is not None
            and (e.pos() - self._press_pos).manhattanLength() <= 4
        )
        self._press_pos = None
        super().canvasReleaseEvent(e)
        if is_click:
            self._on_click(self.toMapCoordinates(e.pos()))


class ReviewDock(QDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__(TITLE, parent or iface.mainWindow())
        self.setObjectName("GeometryParserDock")
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.fids = []
        self.index = -1
        self.highlights = []  # (canvas, item)
        self._mini_center = None  # centre de l'entite courante (WGS84)
        self._mini_marker = None
        self._current_geom = None
        self._current_feat = None
        self._build_ui()
        self._on_layer_changed(self.layer_cb.currentLayer())

    def _build_ui(self):
        tabs = QTabWidget()

        # Onglet Source
        src = QWidget()
        form = QFormLayout(src)
        self.layer_cb = QgsMapLayerComboBox()
        type_row = QHBoxLayout()
        self.pt_chk = QCheckBox("Points")
        self.line_chk = QCheckBox("Lignes")
        self.poly_chk = QCheckBox("Surfaces")
        self.pt_chk.setChecked(True)
        for chk in (self.pt_chk, self.line_chk, self.poly_chk):
            type_row.addWidget(chk)
            chk.toggled.connect(self._update_layer_filter)
        type_row.addStretch(1)
        self._update_layer_filter()
        self.sort_rows = []
        self.sort_box = QVBoxLayout()
        self.sort_box.setContentsMargins(0, 0, 0, 0)
        add_sort_btn = QPushButton("+ Ajouter un critère de tri")
        add_sort_btn.clicked.connect(self._add_sort_row)
        simple_row = QHBoxLayout()
        self.simple_field_cb = QgsFieldComboBox()
        self.simple_field_cb.setToolTip("Champ dans lequel chercher")
        self.simple_value_edit = QgsFilterLineEdit()
        self.simple_value_edit.setPlaceholderText("Valeur…")
        self.simple_value_edit.setToolTip("Recherche la valeur (partielle, sans tenir compte de la casse)")
        simple_row.addWidget(self.simple_field_cb, 1)
        simple_row.addWidget(self.simple_value_edit, 1)
        self.filter_edit = QgsExpressionLineEdit()
        self.filter_edit.setExpressionDialogTitle("Filtre avancé des entités")
        self.filter_edit.setToolTip('Ex. : "type" = \'arbre\' AND "hauteur" > 5')
        self._filter_timer = QTimer(self)
        self._filter_timer.setSingleShot(True)
        self._filter_timer.setInterval(700)
        self._filter_timer.timeout.connect(self._apply_filter)
        self.sel_chk = QCheckBox("Seulement les entités sélectionnées")
        zoom_row = QHBoxLayout()
        self.zoom_chk = QCheckBox("Zoomer à")
        self.zoom_chk.setChecked(True)
        self.scale_w = QgsScaleWidget()
        self.scale_w.setScale(1000)
        self.scale_w.setToolTip("Échelle appliquée à la navigation (et immédiatement à l'entité en cours)")
        self.scale_w.scaleChanged.connect(self._on_scale_changed)
        zoom_row.addWidget(self.zoom_chk)
        zoom_row.addWidget(self.scale_w, 1)
        self.extent_chk = QCheckBox("Lignes/surfaces : ajuster à l'emprise")
        self.extent_chk.setChecked(True)
        self.extent_chk.setToolTip(
            "Zoome sur l'emprise de l'entité au lieu de l'échelle fixe.\n"
            "Se décoche automatiquement si vous modifiez l'échelle.")
        load_btn = QPushButton("Recharger la liste")
        form.addRow("Types", type_row)
        form.addRow("Couche", self.layer_cb)
        form.addRow("Filtre", simple_row)
        form.addRow("Filtre avancé", self.filter_edit)
        form.addRow("Trier par", self.sort_box)
        form.addRow(add_sort_btn)
        form.addRow(self.sel_chk)
        form.addRow(zoom_row)
        form.addRow(self.extent_chk)
        self.fields_cb = QgsCheckableComboBox()
        self.fields_cb.setDefaultText("(aucune)")
        self.fields_cb.setToolTip("Valeurs affichées à côté du compteur dans l'onglet Navigation")
        self._checked_fields = []
        form.addRow("Info affichée", self.fields_cb)
        help_btn = QPushButton("Aide")
        help_btn.setToolTip("Ouvrir la documentation")
        help_btn.clicked.connect(open_help)
        btn_row = QHBoxLayout()
        btn_row.addWidget(load_btn, 1)
        btn_row.addWidget(help_btn)
        form.addRow(btn_row)
        tabs.addTab(src, "Source")

        # Navigation
        nav = QWidget()
        nav_l = QVBoxLayout(nav)
        self.info_lbl = QLabel()
        self.info_lbl.setWordWrap(True)
        self.info_lbl.setTextFormat(Qt.TextFormat.RichText)
        row = QHBoxLayout()
        self.first_btn = QPushButton("⏮")
        self.prev_btn = QPushButton("◀")
        self.next_btn = QPushButton("▶")
        self.last_btn = QPushButton("⏭")
        self.first_btn.setToolTip("Première entité")
        self.prev_btn.setToolTip("Entité précédente (Ctrl+Alt+←)")
        self.next_btn.setToolTip("Entité suivante (Ctrl+Alt+→)")
        self.last_btn.setToolTip("Dernière entité")
        self.goto_sp = QSpinBox()
        self.goto_sp.setMinimum(1)
        self.goto_sp.setKeyboardTracking(False)
        self.goto_sp.setToolTip("Aller à l'entité n°")
        for btn, kind in ((self.first_btn, "first"), (self.prev_btn, "prev"),
                          (self.next_btn, "next"), (self.last_btn, "last")):
            btn.setText("")
            btn.setIcon(_nav_icon(kind))
            btn.setIconSize(QSize(26, 26))
            btn.setFixedSize(34, 34)
            btn.setFlat(True)
            btn.setStyleSheet("QPushButton{border:none;background:transparent;}"
                              "QPushButton:pressed{padding-top:2px;}")
        self.goto_sp.setMinimumHeight(32)
        row.addStretch(1)
        for w in (self.first_btn, self.prev_btn, self.goto_sp, self.next_btn, self.last_btn):
            row.addWidget(w)
        row.addStretch(1)
        self.attr_view = QTextBrowser()
        self.attr_view.setOpenExternalLinks(True)
        self.attr_view.setFrameShape(QFrame.Shape.NoFrame)
        self.info_lbl.setStyleSheet("font-size:10pt;")
        # Carte OpenStreetMap, dans le SCR du projet, centree sur l'entite au 1:10 000
        self.osm_layer = QgsRasterLayer(
            "type=xyz&url=https://tile.openstreetmap.org/{z}/{x}/{y}.png"
            "&zmin=0&zmax=19",
            "OpenStreetMap", "wms")
        self.mini = QgsMapCanvas()
        self.mini.setMinimumHeight(120)
        self.mini.setCanvasColor(QColor("white"))
        self.mini.setLayers([self.osm_layer])
        self.mini.setToolTip("Glisser pour déplacer, molette pour zoomer, clic pour recentrer la carte principale")
        self.mini_overlay = MapOverlay(self.mini)
        self.mini_pan = _ClickPanTool(self.mini, self._recenter_main_map)
        self.mini.setMapTool(self.mini_pan)
        self._update_mini_crs()
        QgsProject.instance().crsChanged.connect(self._on_project_crs_changed)
        split = QSplitter(Qt.Orientation.Vertical)
        split.addWidget(self.attr_view)
        split.addWidget(self.mini)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 2)
        nav_l.addWidget(self.info_lbl)
        nav_l.addLayout(row)
        nav_l.addWidget(split, 1)
        tabs.addTab(nav, "Navigation")
        self.tabs = tabs
        refresh_btn = QToolButton()
        refresh_btn.setIcon(QgsApplication.getThemeIcon("mActionRefresh.svg"))
        refresh_btn.setAutoRaise(True)
        refresh_btn.setToolTip("Vider les filtres et recharger")
        refresh_btn.clicked.connect(lambda: self._reset_filters())
        tabs.setCornerWidget(refresh_btn, Qt.Corner.TopRightCorner)

        self.setWidget(tabs)
        self.fields_cb.checkedItemsChanged.connect(self._on_fields_checked)

        self.layer_cb.layerChanged.connect(self._on_layer_changed)
        self.sel_chk.toggled.connect(lambda _: self.reload())
        self.filter_edit.expressionChanged.connect(lambda _: self._filter_timer.start())
        self.simple_value_edit.textChanged.connect(lambda _: self._filter_timer.start())
        self.simple_field_cb.currentIndexChanged.connect(self._on_simple_field_changed)
        tabs.currentChanged.connect(lambda i: i == 1 and QTimer.singleShot(0, self._center_mini))
        load_btn.clicked.connect(self.reload)
        self.first_btn.clicked.connect(lambda: self.go_to(0))
        self.prev_btn.clicked.connect(self.previous_point)
        self.next_btn.clicked.connect(self.next_point)
        self.last_btn.clicked.connect(lambda: self.go_to(len(self.fids) - 1))
        self.goto_sp.valueChanged.connect(self._on_goto)

    # API publique (raccourcis)
    def next_point(self):
        self._step(1)

    def previous_point(self):
        self._step(-1)

    def cleanup(self):
        self._clear_marker()
        try:
            QgsProject.instance().crsChanged.disconnect(self._on_project_crs_changed)
        except (TypeError, RuntimeError):
            pass
        self.mini.unsetMapTool(self.mini_pan)

    # Logique
    def _add_sort_row(self):
        row = QWidget()
        lay = QHBoxLayout(row)
        lay.setContentsMargins(0, 0, 0, 0)
        field_cb = QgsFieldComboBox()
        field_cb.setLayer(self.layer_cb.currentLayer())
        order_cb = QComboBox()
        order_cb.addItems(["↑", "↓"])
        order_cb.setToolTip("Croissant / décroissant")
        del_btn = QPushButton("✕")
        del_btn.setFixedWidth(28)
        lay.addWidget(field_cb, 1)
        lay.addWidget(order_cb)
        lay.addWidget(del_btn)
        entry = (row, field_cb, order_cb)
        self.sort_rows.append(entry)
        self.sort_box.addWidget(row)
        field_cb.fieldChanged.connect(lambda _: self.reload())
        order_cb.currentIndexChanged.connect(lambda _: self.reload())
        del_btn.clicked.connect(lambda: self._remove_sort_row(entry))
        self.reload()

    def _remove_sort_row(self, entry):
        self.sort_rows.remove(entry)
        entry[0].setParent(None)
        entry[0].deleteLater()
        self.reload()

    def _update_layer_filter(self, _=None):
        checks = (self.pt_chk, self.line_chk, self.poly_chk)
        if not any(c.isChecked() for c in checks):
            sender = self.sender()
            if isinstance(sender, QCheckBox):
                sender.blockSignals(True)
                sender.setChecked(True)
                sender.blockSignals(False)
            return
        f = _filter_enum()
        flags = [flag for chk, flag in zip(checks, (f.PointLayer, f.LineLayer, f.PolygonLayer))
                 if chk.isChecked()]
        self.layer_cb.setFilters(reduce(or_, flags))

    def _on_simple_field_changed(self, _=None):
        if not self.simple_value_edit.text():
            return
        self._filter_timer.stop()
        self.simple_value_edit.blockSignals(True)
        self.simple_value_edit.setText("")
        self.simple_value_edit.blockSignals(False)
        self.reload()

    def _reset_filters(self):
        self._filter_timer.stop()
        for w in (self.simple_value_edit, self.filter_edit):
            w.blockSignals(True)
        self.simple_value_edit.setText("")
        self.filter_edit.setExpression("")
        for w in (self.simple_value_edit, self.filter_edit):
            w.blockSignals(False)
        self.reload()

    # Carte OSM
    def _update_mini_crs(self):
        """La carte utilise le SCR du projet (EPSG:3857 si non defini)."""
        crs = QgsProject.instance().crs()
        if not crs.isValid():
            crs = QgsCoordinateReferenceSystem("EPSG:3857")
        if self.mini.mapSettings().destinationCrs() != crs:
            self.mini.setDestinationCrs(crs)

    def _on_project_crs_changed(self):
        self._update_mini_crs()
        self._center_mini()
        self._draw_mini_highlight()

    def _recenter_main_map(self, pt):
        """Centre la carte principale sur le point clique (echelle conservee)."""
        xform = QgsCoordinateTransform(
            self.mini.mapSettings().destinationCrs(),
            self.canvas.mapSettings().destinationCrs(),
            QgsProject.instance())
        try:
            self.canvas.setCenter(xform.transform(pt))
        except Exception:
            return
        self.canvas.refresh()

    def _mini_point(self):
        """Centre de l'entite courante dans le SCR de la carte OSM."""
        if self._mini_center is None:
            return None
        xform = QgsCoordinateTransform(
            QgsCoordinateReferenceSystem("EPSG:4326"),
            self.mini.mapSettings().destinationCrs(), QgsProject.instance())
        try:
            return xform.transform(self._mini_center)
        except Exception:
            return None

    def _center_mini(self):
        c = self._mini_center
        if c is None:
            self.mini.refresh()
            return
        xform = QgsCoordinateTransform(
            QgsCoordinateReferenceSystem("EPSG:4326"),
            self.mini.mapSettings().destinationCrs(), QgsProject.instance())
        try:
            pt = xform.transform(c)
            # Emprise initiale autour du point (la carte peut ne pas avoir
            # d'emprise valide), puis echelle 1:10 000.
            d = 0.005
            rect = xform.transformBoundingBox(QgsRectangle(c.x() - d, c.y() - d, c.x() + d, c.y() + d))
        except Exception:
            return
        self.mini.setExtent(rect)
        self.mini.setCenter(pt)
        self.mini.zoomScale(MINI_SCALE)
        self.mini.refresh()

    def _clear_mini_highlight(self):
        if self._mini_marker is not None:
            self.mini.scene().removeItem(self._mini_marker)
            self._mini_marker = None

    def _draw_mini_highlight(self):
        self._clear_mini_highlight()
        layer = self.layer_cb.currentLayer()
        geom = self._current_geom
        if geom is None or layer is None:
            return
        if _is_point(geom):
            pt = self._mini_point()
            if pt is None:
                return
            item = QgsVertexMarker(self.mini)
            item.setCenter(pt)
            item.setIconType(_circle_icon())
            item.setIconSize(16)
            item.setPenWidth(2)
            item.setColor(QColor(255, 0, 0))
        else:
            item = QgsRubberBand(self.mini, geom.type())
            item.setStrokeColor(QColor(255, 0, 0))
            item.setFillColor(QColor(255, 0, 0, 50))
            item.setWidth(2)
            item.setToGeometry(geom, layer)
        self._mini_marker = item

    def _simple_expression(self):
        field = self.simple_field_cb.currentField()
        value = self.simple_value_edit.text().strip()
        if not field or not value:
            return ""
        pattern = "%" + value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        return f"to_string({QgsExpression.quotedColumnRef(field)}) ILIKE {QgsExpression.quotedString(pattern)}"

    def _apply_filter(self):
        expr = self.filter_edit.expression().strip()
        if not expr or QgsExpression(expr).isValid():
            self.reload(locate=bool(self._simple_expression()))

    def _on_layer_changed(self, layer):
        self.filter_edit.setLayer(layer)
        self.simple_field_cb.blockSignals(True)
        self.simple_field_cb.setLayer(layer)
        self.simple_field_cb.blockSignals(False)
        self.fields_cb.blockSignals(True)
        self.fields_cb.clear()
        if layer is not None:
            names = layer.fields().names()
            self.fields_cb.addItems(names)
            self.fields_cb.setCheckedItems([n for n in names if n in self._checked_fields])
            self._checked_fields = [n for n in names if n in self._checked_fields]
        self.fields_cb.blockSignals(False)
        for _, field_cb, _ in self.sort_rows:
            field_cb.blockSignals(True)
            field_cb.setLayer(layer)
            field_cb.blockSignals(False)
        self.reload()

    def reload(self, locate=False):
        self._clear_marker()
        self.fids, self.index = [], -1
        self.attr_view.clear()
        layer = self.layer_cb.currentLayer()
        if layer is not None:
            req = QgsFeatureRequest()
            for _, field_cb, order_cb in self.sort_rows:
                field = field_cb.currentField()
                if field:
                    req.addOrderBy(QgsExpression.quotedColumnRef(field), order_cb.currentIndex() == 0)
            adv = self.filter_edit.expression().strip()
            simple = self._simple_expression()
            expr = " AND ".join(f"({e})" for e in (simple, adv) if e)
            ok = True
            if expr:
                parsed = QgsExpression(expr)
                if parsed.hasParserError():
                    self.iface.messageBar().pushWarning(TITLE, f"Filtre invalide : {parsed.parserErrorString()}")
                    ok = False
                else:
                    ctx = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(layer))
                    req.setExpressionContext(ctx)
                    req.setFilterExpression(expr)
            selected = None
            if ok and self.sel_chk.isChecked():
                selected = set(layer.selectedFeatureIds())
                if not selected:
                    self.iface.messageBar().pushWarning(TITLE, "Aucune entité sélectionnée.")
                    ok = False
            if ok:
                self.fids = [f.id() for f in layer.getFeatures(req)
                             if selected is None or f.id() in selected]
        self._refresh_ui()
        if self.fids:
            self.go_to(0)
        elif locate and layer is not None:
            self.iface.messageBar().pushInfo(
                TITLE, f"Aucune entité trouvée pour « {self.simple_value_edit.text().strip()} » "
                       f"dans « {self.simple_field_cb.currentField()} ».")

    def _step(self, direction):
        if not self.fids:
            return
        i = self.index + direction
        if i < 0 or i >= len(self.fids):
            self.iface.messageBar().pushInfo(TITLE, "Fin de la liste atteinte.")
            return
        self.go_to(i)

    def _on_goto(self, value):
        if value - 1 != self.index:
            self.go_to(value - 1)

    def go_to(self, i):
        layer = self.layer_cb.currentLayer()
        if layer is None or not 0 <= i < len(self.fids):
            return
        self.index = i
        fid = self.fids[i]
        feat = layer.getFeature(fid)
        self._clear_marker()

        if not feat.isValid():
            self.attr_view.clear()
            self.iface.messageBar().pushWarning(TITLE, f"Entité {fid} introuvable (supprimée ?).")
            self._refresh_ui()
            return

        geom = feat.geometry()
        if geom is not None and not geom.isEmpty():
            try:
                xform = QgsCoordinateTransform(
                    layer.crs(), self.canvas.mapSettings().destinationCrs(), QgsProject.instance()
                )
                pt = xform.transform(geom.centroid().asPoint())
            except Exception:
                pt = None
            if pt is not None:
                is_point = _is_point(geom)
                extent = None
                if not is_point and self.zoom_chk.isChecked() and self.extent_chk.isChecked():
                    try:
                        extent = xform.transformBoundingBox(geom.boundingBox())
                    except Exception:
                        extent = None
                    if extent is not None and (extent.width() <= 0 and extent.height() <= 0):
                        extent = None
                if extent is not None:
                    extent.scale(1.2)
                    self.canvas.setExtent(extent)
                else:
                    self.canvas.setCenter(pt)
                    if self.zoom_chk.isChecked():
                        self.canvas.zoomScale(self.scale_w.scale())
                self.canvas.refresh()
                if is_point:
                    item = QgsVertexMarker(self.canvas)
                    item.setCenter(pt)
                    item.setIconType(_circle_icon())
                    item.setIconSize(24)
                    item.setPenWidth(3)
                    item.setColor(QColor(255, 0, 0))
                else:
                    item = QgsRubberBand(self.canvas, geom.type())
                    item.setStrokeColor(QColor(255, 0, 0))
                    item.setFillColor(QColor(255, 0, 0, 50))
                    item.setWidth(3)
                    item.setToGeometry(geom, layer)
                self.highlights.append((self.canvas, item))

                # Carte OSM (SCR du projet)
                try:
                    to_wgs = QgsCoordinateTransform(
                        layer.crs(), QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance())
                    self._mini_center = to_wgs.transform(geom.centroid().asPoint())
                except Exception:
                    self._mini_center = None
                self._current_geom = geom
                self._update_mini_crs()
                self._center_mini()
                self._draw_mini_highlight()

        self._current_feat = feat
        self._render_attributes()
        self._refresh_ui()

    def _on_scale_changed(self, scale):
        """Un changement d'échelle doit se voir : on l'active pour la suite
        de la navigation (y compris lignes/surfaces, sinon l'emprise l'emporte)
        et on l'applique tout de suite à l'entité affichée."""
        if scale <= 0:
            return
        self.zoom_chk.setChecked(True)
        self.extent_chk.setChecked(False)
        feat = getattr(self, "_current_feat", None)
        layer = self.layer_cb.currentLayer()
        if feat is None or layer is None or not feat.isValid():
            return
        geom = feat.geometry()
        if geom is None or geom.isEmpty():
            return
        try:
            xform = QgsCoordinateTransform(
                layer.crs(), self.canvas.mapSettings().destinationCrs(), QgsProject.instance())
            self.canvas.setCenter(xform.transform(geom.centroid().asPoint()))
        except Exception:
            pass
        self.canvas.zoomScale(scale)
        self.canvas.refresh()

    def _refresh_ui(self):
        n = len(self.fids)
        for b in (self.first_btn, self.prev_btn, self.next_btn, self.last_btn, self.goto_sp):
            b.setEnabled(n > 0)
        self.goto_sp.blockSignals(True)
        self.goto_sp.setMaximum(max(n, 1))
        self.goto_sp.setValue(self.index + 1 if self.index >= 0 else 1)
        self.goto_sp.blockSignals(False)
        if not n:
            self.info_lbl.setText("Aucune entité à passer en revue.")
        elif self.index < 0:
            self.info_lbl.setText(f"{n} entités chargées.")
        else:
            txt = f"Entité {self.index + 1} / {n}"
            info = self._info_text()
            if info:
                txt += f' <span style="color:#1e6ec8;">— {info}</span>'
            self.info_lbl.setText(txt)

    def _on_fields_checked(self, items):
        self._checked_fields = list(items)
        self._refresh_ui()

    def _info_text(self):
        feat = getattr(self, "_current_feat", None)
        layer = self.layer_cb.currentLayer()
        if feat is None or layer is None or not feat.isValid():
            return ""
        parts = []
        for name in self._checked_fields:
            idx = layer.fields().indexOf(name)
            if idx >= 0:
                v = feat.attribute(idx)
                parts.append(html.escape("—" if _is_empty(v) else str(v)))
        return " · ".join(parts)

    def _render_attributes(self):
        feat = getattr(self, "_current_feat", None)
        layer = self.layer_cb.currentLayer()
        if feat is None or layer is None or not feat.isValid() or self.index < 0:
            self.attr_view.clear()
            return
        pal = self.palette()
        text = pal.color(QPalette.ColorRole.Text)
        base = pal.color(QPalette.ColorRole.Base)
        dark = base.lightness() < 128
        alt = base.lighter(125) if dark else QColor(244, 247, 251)
        line = base.lighter(160) if dark else QColor(225, 230, 238)
        muted = QColor(text)
        muted.setAlpha(150)
        accent = QColor(80, 170, 240) if dark else QColor(30, 110, 200)
        rows = []
        fields = layer.fields()
        shown = range(fields.count())
        for k, idx in enumerate(shown):
            field = fields.at(idx)
            value = feat.attribute(idx)
            if _is_empty(value):
                val_html = f'<span style="color:{muted.name()};"><i>—</i></span>'
            else:
                raw = str(value)
                esc = html.escape(raw).replace("\n", "<br>")
                if _is_url(raw):
                    href = raw if raw.startswith("http") else "https://" + raw
                    val_html = f'<a href="{html.escape(href)}" style="color:{accent.name()};">{esc}</a>'
                else:
                    val_html = esc
            bg = alt.name() if k % 2 else base.name()
            rows.append(
                f'<tr style="background-color:{bg};">'
                f'<td width="35%" style="color:{muted.name()}; font-size:9pt; '
                f'border-bottom:1px solid {line.name()};">{html.escape(field.name())}</td>'
                f'<td style="color:{text.name()}; font-weight:normal; '
                f'border-bottom:1px solid {line.name()};">{val_html}</td></tr>'
            )
        self.attr_view.setHtml(
            f'<table width="100%" cellspacing="0" cellpadding="7" '
            f'style="border-collapse:collapse; font-size:10pt;">{"".join(rows)}</table>'
        )

    def _clear_marker(self):
        for cv, item in self.highlights:
            cv.scene().removeItem(item)
        self.highlights = []
        self._current_geom = None
        self._clear_mini_highlight()
