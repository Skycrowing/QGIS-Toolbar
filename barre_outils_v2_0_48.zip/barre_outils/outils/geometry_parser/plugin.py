import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .dock import ReviewDock, TITLE, open_help

MENU = "&" + TITLE


class PointReviewPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock = None
        self.toggle = None
        self.shortcut_actions = []

    def initGui(self):
        icon = QIcon(os.path.join(os.path.dirname(__file__), "icon.png"))
        self.toggle = QAction(icon, TITLE, self.iface.mainWindow())
        self.toggle.setCheckable(True)
        self.toggle.toggled.connect(self._on_toggle)
        self.iface.addToolBarIcon(self.toggle)
        self.iface.addPluginToMenu(MENU, self.toggle)
        self.help_action = QAction("Aide", self.iface.mainWindow())
        self.help_action.triggered.connect(open_help)
        self.iface.addPluginToMenu(MENU, self.help_action)

        shortcuts = [
            ("Entité suivante", "Ctrl+Alt+Right", "next_point"),
            ("Entité précédente", "Ctrl+Alt+Left", "previous_point"),
        ]
        for label, seq, method in shortcuts:
            action = QAction(label, self.iface.mainWindow())
            action.triggered.connect(lambda _=False, m=method: self._call(m))
            self.iface.registerMainWindowAction(action, seq)
            self.iface.addPluginToMenu(MENU, action)
            self.shortcut_actions.append(action)

    def unload(self):
        for action in self.shortcut_actions:
            self.iface.unregisterMainWindowAction(action)
            self.iface.removePluginMenu(MENU, action)
        self.shortcut_actions = []
        if getattr(self, "help_action", None):
            self.iface.removePluginMenu(MENU, self.help_action)
            self.help_action = None
        if self.toggle:
            self.iface.removePluginMenu(MENU, self.toggle)
            self.iface.removeToolBarIcon(self.toggle)
            self.toggle = None
        if self.dock:
            self.dock.cleanup()
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None

    def _ensure_dock(self):
        if self.dock is None:
            self.dock = ReviewDock(self.iface)
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dock)
            self.dock.visibilityChanged.connect(self.toggle.setChecked)
        return self.dock

    def _on_toggle(self, checked):
        if checked:
            dock = self._ensure_dock()
            dock.show()
            dock.raise_()
        elif self.dock:
            self.dock.hide()

    def _call(self, method):
        dock = self._ensure_dock()
        if not dock.isVisible():
            dock.show()
        getattr(dock, method)()
