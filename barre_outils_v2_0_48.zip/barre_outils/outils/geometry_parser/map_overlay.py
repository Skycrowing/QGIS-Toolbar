import math

from qgis.PyQt.QtCore import Qt, QEvent, QPointF, QRectF, QTimer
from qgis.PyQt.QtGui import QPainter, QColor, QPen, QBrush, QFont, QPolygonF, QFontMetrics
from qgis.PyQt.QtWidgets import QWidget
from qgis.core import Qgis, QgsDistanceArea, QgsPointXY, QgsProject, QgsUnitTypes

try:
    _METERS = Qgis.DistanceUnit.Meters
except AttributeError:  # QGIS < 3.30
    _METERS = QgsUnitTypes.DistanceMeters


def _text_width(fm, text):
    try:
        return fm.horizontalAdvance(text)
    except AttributeError:  # Qt < 5.11
        return fm.width(text)

COPYRIGHT = "© OpenStreetMap contributors"
OVERLAY_OPACITY = 0.7  # opacite fleche nord / barre d'echelle


class MapOverlay(QWidget):
    """Fleche nord, barre d'echelle et copyright dessines par-dessus un QgsMapCanvas."""

    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setGeometry(canvas.rect())
        canvas.extentsChanged.connect(self.update)
        canvas.scaleChanged.connect(self.update)
        canvas.destinationCrsChanged.connect(self.update)
        # Canevas parfois cree dans un onglet cache : re-synchroniser et
        # repasser au premier plan a chaque rendu / affichage.
        try:
            canvas.mapCanvasRefreshed.connect(self._sync)
        except AttributeError:
            pass
        canvas.installEventFilter(self)
        self.show()
        self.raise_()

    def _sync(self):
        try:
            if self.geometry() != self.canvas.rect():
                self.setGeometry(self.canvas.rect())
            self.raise_()
            self.update()
        except RuntimeError:  # canevas supprime
            pass

    def eventFilter(self, obj, event):
        if obj is self.canvas and event.type() == QEvent.Type.Show:
            QTimer.singleShot(0, self._sync)
        if obj is self.canvas and event.type() == QEvent.Type.Resize:
            self.setGeometry(self.canvas.rect())
            self.raise_()
            # Conserver echelle et centre lors d'un redimensionnement
            # (sinon QGIS garde l'emprise et l'echelle change).
            ext = self.canvas.extent()
            if ext.isFinite() and not ext.isEmpty() and self.canvas.scale() > 1:
                center, scale = self.canvas.center(), self.canvas.scale()
                QTimer.singleShot(0, lambda: self._restore(center, scale))
        return False

    def _restore(self, center, scale):
        try:
            self.canvas.setCenter(center)
            self.canvas.zoomScale(scale)
        except RuntimeError:  # canevas supprime
            pass

    # --- Dessin -------------------------------------------------------

    def paintEvent(self, _event):
        if not self.canvas.extent().isFinite() or self.canvas.extent().isEmpty():
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        # Fleche nord et barre d'echelle translucides : la carte reste lisible dessous.
        p.setOpacity(OVERLAY_OPACITY)
        self._draw_north(p)
        self._draw_scalebar(p)
        p.setOpacity(1.0)
        self._draw_copyright(p)
        p.end()

    def _box(self, p, rect, alpha=110):
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(255, 255, 255, alpha))
        p.drawRoundedRect(rect, 3, 3)

    def _draw_north(self, p):
        w, h = 18.0, 30.0
        cx, top = self.width() - 10 - w / 2, 10.0
        self._box(p, QRectF(cx - w / 2 - 4, top - 2, w + 8, h + 18))

        p.save()
        p.translate(cx, top + 14 + h / 2)
        p.rotate(-self.canvas.rotation())
        tip, base = -h / 2, h / 2
        p.setPen(QPen(Qt.GlobalColor.black, 1))
        p.setBrush(Qt.GlobalColor.black)
        p.drawPolygon(QPolygonF([QPointF(0, tip), QPointF(-w / 2, base), QPointF(0, base - 7)]))
        p.setBrush(Qt.GlobalColor.white)
        p.drawPolygon(QPolygonF([QPointF(0, tip), QPointF(w / 2, base), QPointF(0, base - 7)]))
        p.restore()

        f = QFont(self.font()); f.setBold(True); f.setPointSize(8)
        p.setFont(f)
        p.setPen(Qt.GlobalColor.black)
        p.drawText(QRectF(cx - 10, top, 20, 14), Qt.AlignmentFlag.AlignCenter, "N")

    def _meters_per_pixel(self):
        ms = self.canvas.mapSettings()
        center = self.canvas.center()
        upp = self.canvas.mapUnitsPerPixel()
        da = QgsDistanceArea()
        da.setSourceCrs(ms.destinationCrs(), QgsProject.instance().transformContext())
        ell = QgsProject.instance().ellipsoid()
        da.setEllipsoid(ell if ell and ell != "NONE" else "EPSG:7030")
        try:
            d = da.measureLine(center, QgsPointXY(center.x() + upp * 100, center.y()))
            d = da.convertLengthMeasurement(d, _METERS)
        except Exception:
            return None
        return d / 100 if d > 0 else None

    def _draw_scalebar(self, p):
        mpp = self._meters_per_pixel()
        if not mpp:
            return
        target = 100 * mpp
        exp = 10 ** math.floor(math.log10(target))
        length = max(m * exp for m in (1, 2, 5) if m * exp <= target)
        px = length / mpp
        label = f"{length / 1000:g} km" if length >= 1000 else f"{length:g} m"

        f = QFont(self.font()); f.setPointSize(8)
        p.setFont(f)
        fm = QFontMetrics(f)
        x, y = 10.0, self.height() - 12.0
        self._box(p, QRectF(x - 4, y - 12 - fm.height(), px + 8 + _text_width(fm, label) + 6, fm.height() + 18))

        seg = px / 2
        p.setPen(QPen(Qt.GlobalColor.black, 1))
        p.setBrush(Qt.GlobalColor.black)
        p.drawRect(QRectF(x, y - 5, seg, 5))
        p.setBrush(Qt.GlobalColor.white)
        p.drawRect(QRectF(x + seg, y - 5, seg, 5))
        p.drawText(QPointF(x + px + 4, y), label)
        scale = f"1:{round(self.canvas.scale()):,}".replace(",", " ")
        p.drawText(QPointF(x + px / 2 - _text_width(fm, scale) / 2, y - 8), scale)

    def _draw_copyright(self, p):
        f = QFont(self.font()); f.setPointSize(7)
        p.setFont(f)
        fm = QFontMetrics(f)
        tw, th = _text_width(fm, COPYRIGHT) + 8, fm.height() + 2
        r = QRectF(self.width() - tw, self.height() - th, tw, th)
        self._box(p, r, 190)
        p.setPen(QColor(40, 40, 40))
        p.drawText(r, Qt.AlignmentFlag.AlignCenter, COPYRIGHT)
