# -*- coding: utf-8 -*-
# Network Tracer – plugin QGIS
# Copyright (C) 2026 skycrow2 <skycrow2@gmail.com>
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version. See the LICENSE file.
#
# SPDX-License-Identifier: GPL-2.0-or-later
import html
import os
import re

from qgis.core import (QgsApplication, QgsCoordinateReferenceSystem, QgsRasterLayer,
                       QgsVectorFileWriter,
                       QgsCoordinateTransform, QgsProject, QgsVectorLayer,
                       QgsFeature, QgsGeometry, QgsPointXY, QgsSettings, Qgis)
from qgis.core import (QgsProperty, QgsSymbolLayer, QgsFeatureRequest, QgsExpression,
                       QgsExpressionContext, QgsExpressionContextUtils,
                       QgsRectangle, QgsWkbTypes,
                       QgsDistanceArea, QgsMapLayer)
from qgis.gui import (QgsMapToolEmitPoint, QgsColorButton,
                      QgsExpressionLineEdit, QgsRubberBand, QgsMapCanvasItem,
                      QgsMapCanvas, QgsMapToolPan)
from qgis.PyQt.QtCore import Qt, pyqtSignal, QTimer, QPointF, QRectF, QEvent, QSize
from qgis.PyQt.QtGui import QColor, QCursor, QIcon, QPixmap, QPainter, QPainterPath, QPen, QBrush, QFont, QPolygonF
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QPushButton,
    QLineEdit, QComboBox, QLabel,
    QCheckBox, QDoubleSpinBox, QGroupBox, QDialog, QTextBrowser,
    QDialogButtonBox, QScrollArea, QFrame, QTabWidget, QListWidget, QListWidgetItem,
    QSplitter, QMessageBox, QMenu, QToolButton, QStyle, QSizePolicy, QFileDialog)

from .help_text import HELP_HTML
from .version import __version__

from . import router
from .tracer_task import RouteTask

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")
OSM_ATTRIBUTION = "© contributeurs OpenStreetMap"
OSM_COPYRIGHT_URL = "https://www.openstreetmap.org/copyright"
TRACE_PALETTE = ["#e6007e", "#1f78b4", "#33a02c", "#ff7f00", "#6a3d9a",
                 "#e31a1c", "#00a6a6", "#b15928", "#7f7f7f", "#000000"]
START_COLOR = "#1a9641"
END_COLOR = "#d7191c"
# Informations affichables dans le résultat : clé, libellé, coché par défaut
RESULT_INFO = [("dist", "Distance", True),
               ("total", "Total avec accroches", True),
               ("snap", "Accroche au réseau", True)]
DISPLAY_CRS = [("WGS84 (EPSG:4326)", "EPSG:4326"),
               ("Lambert 72 (EPSG:31370)", "EPSG:31370"),
               ("Lambert 2008 (EPSG:3812)", "EPSG:3812")]


def _is_geom_vector(lyr):
    vt = getattr(QgsMapLayer, "LayerType", QgsMapLayer)
    vec = getattr(vt, "VectorLayer", None)
    if vec is None:
        vec = getattr(Qgis.LayerType, "Vector")
    return lyr.type() == vec and lyr.isSpatial()


def _is_null(v):
    return v is None or (hasattr(v, "isNull") and v.isNull()) or str(v) == "NULL"


def _line_type():
    gt = getattr(Qgis, "GeometryType", None)
    return gt.Line if gt is not None else QgsWkbTypes.LineGeometry


def _meters_per_pixel(canvas):
    """Mètres par pixel au centre de la carte (quel que soit le SCR)."""
    da = QgsDistanceArea()
    da.setSourceCrs(canvas.mapSettings().destinationCrs(),
                    QgsProject.instance().transformContext())
    da.setEllipsoid("EPSG:7030")
    c = canvas.extent().center()
    upp = canvas.mapUnitsPerPixel()
    if upp <= 0:
        return 0
    d = da.measureLine(QgsPointXY(c.x(), c.y()), QgsPointXY(c.x() + upp * 100, c.y()))
    return d / 100.0


OSM_XYZ = ("type=xyz&url=https://tile.openstreetmap.org/%7Bz%7D/%7Bx%7D/%7By%7D.png"
           "&zmax=19&zmin=0")


class PinMarker(QgsMapCanvasItem):
    """Repère en forme d'épingle (pointe = position), couleur pleine, cœur blanc."""

    def __init__(self, canvas, color, size=26):
        super().__init__(canvas)
        self.color = QColor(color)
        self.size = size
        self.center = None
        self.setZValue(20)

    def setCenter(self, pt):
        self.center = QgsPointXY(pt)
        self.updatePosition()

    def updatePosition(self):
        if self.center is not None:
            self.setPos(self.toCanvasCoordinates(self.center))

    def boundingRect(self):
        s = self.size
        return QRectF(-s / 2 - 2, -s - 2, s + 4, s + 4)

    def paint(self, p, *_args):
        s = self.size
        r = s * 0.34                      # rayon de la tête
        cy = -s + r + 1                   # centre de la tête
        path = QPainterPath()
        path.moveTo(0, 0)
        path.cubicTo(-r * 0.35, -s * 0.3, -r, cy + r * 0.55, -r, cy)
        path.arcTo(QRectF(-r, cy - r, 2 * r, 2 * r), 180, -180)
        path.cubicTo(r, cy + r * 0.55, r * 0.35, -s * 0.3, 0, 0)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(QPen(QColor(255, 255, 255, 230), 1.4))
        p.setBrush(QBrush(self.color))
        p.drawPath(path)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor("#ffffff")))
        p.drawEllipse(QPointF(0, cy), r * 0.42, r * 0.42)


class Section(QWidget):
    """Groupe repliable maison (en-tête flèche + titre, corps masquable), état
    mémorisé. Remplace QgsCollapsibleGroupBox dont le titre pouvait être rogné."""

    def __init__(self, title, key, collapsed=True):
        super().__init__()
        self.key = "network_tracer/section_" + key
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(2)
        self.btn = QToolButton()
        self.btn.setText(title)
        self.btn.setCheckable(True)
        self.btn.setAutoRaise(True)
        self.btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.btn.setStyleSheet("QToolButton { border: none; font-weight: bold; "
                               "padding: 3px 2px; text-align: left; }")
        self.body = QFrame()
        self.body.setFrameShape(QFrame.Shape.StyledPanel)
        v.addWidget(self.btn)
        v.addWidget(self.body)
        open_ = not QgsSettings().value(self.key, collapsed, type=bool)
        self.btn.setChecked(open_)
        self._apply(open_)
        self.btn.toggled.connect(self._toggled)

    def _apply(self, open_):
        self.body.setVisible(open_)
        self.btn.setArrowType(Qt.ArrowType.DownArrow if open_ else Qt.ArrowType.RightArrow)

    def _toggled(self, open_):
        self._apply(open_)
        QgsSettings().setValue(self.key, not open_)

    def setTitle(self, title):
        self.btn.setText(title)

    def setCollapsed(self, collapsed):
        self.btn.setChecked(not collapsed)

    def isCollapsed(self):
        return not self.btn.isChecked()


class ResultMapTool(QgsMapToolPan):
    """Déplacement de la carte du résultat + clic simple (sans glisser) signalé."""
    clicked = pyqtSignal(QgsPointXY)

    def __init__(self, canvas):
        super().__init__(canvas)
        self._press = None
        self.hit_test = None    # fonction(point carte) -> index du tracé ou None
        self._hand = False

    def canvasMoveEvent(self, e):
        if e.buttons() == Qt.MouseButton.NoButton and self.hit_test is not None:
            hit = self.hit_test(e.mapPoint()) is not None
            if hit != self._hand:   # main au survol d'un tracé cliquable
                self._hand = hit
                self.canvas().setCursor(QCursor(Qt.CursorShape.PointingHandCursor if hit
                                                else Qt.CursorShape.OpenHandCursor))
            return
        super().canvasMoveEvent(e)

    def canvasPressEvent(self, e):
        self._press = e.pos()
        super().canvasPressEvent(e)

    def canvasReleaseEvent(self, e):
        p0, self._press = self._press, None
        super().canvasReleaseEvent(e)
        if p0 is not None and (e.pos() - p0).manhattanLength() <= 4:
            self.clicked.emit(e.mapPoint())


class MapOverlay(QWidget):
    """Échelle graphique + flèche du nord translucides, par-dessus une carte."""

    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        canvas.installEventFilter(self)
        canvas.extentsChanged.connect(self.update)
        self.resize(canvas.size())

    def eventFilter(self, obj, e):
        if obj is self.canvas and e.type() == QEvent.Type.Resize:
            self.resize(self.canvas.size())
        return False

    def paintEvent(self, _e):
        mpp = _meters_per_pixel(self.canvas)
        if mpp <= 0:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        bg = QBrush(QColor(255, 255, 255, 150))
        ink = QColor(40, 40, 40, 190)
        f = QFont(self.font())
        f.setPointSizeF(8)
        p.setFont(f)
        # --- échelle graphique (bas gauche)
        target = mpp * max(60, self.width() / 4)
        mag = 10 ** int(len(str(int(target))) - 1) if target >= 1 else 1
        nice = max(n * mag for n in (1, 2, 5, 10) if n * mag <= target) if target >= 1 else 1
        px = nice / mpp
        label = ("%g km" % (nice / 1000)) if nice >= 1000 else "%g m" % nice
        scale = "1:%s" % format(int(round(self.canvas.scale())), ",").replace(",", " ")
        x0, y0 = 10, self.height() - 14
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(bg)
        p.drawRoundedRect(QRectF(x0 - 6, y0 - 30, px + 12 + 70, 40), 4, 4)
        p.setPen(QPen(ink, 1.5))
        p.drawLine(QPointF(x0, y0), QPointF(x0 + px, y0))
        for x in (x0, x0 + px / 2, x0 + px):
            p.drawLine(QPointF(x, y0), QPointF(x, y0 - (6 if x != x0 + px / 2 else 4)))
        p.drawText(QPointF(x0, y0 - 10), label)
        p.drawText(QPointF(x0 + px + 8, y0 - 1), scale)
        # --- flèche du nord (haut droit)
        cx, cy, r = self.width() - 26, 30, 14
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(bg)
        p.drawEllipse(QPointF(cx, cy + 2), r + 6, r + 6)
        p.translate(cx, cy + 2)
        p.rotate(-self.canvas.rotation())
        p.setBrush(QBrush(ink))
        p.drawPolygon(QPolygonF([QPointF(0, -r), QPointF(r * 0.5, r * 0.6),
                                 QPointF(0, r * 0.25), QPointF(-r * 0.5, r * 0.6)]))
        p.resetTransform()
        p.setPen(QPen(ink))
        p.drawText(QRectF(cx - 10, cy - r - 4, 20, 10), Qt.AlignmentFlag.AlignCenter, "N")
        # --- attribution du fond OSM (bas droit)
        txt = "© contributeurs OpenStreetMap"
        tw = p.fontMetrics().horizontalAdvance(txt) + 8
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(bg)
        p.drawRect(QRectF(self.width() - tw, self.height() - 14, tw, 14))
        p.setPen(QPen(ink))
        p.drawText(QRectF(self.width() - tw, self.height() - 14, tw, 14),
                   Qt.AlignmentFlag.AlignCenter, txt)
        p.end()


def _local_crs(lonlat):
    """Projection azimutale équidistante centrée sur le point (mètres)."""
    return QgsCoordinateReferenceSystem.fromProj(
        "+proj=aeqd +lat_0=%.8f +lon_0=%.8f +datum=WGS84 +units=m +no_defs"
        % (lonlat[1], lonlat[0]))


class PointPickTool(QgsMapToolEmitPoint):
    picked = pyqtSignal(QgsPointXY)

    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvasClicked.connect(lambda pt, _btn: self.picked.emit(pt))


class TracerDock(QDockWidget):
    def __init__(self, iface):
        super().__init__("Network Tracer v%s" % __version__)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.points = {"start": None, "end": None}       # WGS84 (lon, lat)
        self.markers = {"start": None, "end": None}
        self.dir_arrow = None   # flèche de la direction de départ
        self._res_markers = []  # marqueurs de la carte du résultat
        self.task = None
        self.layer = None
        self.tool = PointPickTool(self.canvas)
        self.tool.picked.connect(self._on_picked)
        self._picking = None
        self._prev_tool = None
        self._build_ui()
        self.canvas.destinationCrsChanged.connect(self._update_arrow)
        self.canvas.scaleChanged.connect(self._update_arrow)
        prj = QgsProject.instance()
        prj.layersAdded.connect(self._refresh_net_list)
        prj.layersRemoved.connect(self._refresh_net_list)
        prj.layersRemoved.connect(lambda *_: QTimer.singleShot(0, self._update_clear_button))
        # La flèche disparaît à la fermeture du panneau et au rafraîchissement de la carte
        self.visibilityChanged.connect(
            lambda visible: self._update_arrow() if visible else self._remove_arrow())
        self.iface.actionDraw().triggered.connect(self._remove_arrow)

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        st = QgsSettings()
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(4)

        # Points
        g = QGroupBox("Points")
        gl = QGridLayout(g)
        gl.setContentsMargins(6, 4, 6, 4)
        gl.setVerticalSpacing(2)
        self.le, self.btn_pick = {}, {}
        for row, (key, label) in enumerate((("start", "Départ"), ("end", "Arrivée"))):
            btn = QPushButton(" " + label)
            btn.setIcon(QIcon(os.path.join(os.path.dirname(__file__), "icons", key + ".svg")))
            btn.setIconSize(QSize(18, 18))
            btn.setToolTip("Cliquer puis sélectionner le point sur la carte")
            btn.clicked.connect(lambda _=False, k=key: self._start_pick(k, reset=True))
            le = QLineEdit()
            le.setReadOnly(True)
            self.le[key] = le
            self.btn_pick[key] = btn
            gl.addWidget(btn, row, 0)
            gl.addWidget(le, row, 1, 1, 2)
        self.cb_crs = QComboBox()
        for label, authid in DISPLAY_CRS:
            self.cb_crs.addItem(label, authid)
        self.cb_crs.setToolTip("Système d'affichage des coordonnées")
        idx = self.cb_crs.findData(st.value("network_tracer/display_crs", "EPSG:4326"))
        self.cb_crs.setCurrentIndex(max(idx, 0))
        self.cb_crs.currentIndexChanged.connect(self._refresh_coords)
        self.btn_swap = swap = QPushButton("⇅")
        swap.setToolTip("Inverser départ et arrivée")
        swap.setFixedWidth(32)
        swap.clicked.connect(self._swap)
        gl.addWidget(QLabel("Coord."), 2, 0)
        gl.addWidget(self.cb_crs, 2, 1)
        gl.addWidget(swap, 2, 2)
        self.chk_dir = QCheckBox("Direction du tronçon")
        self.chk_dir.setIcon(QIcon(os.path.join(os.path.dirname(__file__), "icons",
                                                "direction.svg")))
        self.chk_dir.setToolTip("Option : le départ s'accroche au premier tronçon rencontré "
                                "dans cette direction (azimut, 0° = nord, sens horaire) "
                                "au lieu du tronçon le plus proche")
        self.spin_dir = QDoubleSpinBox()
        self.spin_dir.setRange(0, 359.9)
        self.spin_dir.setDecimals(0)
        self.spin_dir.setWrapping(True)
        self.spin_dir.setSingleStep(15)
        self.spin_dir.setSuffix(" °")
        self.spin_dir.setEnabled(False)
        self.btn_dir = QPushButton("Pointer")
        self.btn_dir.setToolTip("Cliquer sur la carte un point dans la direction du tronçon")
        self.btn_dir.setEnabled(False)
        self.btn_dir.clicked.connect(lambda: self._start_pick("dir"))
        self.chk_dir.toggled.connect(self.spin_dir.setEnabled)
        self.chk_dir.toggled.connect(self.btn_dir.setEnabled)
        self.chk_dir.toggled.connect(self._update_arrow)
        self.chk_dir.toggled.connect(
            lambda on: self._start_pick("dir") if on and self.points["start"] else None)
        self.spin_dir.valueChanged.connect(lambda *_: setattr(self, "_arrow_faded", False))
        self.spin_dir.valueChanged.connect(self._update_arrow)
        self._dir_point = None
        # angle saisi à la main : on oublie la voie visée par le clic
        self.spin_dir.editingFinished.connect(lambda: setattr(self, "_dir_point", None))
        hd = QHBoxLayout()
        hd.addWidget(self.chk_dir)
        hd.addWidget(self.spin_dir, 1)
        hd.addWidget(self.btn_dir)
        gl.addLayout(hd, 3, 0, 1, 3)
        lay.addWidget(g)

        # Réseau : couche de lignes + champs
        g = QGroupBox("Réseau")
        gl = QGridLayout(g)
        gl.setContentsMargins(6, 4, 6, 4)
        gl.setVerticalSpacing(2)
        self.lst_net = QListWidget()
        self.lst_net.setMaximumHeight(110)
        self.lst_net.setToolTip("Cochez une ou plusieurs couches de lignes servant de réseau : "
                                "les tronçons qui partagent un sommet sont connectés, "
                                "y compris d'une couche à l'autre")
        self._net_ids = set(i for i in str(st.value("network_tracer/net_layers", "")
                                           or st.value("network_tracer/net_layer", "")).split(";") if i)
        self.lst_net.itemChanged.connect(self._on_net_item)
        gl.addWidget(QLabel("Couches"), 0, 0, Qt.AlignmentFlag.AlignTop)
        gl.addWidget(self.lst_net, 0, 1, 1, 2)
        self.chk_net_sel = QCheckBox("Uniquement les tronçons sélectionnés")
        self.chk_net_sel.setChecked(st.value("network_tracer/net_selected", False, type=bool))
        self.le_net_filter = QgsExpressionLineEdit()
        self.le_net_filter.setExpressionDialogTitle("Filtre des tronçons du réseau")
        self.le_net_filter.setToolTip(
            "Requête limitant les tronçons utilisables (expression QGIS), ex. "
            "\"tension\" = 'BT' ou \"type\" IN ('BT', 'Éclairage'). Les couches qui n'ont "
            "pas les champs utilisés sont exclues.")
        self.le_net_filter.setExpression(st.value("network_tracer/net_filter", ""))
        gl.addWidget(QLabel("Filtre"), 1, 0)
        gl.addWidget(self.le_net_filter, 1, 1, 1, 2)
        self._net_filter_timer = QTimer(self)
        self._net_filter_timer.setSingleShot(True)
        self._net_filter_timer.setInterval(600)
        self._net_filter_timer.timeout.connect(self._on_net_filter)
        self.le_net_filter.expressionChanged.connect(lambda *_: self._net_filter_timer.start())
        self.le_net_filter.expressionChanged.connect(self._update_clear_button)
        gl.addWidget(self.chk_net_sel, 2, 0, 1, 3)
        lay.addWidget(g)

        # Actions + résultat (toujours visibles en haut)
        h = QHBoxLayout()
        self.btn_run = QPushButton("▶ Calculer")
        self.btn_run.clicked.connect(self.run)
        self.btn_stop = QPushButton("■ Arrêter")
        self.btn_stop.setToolTip("Arrêter le téléchargement / calcul en cours")
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self.stop)
        self.btn_clear = clear = QToolButton()
        clear.setIcon(QIcon(os.path.join(os.path.dirname(__file__), "icons", "refresh.svg")))
        clear.setIconSize(QSize(18, 18))
        clear.setAutoRaise(True)
        clear.setToolTip("Réinitialiser : effacer les points, les tracés et le filtre")
        clear.setEnabled(False)       # actif seulement s'il y a des tracés
        clear.clicked.connect(self._on_clear_clicked)
        for b in (self.btn_run, self.btn_stop, clear):
            h.addWidget(b)
        lay.addLayout(h)
        self.lbl_result = QLabel()
        self.lbl_result.setWordWrap(True)
        self.lbl_result.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.lbl_result.setFrameShape(QFrame.Shape.StyledPanel)
        self.lbl_result.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.lbl_result.setStyleSheet("QLabel { padding: 4px 8px; font-size: 9pt; }")
        self.lbl_result.setVisible(False)
        self.txt_result = QTextBrowser()
        self.txt_result.setFrameShape(QFrame.Shape.NoFrame)
        self.txt_result.setStyleSheet("QTextBrowser { padding: 6px; font-size: 10pt; }")
        self.txt_result.setOpenLinks(False)
        self.txt_result.document().setDefaultStyleSheet("a { text-decoration: none; }")
        self.txt_result.setToolTip("Cliquer sur un tracé pour le faire clignoter sur les cartes")
        self.txt_result.anchorClicked.connect(self._on_result_clicked)

        # Options : fenêtre ouverte par l'engrenage de la barre de titre
        self.dlg_options = QDialog(self)
        self.dlg_options.setWindowTitle("Network Tracer – Options")
        self.dlg_options.setWindowIcon(QIcon(os.path.join(os.path.dirname(__file__),
                                                          "icons", "settings.svg")))
        ov_opt = QVBoxLayout(self.dlg_options)
        g = QWidget()
        gl = QGridLayout(g)
        gl.setContentsMargins(0, 0, 0, 0)
        self.btn_color = QgsColorButton()
        self.btn_color.setColor(QColor(st.value("network_tracer/color", "#e6007e")))
        self.btn_color.setToolTip("Couleur de la première trace ; les suivantes prennent automatiquement une autre couleur")
        self.spin_width = QDoubleSpinBox()
        self.spin_width.setRange(0.1, 10)
        self.spin_width.setSingleStep(0.1)
        self.spin_width.setSuffix(" mm")
        w0 = float(st.value("network_tracer/width", 0.4))
        # anciens défauts (1,2 puis 0,6 mm) jugés trop épais -> 0,4 mm
        self.spin_width.setValue(0.4 if any(abs(w0 - v) < 1e-6 for v in (1.2, 0.6)) else w0)
        gl.addWidget(QLabel("Trace"), 0, 0)
        gl.addWidget(self.btn_color, 0, 1)
        gl.addWidget(self.spin_width, 0, 2)
        # Changement de couleur / épaisseur : appliqué en direct aux tracés affichés
        self.btn_color.colorChanged.connect(self._restyle)
        self.spin_width.valueChanged.connect(self._restyle)
        self.spin_tol = QDoubleSpinBox()
        self.spin_tol.setRange(0.001, 50)
        self.spin_tol.setDecimals(3)
        self.spin_tol.setSingleStep(0.1)
        self.spin_tol.setSuffix(" m")
        self.spin_tol.setValue(float(st.value("network_tracer/tolerance", 0.1)))
        self.spin_tol.setToolTip("Deux sommets plus proches que cette distance sont "
                                 "considérés comme un même nœud (connexion des tronçons)")
        gl.addWidget(QLabel("Tolérance"), 1, 0)
        gl.addWidget(self.spin_tol, 1, 1, 1, 2)
        self.chk_gap = QCheckBox("Raccorder les lignes mal connectées")
        self.chk_gap.setToolTip(
            "Extrémité libre d'une ligne proche d'une autre ligne (trou, ligne qui s'arrête "
            "juste avant ou juste après l'autre, croisement sans sommet commun en bout) : "
            "un raccord est créé si la distance est inférieure à la valeur indiquée")
        self.chk_gap.setChecked(st.value("network_tracer/gap_on", False, type=bool))
        self.spin_gap = QDoubleSpinBox()
        self.spin_gap.setRange(0.01, 100)
        self.spin_gap.setDecimals(2)
        self.spin_gap.setSingleStep(0.5)
        self.spin_gap.setSuffix(" m")
        self.spin_gap.setValue(float(st.value("network_tracer/gap_m", 1.0)))
        self.spin_gap.setToolTip("Distance maximale entre une extrémité libre et la ligne voisine")
        self.spin_gap.setEnabled(self.chk_gap.isChecked())
        self.chk_gap.toggled.connect(self.spin_gap.setEnabled)
        gl.addWidget(self.chk_gap, 2, 0, 1, 2)
        gl.addWidget(self.spin_gap, 2, 2)
        ov_opt.addWidget(g)
        ov_opt.addStretch()
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        bb.rejected.connect(self.dlg_options.close)
        ov_opt.addWidget(bb)

        # Informations affichées dans le résultat (repliable, appliqué en direct)
        g = Section("Informations du résultat", "result_info")
        vl = QVBoxLayout(g.body)
        vl.setContentsMargins(6, 4, 6, 4)
        vl.setSpacing(1)
        vl.addWidget(QLabel("Champs des couches réseau parcourues :"))
        self.lst_info_fields = QListWidget()
        self.lst_info_fields.setMaximumHeight(120)
        self.lst_info_fields.setToolTip(
            "Champs des couches réseau cochées : pour chaque tracé, valeurs des tronçons "
            "parcourus, dans l'ordre du trajet, avec leur longueur")
        self._info_fields = [f for f in str(st.value("network_tracer/info_fields", "")).split(";") if f]
        self.lst_info_fields.itemChanged.connect(self._on_info_field)
        vl.addWidget(self.lst_info_fields)
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)
        vl.addWidget(sep)
        self.chk_info = {}
        for key, label, default in RESULT_INFO:
            cb = QCheckBox(label)
            cb.setChecked(st.value("network_tracer/info_" + key, default, type=bool))
            cb.toggled.connect(lambda v, k=key: (
                QgsSettings().setValue("network_tracer/info_" + k, v), self._show_result()))
            self.chk_info[key] = cb
            vl.addWidget(cb)
        lay.addWidget(g)

        lay.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(w)
        # Résultat épinglé en bas du panneau, hors zone de défilement
        outer = QWidget()
        ov = QVBoxLayout(outer)
        ov.setContentsMargins(0, 0, 0, 4)
        ov.setSpacing(4)
        self.tabs = QTabWidget()
        self.tabs.addTab(scroll, "Itinéraire")
        self.res_canvas = QgsMapCanvas()
        self.res_canvas.setMinimumHeight(160)
        self.res_canvas.enableAntiAliasing(True)
        self.res_pan = ResultMapTool(self.res_canvas)
        self.res_pan.clicked.connect(self._on_result_map_clicked)
        self.res_pan.hit_test = self._hit_route
        self.res_canvas.setMapTool(self.res_pan)
        self.res_overlay = MapOverlay(self.res_canvas)
        self.res_split = QSplitter(Qt.Orientation.Vertical)
        self.res_split.addWidget(self.txt_result)
        self.res_split.addWidget(self.res_canvas)
        self.res_split.setStretchFactor(0, 1)
        self.res_split.setStretchFactor(1, 1)
        self.osm_bg = None   # fond OSM (couche hors projet, créée à la demande)
        self.tabs.addTab(self.res_split, "Résultat")
        self._set_result_html(None)
        ov.addWidget(self.tabs, 1)
        ov.addWidget(self.lbl_result)
        attr = QLabel("<small>Network Tracer v%s – GPL v2+ · fond "
                      "<a href='%s'>%s</a></small>"
                      % (__version__, OSM_COPYRIGHT_URL, OSM_ATTRIBUTION))
        attr.setOpenExternalLinks(True)
        attr.setAlignment(Qt.AlignmentFlag.AlignRight)
        ov.addWidget(attr)
        self.setWidget(outer)
        self.setTitleBarWidget(self._build_title_bar())
        self._refresh_coords()
        # Bouton Calculer mis en évidence quand tout est prêt (et pas encore calculé)
        self._dirty = True
        self._refresh_net_list()
        for sig in (self.chk_dir.toggled, self.spin_dir.valueChanged,
                    self.lst_net.itemChanged,
                    self.chk_net_sel.toggled, self.spin_tol.valueChanged,
                    self.chk_gap.toggled, self.spin_gap.valueChanged,
                    self.le_net_filter.expressionChanged):
            sig.connect(self._mark_dirty)
        self._update_run_button()

    # ------------------------------------------------------------ Réseau
    def _net_layers(self):
        prj = QgsProject.instance()
        return [l for l in (prj.mapLayer(i) for i in sorted(self._net_ids))
                if l is not None and l.isValid()]

    def _net_names(self):
        return ", ".join(l.name() for l in self._net_layers())

    def _refresh_net_list(self, *_):
        """(Re)remplit la liste des couches de lignes cochables du réseau."""
        if not hasattr(self, "lst_net"):
            return
        self.lst_net.blockSignals(True)
        self.lst_net.clear()
        route_id = self.layer.id() if self._route_layer_in_project() else None
        line = _line_type()
        layers = [l for l in QgsProject.instance().mapLayers().values()
                  if _is_geom_vector(l) and l.geometryType() == line and l.id() != route_id]
        for l in sorted(layers, key=lambda x: x.name().lower()):
            it = QListWidgetItem(l.name())
            it.setData(Qt.ItemDataRole.UserRole, l.id())
            it.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            it.setCheckState(Qt.CheckState.Checked if l.id() in self._net_ids
                             else Qt.CheckState.Unchecked)
            self.lst_net.addItem(it)
        self.lst_net.blockSignals(False)
        self._refresh_net_fields()

    def _on_net_item(self, it):
        lid = it.data(Qt.ItemDataRole.UserRole)
        if it.checkState() == Qt.CheckState.Checked:
            self._net_ids.add(lid)
        else:
            self._net_ids.discard(lid)
        QgsSettings().setValue("network_tracer/net_layers", ";".join(sorted(self._net_ids)))
        self._refresh_net_fields()

    def _refresh_net_fields(self):
        """Champs des couches réseau cochées (informations du résultat, filtre)."""
        names = set()
        for l in self._net_layers():
            names.update(l.fields().names())
        self._refresh_info_fields(names)
        lyrs = self._net_layers()
        self.le_net_filter.setLayer(lyrs[0] if lyrs else None)
        self._mark_dirty()

    def _refresh_info_fields(self, names):
        """Liste cochable des champs des couches réseau (informations du résultat)."""
        if not hasattr(self, "lst_info_fields"):
            return
        self.lst_info_fields.blockSignals(True)
        self.lst_info_fields.clear()
        for n in sorted(names, key=str.lower):
            it = QListWidgetItem(n)
            it.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            it.setCheckState(Qt.CheckState.Checked if n in self._info_fields
                             else Qt.CheckState.Unchecked)
            self.lst_info_fields.addItem(it)
        if not names:
            it = QListWidgetItem("(cochez une couche réseau)")
            it.setFlags(Qt.ItemFlag.NoItemFlags)
            self.lst_info_fields.addItem(it)
        self.lst_info_fields.blockSignals(False)

    def _on_info_field(self, it):
        name = it.text()
        if it.checkState() == Qt.CheckState.Checked:
            if name not in self._info_fields:
                self._info_fields.append(name)
        elif name in self._info_fields:
            self._info_fields.remove(name)
        QgsSettings().setValue("network_tracer/info_fields", ";".join(self._info_fields))
        self._show_result()

    def _ways_html(self, res):
        """Valeurs des champs choisis le long du tracé : val (km) → val (km)…"""
        fields = [f for f in self._info_fields
                  if any(l.fields().indexOf(f) >= 0 for l in self._net_layers())]
        if not fields or not res.get("ways"):
            return ""
        grey = "#8a8a8a"
        prj = QgsProject.instance()
        cache = getattr(self, "_feat_cache", None)
        if cache is None:
            cache = self._feat_cache = {}
        feats = []
        for fid, length in res["ways"]:
            if fid not in cache:
                f = None
                try:
                    lyr = prj.mapLayer(fid[0])
                    if lyr is not None:
                        f = lyr.getFeature(fid[1])
                        f = f if f.isValid() else None
                except (RuntimeError, TypeError):
                    f = None
                cache[fid] = f
            feats.append((cache[fid], length))
        out = []
        for name in sorted(fields, key=lambda n: self._info_fields.index(n)):
            seq = []
            for f, length in feats:
                if f is None or f.fields().indexOf(name) < 0 or _is_null(f[name]):
                    continue
                v = str(f[name])
                if seq and seq[-1][0] == v:
                    seq[-1][1] += length
                else:
                    seq.append([v, length])
            if not seq:
                continue
            more = len(seq) - 30
            txt = " → ".join("%s <span style='color:%s'>%.2f km</span>"
                             % (html.escape(v), grey, l / 1000) for v, l in seq[:30])
            if more > 0:
                txt += " <span style='color:%s'>… (+%d)</span>" % (grey, more)
            out.append("<div style='font-size:9pt; margin-top:3px'>"
                       "<span style='color:%s'>%s :</span> %s</div>"
                       % (grey, html.escape(name), txt))
        return "".join(out)

    def _net_filter(self):
        """(texte, QgsExpression) du filtre réseau ; (None, None) si vide.
        ValueError si l'expression est invalide."""
        txt = self.le_net_filter.expression().strip() if hasattr(self, "le_net_filter") else ""
        if not txt:
            return None, None
        e = QgsExpression(txt)
        if e.hasParserError():
            raise ValueError("Filtre réseau invalide : %s" % e.parserErrorString())
        return txt, e

    def _filter_applies(self, lyr, e):
        """La couche possède-t-elle les champs utilisés par le filtre ?"""
        cols = set(e.referencedColumns()) - {QgsFeatureRequest.ALL_ATTRIBUTES}
        return cols <= set(lyr.fields().names())

    def _filter_request(self, lyr, txt, e, req=None):
        req = req or QgsFeatureRequest()
        req.setFilterExpression(txt)
        req.setExpressionContext(QgsExpressionContext(
            QgsExpressionContextUtils.globalProjectLayerScopes(lyr)))
        return req

    def _on_net_filter(self):
        txt = self.le_net_filter.expression()
        try:
            self._net_filter()
        except ValueError as e:
            self._status("⚠ %s" % e)
            return
        self._status("")
        QgsSettings().setValue("network_tracer/net_filter", txt)
        self._mark_dirty()

    def _collect_lines(self, pts):
        """Tronçons de la couche réseau autour des points (emprise + marge),
        convertis en WGS84 pour le moteur de routage."""
        layers = self._net_layers()
        if not layers:
            raise ValueError("Cochez au moins une couche réseau.")
        s, w, n, e = router.compute_bbox_pts(pts)
        prj = QgsProject.instance()
        ftxt, fexp = self._net_filter()
        lines = []
        for lyr in layers:
            if fexp is not None and not self._filter_applies(lyr, fexp):
                continue   # couche sans les champs du filtre : exclue
            to_lyr = QgsCoordinateTransform(WGS84, lyr.crs(), prj)
            to_wgs = QgsCoordinateTransform(lyr.crs(), WGS84, prj)
            req = QgsFeatureRequest()
            if fexp is not None:
                self._filter_request(lyr, ftxt, fexp, req)
            req.setFilterRect(to_lyr.transformBoundingBox(QgsRectangle(w, s, e, n)))
            feats = lyr.getSelectedFeatures(req) if self.chk_net_sel.isChecked() \
                else lyr.getFeatures(req)
            for f in feats:
                g = QgsGeometry(f.geometry())
                if g.isNull() or g.isEmpty():
                    continue
                if QgsWkbTypes.isCurvedType(g.wkbType()):
                    g = QgsGeometry(g.constGet().segmentize())
                g.transform(to_wgs)
                parts = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
                for part in parts:
                    if len(part) >= 2:
                        lines.append(dict(fid=(lyr.id(), f.id()),
                                          coords=[(p.x(), p.y()) for p in part],
                                          key=router.ALL_KEY))
        if not lines:
            raise ValueError("Aucun tronçon utilisable dans les couches réseau "
                             "autour des points%s." % (" (filtre réseau)" if fexp else ""))
        return lines

    def _mark_dirty(self, *_):
        self._dirty = True
        self._update_run_button()

    def _is_ready(self):
        return bool(self.points["start"] and self.points["end"] and self._net_layers())

    def _update_run_button(self):
        if not hasattr(self, "btn_run"):
            return
        hot = self.btn_run.isEnabled() and getattr(self, "_dirty", True) and self._is_ready()
        self.btn_run.setStyleSheet(
            "QPushButton { background-color: #cfe3fa; color: #1b4f8a; font-weight: bold; "
            "border: 1px solid #8fb8e8; border-radius: 3px; padding: 3px 8px; }"
            "QPushButton:hover { background-color: #bcd7f7; }" if hot else "")
        self.btn_run.setToolTip("Prêt : lancer le calcul" if hot else "Lancer le calcul")
    def _build_title_bar(self):
        """Barre de titre : nom + version, options, aide, détacher, fermer."""
        bar = QWidget()
        h = QHBoxLayout(bar)
        h.setContentsMargins(6, 2, 2, 2)
        h.setSpacing(2)
        h.addWidget(QLabel("Network Tracer <span style='color:#8a8a8a'>v%s</span>" % __version__))
        h.addStretch()

        def tool(icon, tip, slot):
            b = QToolButton()
            b.setIcon(icon)
            b.setToolTip(tip)
            b.setAutoRaise(True)
            b.setIconSize(QSize(16, 16))
            b.clicked.connect(slot)
            h.addWidget(b)
            return b

        here = os.path.dirname(__file__)
        st = self.style()
        tool(QIcon(os.path.join(here, "icons", "settings.svg")), "Options", self.show_options)
        tool(QIcon(os.path.join(here, "icons", "help.svg")), "Aide", self.show_help)
        tool(st.standardIcon(QStyle.StandardPixmap.SP_TitleBarNormalButton), "Détacher / ancrer",
             lambda: self.setFloating(not self.isFloating()))
        tool(st.standardIcon(QStyle.StandardPixmap.SP_TitleBarCloseButton), "Fermer", self.close)
        return bar

    def _remove_arrow(self, *_):
        """Retire la flèche de direction (repère temporaire)."""
        if self.dir_arrow is not None:
            self.canvas.scene().removeItem(self.dir_arrow)
            self.dir_arrow = None

    def _update_arrow(self, *_):
        self._remove_arrow()
        if self.points["start"] and self.chk_dir.isChecked():
            self._draw_dir_arrow()

    def _draw_dir_arrow(self):
        """Flèche (60 px) partant du départ dans la direction choisie."""
        import math
        ms = self.canvas.mapSettings()
        L = self.canvas.scale() * 0.0254 / max(ms.outputDpi(), 1) * 32
        a = math.radians(self.spin_dir.value())
        def pt(r, ang):
            return QgsPointXY(r * math.sin(ang), r * math.cos(ang))
        tip = pt(L, a)
        h = L * 0.3
        head1 = QgsPointXY(tip.x() + h * math.sin(a + math.radians(150)),
                           tip.y() + h * math.cos(a + math.radians(150)))
        head2 = QgsPointXY(tip.x() + h * math.sin(a - math.radians(150)),
                           tip.y() + h * math.cos(a - math.radians(150)))
        geom = QgsGeometry.fromMultiPolylineXY([[QgsPointXY(0, 0), tip], [head1, tip, head2]])
        self.dir_arrow = QgsRubberBand(self.canvas, _line_type())
        # translucide une fois le calcul terminé
        alpha = 70 if getattr(self, "_arrow_faded", False) else 220
        self.dir_arrow.setStrokeColor(QColor(26, 150, 65, alpha))
        self.dir_arrow.setWidth(2)
        self.dir_arrow.setToGeometry(geom, _local_crs(self.points["start"]))

    # --------------------------------------------------------- Coordonnées
    def _fmt(self, lonlat):
        if lonlat is None:
            return ""
        authid = self.cb_crs.currentData()
        if authid == "EPSG:4326":
            return "%.6f, %.6f" % lonlat
        xf = QgsCoordinateTransform(WGS84, QgsCoordinateReferenceSystem(authid),
                                    QgsProject.instance())
        p = xf.transform(QgsPointXY(*lonlat))
        return "%.2f, %.2f" % (p.x(), p.y())

    def _refresh_coords(self, *_):
        authid = self.cb_crs.currentData()
        QgsSettings().setValue("network_tracer/display_crs", authid)
        ph = "lon, lat" if authid == "EPSG:4326" else "X, Y"
        for k, le in self.le.items():
            le.setPlaceholderText(ph)
            le.setText(self._fmt(self.points[k]))
            le.setToolTip("WGS84 : %s" % ("%.6f, %.6f" % self.points[k]
                                          if self.points[k] else "-"))

    def _set_copyright(self, layer):
        """Métadonnées de la couche des tracés : réseau source."""
        md = layer.metadata()
        md.setAbstract("Itinéraires calculés par Network Tracer v%s sur le réseau "
                       "« %s »." % (__version__, self._net_names() or "?"))
        layer.setMetadata(md)

    def _coord_attr(self, key):
        return "%s (%s)" % (self.le[key].text(), self.cb_crs.currentData())

    # ------------------------------------------------------------ Réglages
    def settings(self):
        """Réglages du moteur : itinéraire le plus court, tous tronçons utilisables."""
        return dict(enabled=[router.ALL_KEY], speeds={}, factors={}, weight=1.0,
                    tol_m=self.spin_tol.value(),
                    gap_m=self.spin_gap.value() if self.chk_gap.isChecked() else 0,
                    start_bearing=self.spin_dir.value() if self.chk_dir.isChecked() else None,
                    start_toward=self._dir_point if self.chk_dir.isChecked() else None)

    # -------------------------------------------------------- Sélection
    def _start_pick(self, key, reset=False):
        if reset and key in ("start", "end") and self.points[key]:
            # nouveau clic sur Départ / Arrivée : le point déjà placé est retiré
            self._set_point(key, None)
            if key == "start":
                self._remove_arrow()
                self._dir_point = None
        self._picking = key
        cur = self.canvas.mapTool()
        if cur is not self.tool:
            self._prev_tool = cur
        self.canvas.setMapTool(self.tool)
        self.iface.messageBar().pushMessage(
            "Network Tracer",
            "Cliquez sur la carte dans la direction du tronçon" if key == "dir" else
            "Cliquez sur la carte pour le point de %s"
            % ("départ" if key == "start" else "arrivée"), Qgis.MessageLevel.Info, 3)

    def _on_picked(self, pt):
        key = self._picking
        if not key:
            return
        xf = QgsCoordinateTransform(self.canvas.mapSettings().destinationCrs(),
                                    WGS84, QgsProject.instance())
        p = xf.transform(pt)
        if key == "dir":
            if self.points["start"]:
                self.spin_dir.setValue(round(router.bearing_deg(
                    self.points["start"][0], self.points["start"][1], p.x(), p.y())))
                self._dir_point = (p.x(), p.y())   # voie visée par le clic
            else:
                self.iface.messageBar().pushMessage(
                    "Network Tracer", "Placez d'abord le point de départ.",
                    Qgis.MessageLevel.Warning, 3)
        else:
            self._set_point(key, (p.x(), p.y()), pt)
        self._picking = None
        # Clics enchaînés : départ -> (direction) -> arrivée (mode deux points)
        nxt = None
        if key == "start":
            self._chain_end = True
            if self.chk_dir.isChecked():
                nxt = "dir"
            elif self._chain_end:
                nxt = "end"
        elif key == "dir" and getattr(self, "_chain_end", False):
            nxt = "end"
        if key in ("end", "dir") and nxt is None:
            self._chain_end = False
        if nxt:
            if nxt == "end":
                self._chain_end = False
            self._start_pick(nxt)
            return
        if self._prev_tool:
            self.canvas.setMapTool(self._prev_tool)

    def _set_point(self, key, lonlat, map_pt=None):
        self.points[key] = lonlat
        self._mark_dirty()
        self._update_clear_button()
        self._refresh_coords()
        if self.markers[key]:
            self.canvas.scene().removeItem(self.markers[key])
            self.markers[key] = None
        if lonlat is None:
            return
        if map_pt is None:
            xf = QgsCoordinateTransform(WGS84, self.canvas.mapSettings().destinationCrs(),
                                        QgsProject.instance())
            map_pt = xf.transform(QgsPointXY(*lonlat))
        m = PinMarker(self.canvas, START_COLOR if key == "start" else END_COLOR)
        m.setCenter(map_pt)
        self.markers[key] = m
        if key == "start":
            self._arrow_faded = False
            self._update_arrow()

    def _swap(self):
        s, e = self.points["start"], self.points["end"]
        self._set_point("start", e)
        self._set_point("end", s)

    def _clear(self, keep_trace=False):
        self._set_point("start", None)
        self._set_point("end", None)
        self._remove_arrow()
        if not keep_trace:
            self._clear_trace()
        self._dir_point = None
        self._status("")
        self._set_result_html(None)
        self._update_clear_button()
        self._last = None

    def _clear_trace(self):
        """Supprime le trajet de la couche « Itinéraires réseau »."""
        lyr = self.layer
        try:
            if lyr is None or QgsProject.instance().mapLayer(lyr.id()) is None:
                return
            lyr.dataProvider().deleteFeatures([ft.id() for ft in lyr.getFeatures()])
            lyr.triggerRepaint()
        except RuntimeError:   # couche déjà détruite
            pass

    def _route_layer_in_project(self):
        try:
            return self.layer is not None and \
                QgsProject.instance().mapLayer(self.layer.id()) is not None
        except RuntimeError:
            return False

    def _ask_close(self):
        """Choix à la fermeture : 'save', 'delete' ou 'keep'."""
        box = QMessageBox(self)
        box.setWindowTitle("Network Tracer")
        box.setIcon(QMessageBox.Icon.Question)
        box.setText("Que faire de la couche temporaire « %s » ?" % self.layer.name())
        box.setInformativeText(
            "Enregistrer : copie des traces dans un GeoPackage (dossier du projet par "
            "défaut), ajoutée au projet.\nSupprimer : la couche temporaire est retirée.\n"
            "Conserver : la couche temporaire reste dans le projet.")
        b_save = box.addButton("Enregistrer…", QMessageBox.ButtonRole.AcceptRole)
        b_del = box.addButton("Supprimer", QMessageBox.ButtonRole.DestructiveRole)
        box.addButton("Conserver", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(b_save)
        box.exec()
        clicked = box.clickedButton()
        return "save" if clicked is b_save else "delete" if clicked is b_del else "keep"

    def _has_traces(self):
        try:
            return self._route_layer_in_project() and self.layer.featureCount() > 0
        except RuntimeError:
            return False

    def _update_clear_button(self, *_):
        if hasattr(self, "btn_clear"):
            self.btn_clear.setEnabled(
                self._has_traces() or any(self.points.values())
                or bool(self.le_net_filter.expression().strip()))

    def _ask_clear(self, before_run=False):
        """Choix pour les tracés existants : 'save', 'keep', 'delete' ou 'cancel'.
        before_run : posé avant un nouveau calcul (qui remplacerait les tracés)."""
        box = QMessageBox(self)
        box.setWindowTitle("Network Tracer")
        box.setIcon(QMessageBox.Icon.Question)
        n = self.layer.featureCount()
        box.setText(("Un nouveau calcul va remplacer les %d tracé%s affiché%s. Qu'en faire ?"
                     if before_run else "Que faire des %d tracé%s affiché%s ?")
                    % (n, "s" * (n > 1), "s" * (n > 1)))
        box.setInformativeText(
            "Enregistrer : copie dans un GeoPackage (dossier du projet par défaut), "
            "ajoutée au projet.\nConserver : copie dans une couche temporaire séparée, "
            "que les prochains calculs ne remplaceront pas.\nSupprimer : les tracés sont effacés."
            + ("\nAnnuler : le calcul n'est pas lancé." if before_run else ""))
        b_save = box.addButton("Enregistrer…", QMessageBox.ButtonRole.AcceptRole)
        b_keep = box.addButton("Conserver", QMessageBox.ButtonRole.ActionRole)
        b_del = box.addButton("Supprimer", QMessageBox.ButtonRole.DestructiveRole)
        box.addButton("Annuler", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(b_save)
        box.exec()
        c = box.clickedButton()
        return ("save" if c is b_save else "keep" if c is b_keep
                else "delete" if c is b_del else "cancel")

    def _keep_routes(self):
        """Copie les tracés dans une couche mémoire séparée (non remplacée ensuite)."""
        import datetime
        copy = self.layer.materialize(QgsFeatureRequest())
        copy.setName("Itinéraires réseau – conservés %s"
                     % datetime.datetime.now().strftime("%H:%M:%S"))
        copy.setRenderer(self.layer.renderer().clone())
        self._set_copyright(copy)
        QgsProject.instance().addMapLayer(copy)
        return True

    def _on_clear_clicked(self, *_):
        """Effacer : s'il y a des tracés, proposer de les enregistrer / conserver."""
        if self._has_traces():
            choice = self._ask_clear()
            if choice == "cancel":
                return
            if choice == "save" and not self._save_routes():
                return                      # enregistrement annulé : on ne touche à rien
            if choice == "keep":
                self._keep_routes()
        self._clear()
        self._clear_filter()
        self._update_clear_button()

    def _clear_filter(self):
        """Vide la requête (filtre réseau) et le réglage mémorisé."""
        self._net_filter_timer.stop()
        self.le_net_filter.setExpression("")
        QgsSettings().setValue("network_tracer/net_filter", "")

    def _save_routes(self):
        """Enregistre les traces dans un GeoPackage (dossier du projet par défaut) et
        ajoute la couche enregistrée au projet. Retourne True si c'est fait."""
        import datetime
        prj = QgsProject.instance()
        folder = prj.homePath() or os.path.expanduser("~")
        path, _f = QFileDialog.getSaveFileName(
            self, "Enregistrer les itinéraires",
            os.path.join(folder, "itineraires_reseau.gpkg"), "GeoPackage (*.gpkg)")
        if not path:
            return False
        if not path.lower().endswith(".gpkg"):
            path += ".gpkg"
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        lname = "itineraires_%s" % stamp
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = lname
        opts.fileEncoding = "UTF-8"
        if os.path.exists(path):
            opts.actionOnExistingFile = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer
        res = QgsVectorFileWriter.writeAsVectorFormatV3(self.layer, path,
                                                        prj.transformContext(), opts)
        if res[0] != QgsVectorFileWriter.WriterError.NoError:
            QMessageBox.warning(self, "Network Tracer", "Enregistrement impossible :\n%s" % res[1])
            return False
        saved = QgsVectorLayer("%s|layername=%s" % (path, lname),
                               "Itinéraires réseau %s" % stamp.replace("_", " "), "ogr")
        if not saved.isValid():
            QMessageBox.warning(self, "Network Tracer", "Couche enregistrée illisible : %s" % path)
            return False
        saved.setRenderer(self.layer.renderer().clone())
        self._set_copyright(saved)
        prj.addMapLayer(saved)
        self.iface.messageBar().pushMessage(
            "Network Tracer", "Itinéraires enregistrés dans %s (couche %s)" % (path, lname),
            Qgis.MessageLevel.Success, 5)
        return True

    def close_and_clear(self, ask=True):
        """Fermeture du panneau : arrêt du calcul, points, flèche et résultat effacés.
        Choix pour la couche temporaire : enregistrer (GeoPackage, ajouté au projet)
        puis la retirer, la supprimer, ou la conserver."""
        self.stop()
        self._clear_filter()   # la requête (filtre réseau) est vidée à la fermeture
        remove = False
        if ask and self._route_layer_in_project():
            choice = self._ask_close()
            if choice == "save":
                remove = self._save_routes()   # annulé : on garde la couche temporaire
            else:
                remove = choice == "delete"
        self._clear(keep_trace=ask and not remove)
        if remove:
            lid, self.layer = self.layer.id(), None
            QgsProject.instance().removeMapLayer(lid)
        self._update_clear_button()

    def closeEvent(self, e):
        self.close_and_clear()
        super().closeEvent(e)

    # --------------------------------------------------------- Calcul
    def run(self):
        if not self.points["start"] or not self.points["end"]:
            self._status("⚠ Sélectionnez un départ et une arrivée.")
            return
        s = self.settings()
        if not self._net_layers():
            self._status("⚠ Cochez au moins une couche réseau.")
            return
        try:
            lines = self._collect_lines([self.points["start"], self.points["end"]])
        except ValueError as e:
            self._status("⚠ %s" % e)
            return
        qs = QgsSettings()
        qs.setValue("network_tracer/net_selected", self.chk_net_sel.isChecked())
        qs.setValue("network_tracer/tolerance", self.spin_tol.value())
        qs.setValue("network_tracer/gap_on", self.chk_gap.isChecked())
        qs.setValue("network_tracer/gap_m", self.spin_gap.value())
        qs.setValue("network_tracer/color", self.btn_color.color().name())
        qs.setValue("network_tracer/width", self.spin_width.value())
        # Tracés existants : proposer de les enregistrer / conserver avant de les remplacer
        if self._has_traces():
            choice = self._ask_clear(before_run=True)
            if choice == "cancel":
                return
            if choice == "save" and not self._save_routes():
                return
            if choice == "keep":
                self._keep_routes()
        # Les anciens tracés (copiés si Enregistrer / Conserver) sont effacés avant le calcul
        self._clear_trace()
        self._last = None
        self._set_result_html(None)
        self._update_clear_button()
        self._set_running(True)
        self._arrow_faded = False
        self._status("⏳ %d tronçons lus, calcul…" % len(lines))
        self.task = RouteTask(self.points["start"], self.points["end"], s, lines,
                              self._on_done)
        QgsApplication.taskManager().addTask(self.task)

    def _on_done(self, res, error):
        self._set_running(False)
        self.task = None
        if res is None:
            if error is None or "arrêté" in error:
                self._status("⏹ Calcul arrêté.")
            else:
                self._status("❌ " + error)
            return
        self._clear_trace()     # un nouveau calcul remplace le précédent
        self._last = []
        self._feat_cache = {}
        self._sel = None
        self._assign_widths(res["routes"])
        for r in res["routes"]:
            self._add_feature(r)
            self._last.append(r)
        n = len(self._last)
        self._status("✓ %d tracé%s calculé%s – voir l'onglet Résultat"
                     % (n, "s" if n > 1 else "", "s" if n > 1 else ""))
        self._show_result()
        self.tabs.setCurrentIndex(1)
        self._update_clear_button()
        self._dirty = False
        self._update_run_button()
        self._arrow_faded = True
        self._update_arrow()
        self._update_result_map()

    def _restyle(self, *_):
        """Applique en direct couleur et épaisseur (Options) aux tracés affichés."""
        qs = QgsSettings()
        qs.setValue("network_tracer/color", self.btn_color.color().name())
        qs.setValue("network_tracer/width", self.spin_width.value())
        if not getattr(self, "_last", None) or not self._route_layer_in_project():
            return
        lyr = self.layer
        base = self.btn_color.color().name()
        palette = [base] + [c for c in TRACE_PALETTE if c.lower() != base.lower()]
        routes = self._last
        for i, r in enumerate(routes):
            r["color"] = palette[i % len(palette)]
        self._assign_widths(routes)
        fids = sorted(f.id() for f in lyr.getFeatures())
        flds = lyr.fields()
        i_col, i_w, i_off = (flds.indexOf(n) for n in ("couleur", "epaisseur", "decalage"))
        changes = {}
        for fid, r in zip(fids, routes):
            ch = {i_col: r["color"], i_w: r["width"]}
            if i_off >= 0:
                ch[i_off] = r.get("offset", 0.0)
            changes[fid] = ch
        lyr.dataProvider().changeAttributeValues(changes)
        lyr.triggerRepaint()
        self._show_result()
        # carte du résultat : repères recolorés, cadrage et zoom conservés
        for m in self._res_markers:
            self.res_canvas.scene().removeItem(m)
        self._res_markers = []
        if self.points["start"]:
            self._res_pin(self.points["start"], START_COLOR)
        for r in self._last:
            if r["coords"]:
                self._res_pin(r["coords"][-1], END_COLOR)
        self.res_canvas.refreshAllLayers()

    def _assign_widths(self, routes):
        """Tous les tracés gardent un trait fin. Ceux qui empruntent les mêmes
        tronçons sont décalés côte à côte (lignes parallèles) pour rester visibles."""
        base = self.spin_width.value()
        gap = base + 0.15                       # écart entre lignes parallèles (mm)
        segs = []
        for r in routes:
            c = [(round(x, 6), round(y, 6)) for x, y in r["coords"]]
            segs.append({frozenset(p) for p in zip(c, c[1:]) if p[0] != p[1]})
        shared = [i for i in range(len(routes))
                  if any(segs[i] & segs[j] for j in range(len(routes)) if j != i)]
        for r in routes:
            r["width"], r["offset"] = base, 0.0
        n = len(shared)
        for k, i in enumerate(shared):
            routes[i]["offset"] = round((k - (n - 1) / 2.0) * gap, 2)

    @staticmethod
    def _linkify(block, idx):
        """Rend chaque ligne du bloc cliquable (lien route:idx) en gardant sa couleur."""
        def wrap(m):
            col = re.search(r"color:\s*(#[0-9a-fA-F]{6})", m.group(1))
            return ("%s<a href='route:%d'><span style='color:%s'>%s</span></a>%s"
                    % (m.group(1), idx, col.group(1) if col else "#202020",
                       m.group(2), m.group(3)))
        return re.sub(r"(<div[^>]*>)((?:(?!<div|</div>).)*)(</div>)", wrap, block)

    def _on_result_clicked(self, url):
        """Clic sur un tracé de la liste : sélection + clignotement sur les deux cartes."""
        s = url.toString()
        if s.startswith("route:"):
            self._select_route(int(s.split(":")[1]))

    def _on_result_map_clicked(self, pt):
        """Clic sur la carte du résultat : sélection du tracé visé ; si plusieurs
        tracés se superposent à cet endroit, un menu permet de choisir."""
        hits = self._hit_routes(pt)
        if len(hits) == 1:
            self._select_route(hits[0])
        elif hits:
            menu = QMenu(self)
            for i in hits:
                r = self._last[i]
                pix = QPixmap(14, 14)
                pix.fill(QColor(r.get("color", "#888888")))
                act = menu.addAction(QIcon(pix), "%d.  %.2f km" % (
                    i + 1, r["length_m"] / 1000))
                act.triggered.connect(lambda _=False, k=i: self._select_route(k))
            menu.exec(QCursor.pos())

    def _hit_route(self, pt):
        hits = self._hit_routes(pt)
        return hits[0] if hits else None

    def _hit_routes(self, pt):
        """Indices des tracés à moins de 10 px de pt, du plus proche au plus éloigné."""
        if not self._last:
            return []
        xf = QgsCoordinateTransform(WGS84, self.res_canvas.mapSettings().destinationCrs(),
                                    QgsProject.instance())
        click = QgsGeometry.fromPointXY(pt)
        tol = self.res_canvas.mapUnitsPerPixel() * 10
        found = []
        for i, r in enumerate(self._last):
            g = QgsGeometry.fromPolylineXY([QgsPointXY(x, y) for x, y in r["coords"]])
            g.transform(xf)
            dist = g.distance(click)
            if dist <= tol:
                found.append((dist, i))
        return [i for _d, i in sorted(found)]

    def _select_route(self, i):
        """Met le tracé i en évidence dans la liste et le fait clignoter sur les cartes."""
        if not self._last or not 0 <= i < len(self._last):
            return
        self._sel = i
        self._show_result()
        self.txt_result.scrollToAnchor("r%d" % i)
        r = self._last[i]
        for cv in (self.canvas, self.res_canvas):
            self._blink(cv, r["coords"], r.get("color", "#ff0000"))

    def _blink(self, canvas, coords, color, times=4, period=350):
        """Clignotement fin (trait de 1 px) d'un tracé sur une carte."""
        col = QColor(color)
        line = QgsRubberBand(canvas, _line_type())
        line.setToGeometry(QgsGeometry.fromPolylineXY(
            [QgsPointXY(x, y) for x, y in coords]), WGS84)
        line.setStrokeColor(col)
        line.setWidth(1)
        items = [line]
        state = {"n": 0}
        timer = QTimer(self)

        def tick():
            state["n"] += 1
            if state["n"] >= times * 2:
                timer.stop()
                for it in items:
                    canvas.scene().removeItem(it)
                timer.deleteLater()
                return
            for it in items:
                it.setVisible(state["n"] % 2 == 0)

        timer.timeout.connect(tick)
        timer.start(period // 2 if period > 1 else 1)

    def _info(self, key):
        cb = getattr(self, "chk_info", {}).get(key)
        return cb is None or cb.isChecked()

    def _route_html(self, res, rank):
        grey, soft = "#8a8a8a", "#5a5a5a"
        total = res["length_m"] + res["snap_start_m"] + res["snap_end_m"]
        head = ("<span style='font-size:12pt; color:%s'>━━</span>"
                % res.get("color", "#888888"))
        if self._info("dist"):
            head += ("&nbsp;&nbsp;<span style='font-size:12pt; font-weight:300'>%.2f km</span>"
                     % (res["length_m"] / 1000))
        if self._info("total"):
            head += ("<span style='color:%s'>&nbsp;&nbsp;·&nbsp;&nbsp;total "
                     "<span style='color:%s'>%.2f km</span> avec accroches</span>"
                     % (grey, soft, total / 1000))
        if rank is not None:
            head = "<span style='color:%s'>%d.</span>&nbsp;&nbsp;" % (grey, rank) + head
        body = self._ways_html(res)
        if self._info("snap"):
            body += ("<div style='color:%s; font-size:8.5pt'>Accroche au réseau : "
                     "départ %d m%s · arrivée %d m</div>"
                     % (grey, res["snap_start_m"],
                        (" (%s)" % html.escape(res["snap_start_name"]))
                        if res.get("snap_start_name") else "", res["snap_end_m"]))
        return "<div style='margin-bottom:12px'><div>%s</div>%s</div>" % (head, body)

    def _show_result(self):
        if not getattr(self, "_last", None):
            return
        parts = []
        multi = len(self._last) > 1
        for i, r in enumerate(self._last):
            if i:
                parts.append("<hr style='border:0; height:1px; background:#dddddd'>")
            block = self._linkify(self._route_html(r, i + 1 if multi else None), i)
            if i == getattr(self, "_sel", None):   # tracé sélectionné : fond teinté
                tint = QColor(r.get("color", "#888888"))
                tint.setAlpha(28)
                a = tint.alphaF()
                mix = QColor(int(tint.red() * a + 255 * (1 - a)), int(tint.green() * a + 255 * (1 - a)),
                             int(tint.blue() * a + 255 * (1 - a)))
                block = block.replace("<div>", "<div style=''>").replace(
                    "<div style='", "<div style='background-color:%s; " % mix.name())
            parts.append("<a name='r%d'></a>" % i + block)
        self._set_result_html("".join(parts))

    def _status(self, text):
        """Ligne d'état sous les onglets (masquée si vide)."""
        self.lbl_result.setText(text)
        self.lbl_result.setVisible(bool(text))

    def _set_result_html(self, body):
        """Onglet Résultat visible uniquement s'il y a un résultat."""
        self.txt_result.setHtml(body or "")
        self.tabs.setTabVisible(1, bool(body))
        if not body:
            self._clear_result_map()

    def _clear_result_map(self):
        for m in self._res_markers:
            self.res_canvas.scene().removeItem(m)
        self._res_markers = []
        self.res_canvas.setLayers([])

    def _res_pin(self, lonlat, color):
        xf = QgsCoordinateTransform(WGS84, self.res_canvas.mapSettings().destinationCrs(),
                                    QgsProject.instance())
        m = PinMarker(self.res_canvas, color, 22)
        m.setCenter(xf.transform(QgsPointXY(*lonlat)))
        self._res_markers.append(m)

    def _update_result_map(self):
        """Carte du résultat : tracés sur fond OSM, cadrée sur 2× l'emprise des tracés."""
        self._clear_result_map()
        if not self._last:
            return
        crs = QgsCoordinateReferenceSystem("EPSG:3857")
        self.res_canvas.setDestinationCrs(crs)
        self.res_canvas.setCanvasColor(QColor("#f2efe9"))
        if self.osm_bg is None or not self.osm_bg.isValid():
            self.osm_bg = QgsRasterLayer(OSM_XYZ, "OpenStreetMap", "wms")
        route = self.layer if self._route_layer_in_project() else None
        layers = [l for l in (route, self.osm_bg) if l is not None and l.isValid()]
        self.res_canvas.setLayers(layers)
        xf = QgsCoordinateTransform(WGS84, crs, QgsProject.instance())
        box = None
        for r in self._last:
            g = QgsGeometry.fromPolylineXY([QgsPointXY(x, y) for x, y in r["coords"]])
            g.transform(xf)
            bb = g.boundingBox()
            if box is None:
                box = bb
            else:
                box.combineExtentWith(bb)
        if self.points["start"]:
            self._res_pin(self.points["start"], START_COLOR)
        for r in self._last:
            if r["coords"]:
                self._res_pin(r["coords"][-1], END_COLOR)
        self._res_box = box
        QTimer.singleShot(0, self._frame_result_map)
        QTimer.singleShot(0, self._half_split)

    def _half_split(self):
        """Carte du résultat = moitié de la hauteur de l'onglet."""
        h = self.res_split.height()
        if h > 0:
            self.res_split.setSizes([h // 2, h - h // 2])

    def _frame_result_map(self):
        box = getattr(self, "_res_box", None)
        if box is None:
            return
        # Cadrage = 2 × l'emprise des tracés (au moins 300 m de côté)
        ext = QgsRectangle(box)
        ext.scale(2.0)
        c = ext.center()
        ext = QgsRectangle(c.x() - max(ext.width() / 2, 150), c.y() - max(ext.height() / 2, 150),
                           c.x() + max(ext.width() / 2, 150), c.y() + max(ext.height() / 2, 150))
        self.res_canvas.setExtent(ext)
        self.res_canvas.refresh()
        self.res_overlay.update()

    def _set_running(self, running):
        self.btn_run.setEnabled(not running)
        self.btn_stop.setEnabled(running)
        self._update_run_button()

    def stop(self):
        self._remove_arrow()
        if self.task is not None:
            self._status("⏳ Arrêt en cours…")
            self.task.cancel()

    def _route_layer(self):
        if not self._route_layer_in_project():
            self.layer = QgsVectorLayer(
                "LineString?crs=EPSG:4326&field=distance_km:double"
                "&field=depart:string(60)&field=arrivee:string(60)"
                "&field=couleur:string(9)&field=epaisseur:double&field=version:string(10)"
                "&field=source:string(80)&field=distance_tot_km:double"
                "&field=decalage:double",
                "Itinéraires réseau", "memory")
            # Couleur / épaisseur pilotées par les champs : chaque trace garde son style
            sl = self.layer.renderer().symbol().symbolLayer(0)
            prop = getattr(QgsSymbolLayer, "Property", QgsSymbolLayer)
            color_p = getattr(prop, "StrokeColor", None)
            if color_p is None:
                color_p = QgsSymbolLayer.PropertyStrokeColor
            width_p = getattr(prop, "StrokeWidth", None)
            if width_p is None:
                width_p = QgsSymbolLayer.PropertyStrokeWidth
            sl.setDataDefinedProperty(color_p, QgsProperty.fromField("couleur"))
            sl.setDataDefinedProperty(width_p, QgsProperty.fromField("epaisseur"))
            # Tracés superposés : décalage latéral (mm) piloté par le champ « decalage »
            off_p = getattr(prop, "Offset", None)
            if off_p is None:
                off_p = QgsSymbolLayer.PropertyOffset
            sl.setDataDefinedProperty(off_p, QgsProperty.fromExpression('coalesce("decalage", 0)'))
            self._set_copyright(self.layer)
            QgsProject.instance().addMapLayer(self.layer)
            self._refresh_net_list()
        return self.layer

    def _next_color(self, lyr):
        """Couleur de la nouvelle trace : celle du bouton pour la première, puis
        la première couleur de la palette pas encore utilisée dans la couche."""
        used = {str(f["couleur"]).lower() for f in lyr.getFeatures()}
        palette = [self.btn_color.color().name()] + [
            c for c in TRACE_PALETTE if c != self.btn_color.color().name()]
        for c in palette:
            if c.lower() not in used:
                return c
        return palette[len(used) % len(palette)]

    def _add_feature(self, res):
        lyr = self._route_layer()
        # Chaque tracé d'un même calcul a sa couleur (un nouveau calcul remplace tout)
        color = self._next_color(lyr)
        res["color"] = color
        f = QgsFeature(lyr.fields())
        f.setGeometry(QgsGeometry.fromPolylineXY([QgsPointXY(x, y) for x, y in res["coords"]]))
        f.setAttributes([round(res["length_m"] / 1000, 3),
                         self._coord_attr("start"), self._coord_attr("end"),
                         color, res.get("width", self.spin_width.value()), __version__,
                         self._net_names()[:80]]
                        + [None] * (lyr.fields().count() - 7))
        f.setAttribute("distance_tot_km", round(
            (res["length_m"] + res["snap_start_m"] + res["snap_end_m"]) / 1000, 3))
        if lyr.fields().indexOf("decalage") >= 0:
            f.setAttribute("decalage", res.get("offset", 0.0))
        lyr.dataProvider().addFeatures([f])
        lyr.updateExtents()
        lyr.triggerRepaint()

    def show_options(self):
        """Fenêtre Options (non modale) : modifications appliquées immédiatement."""
        self.dlg_options.show()
        self.dlg_options.raise_()
        self.dlg_options.activateWindow()

    def show_help(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Network Tracer – Aide")
        dlg.resize(560, 620)
        v = QVBoxLayout(dlg)
        tb = QTextBrowser()
        tb.setOpenExternalLinks(True)
        tb.setHtml(HELP_HTML.replace("{version}", __version__))
        v.addWidget(tb)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        dlg.exec()

    def cleanup(self):
        # Déchargement (fermeture de QGIS, rechargement) : pas de question
        self.close_and_clear(ask=False)
        for k in ("start", "end"):
            if self.markers[k]:
                self.canvas.scene().removeItem(self.markers[k])
        self._remove_arrow()
        try:
            self.canvas.destinationCrsChanged.disconnect(self._update_arrow)
            self.canvas.scaleChanged.disconnect(self._update_arrow)
            QgsProject.instance().layersAdded.disconnect(self._refresh_net_list)
            QgsProject.instance().layersRemoved.disconnect(self._refresh_net_list)
            self.iface.actionDraw().triggered.disconnect(self._remove_arrow)
        except (TypeError, RuntimeError):
            pass
        if self.canvas.mapTool() is self.tool:
            self.canvas.unsetMapTool(self.tool)
