# Changelog

Format : [Keep a Changelog](https://keepachangelog.com/fr/1.1.0/), versions [SemVer](https://semver.org/lang/fr/).
La version de référence est `version=` dans `metadata.txt`.

## [2.1.1] - 2026-10-22
### Modifié
- Bouton de réinitialisation : vide aussi la **requête** (filtre réseau) ; actif dès qu'il y a un point, un tracé ou un filtre.

## [2.1.0] - 2026-10-22
### Modifié
- Fermeture du panneau : la **requête** (filtre réseau) est vidée.
- Nouveau clic sur **Départ** / **Arrivée** : le point déjà placé est retiré avant d'en pointer un nouveau.
- Bouton **Effacer** remplacé par une icône de réinitialisation (refresh).

## [2.0.0] - 2026-10-18
### Retiré
- **Types de tronçons** : tableau (coche, km/h, préférence), champ **Type** et **Profil**. L'itinéraire est toujours le plus court, sur tous les tronçons retenus (couches, filtre, sélection).
- **Recherche de la destination** : mode « Recherche d'élément(s) dans un rayon » (couches cibles, rayon, filtre, tracés max, cercle), adresse Nominatim et champs `cible_*`.
- Couche « Itinéraires réseau » : champs `profil`, `poids_dist`, `duree_min`, `detail`, `cible_*`. Informations du résultat : nombre d'éléments, durée, détail par type, élément atteint, adresse.

## [1.9.0] - 2026-10-18
### Ajouté
- Groupe Réseau : **Filtre** (expression QGIS) limitant les tronçons utilisables, ex. `"tension" = 'BT'`. Les couches sans les champs utilisés sont exclues ; le tableau des types ne liste que les valeurs des tronçons retenus.

## [1.8.0] - 2026-10-18
### Ajouté
- Options : **Raccorder les lignes mal connectées** + distance (1 m par défaut). Une extrémité libre proche d'une autre ligne y est raccordée (sur un sommet ou en coupant le tronçon) ; les croisements en milieu de ligne ne sont pas connectés.
### Corrigé
- Tolérance de connexion : deux sommets proches situés de part et d'autre d'une limite de cellule n'étaient pas toujours fusionnés.

## [1.7.0] - 2026-10-18
### Modifié
- **Options** sorties du panneau : fenêtre non modale ouverte par un bouton **engrenage** dans la barre de titre, à gauche de l'aide.

## [1.6.0] - 2026-10-17
### Ajouté
- **Informations du résultat** : liste des **champs des couches réseau** cochées. Pour chaque champ choisi, le résultat affiche les valeurs des tronçons parcourus dans l'ordre du trajet, avec leur longueur. Mise à jour en direct, choix mémorisé.

## [1.5.0] - 2026-10-17
### Ajouté
- Groupe repliable **Informations du résultat** : choix des informations affichées pour chaque tracé (nombre d'éléments dans le rayon, distance, durée, total avec accroches, détail par type, élément atteint, adresse, accroche au réseau). Appliqué en direct, choix mémorisé.

## [1.4.0] - 2026-10-17
### Retiré
- Options : cases « Afficher la durée », « Afficher la colonne km/h » et « Afficher la colonne Préférence ». La durée n'est plus affichée dans le résultat (toujours enregistrée dans *duree_min*) ; les colonnes km/h et Préf. sont toujours visibles.

## [1.3.0] - 2026-10-17
### Modifié
- **Options › Trace** : changer la couleur ou l'épaisseur s'applique **en direct** aux tracés affichés (couche, points des éléments atteints, liste et carte du résultat), sans recalcul.

## [1.2.0] - 2026-10-17
### Ajouté
- **Plusieurs couches réseau** : liste à cocher des couches de lignes ; les tronçons se connectent aussi d'une couche à l'autre (sommets communs, à la tolérance près).
- Champ **Type** choisi parmi les champs des couches cochées ; les couches sans ce champ sont classées « (vide) ».

## [1.1.0] - 2026-10-17
### Retiré
- Champs **Nom**, **Sens** et **Vitesse** du groupe Réseau, case **Sens uniques** : le réseau est parcouru dans les deux sens, la vitesse vient du type.

## [1.0.0] - 2026-10-17
### Ajouté
- Version initiale, dérivée d'**OSM Tracer 1.30.0** (mêmes fonctions : deux points, recherche dans un rayon,
  direction de départ, résultat avec carte, enregistrer / conserver / supprimer les tracés).
- Le réseau n'est plus téléchargé depuis OSM (Overpass) : il est lu dans une **couche de lignes choisie**.
- Champs facultatifs de la couche réseau : **Type** (le tableau des types liste ses valeurs),
  **Nom**, **Sens** (sens uniques), **Vitesse** (km/h).
- Option « Uniquement les tronçons sélectionnés », **tolérance de connexion** des sommets.
- Adresse Nominatim désactivable (Options).
### Retiré
- Serveur Overpass, types de voies OSM, RAVeL, case « Motorisé ».
