# -*- coding: utf-8 -*-
# Network Tracer – plugin QGIS
# Copyright (C) 2026 skycrow2 <skycrow2@gmail.com>
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version. See the LICENSE file.
#
# SPDX-License-Identifier: GPL-2.0-or-later
"""Tâche de fond : construction du graphe depuis la couche + calcul d'itinéraire."""
from qgis.core import QgsTask, QgsFeedback, QgsMessageLog, Qgis

from . import router

LOG_TAG = "Network Tracer"


class RouteTask(QgsTask):
    def __init__(self, start, end, settings, lines, on_done):
        """lines : tronçons extraits de la couche (voir router.RoadGraph)."""
        super().__init__("Network Tracer – calcul d'itinéraire", QgsTask.Flag.CanCancel)
        self.start, self.end = start, end
        self.settings = settings
        self.lines = lines
        self.on_done = on_done
        self.result = None
        self.feedback = QgsFeedback()
        self.error = None

    def cancel(self):
        self.feedback.cancel()
        super().cancel()

    def run(self):
        try:
            self.setProgress(10)
            self.result = dict(routes=[router.route(
                self.lines, self.start, self.end, self.settings,
                is_canceled=self.isCanceled)])
            self.setProgress(100)
            return True
        except Exception as e:  # noqa
            self.error = str(e)
            QgsMessageLog.logMessage(self.error, LOG_TAG, Qgis.MessageLevel.Warning)
            return False

    def finished(self, ok):
        self.on_done(self.result if ok else None, self.error)
