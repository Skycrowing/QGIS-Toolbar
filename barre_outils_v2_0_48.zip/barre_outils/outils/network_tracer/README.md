# Network Tracer (plugin QGIS 3.28+ / 4.x)

Installation : Extensions > Installer depuis un ZIP > `network_tracer_vX.Y.Z.zip`.
Version : voir `metadata.txt` et `CHANGELOG.md`. Dérivé d'OSM Tracer 1.30.0.

1. Cliquer l'icône Network Tracer (panneau à droite).
2. Groupe « Réseau » : cocher une ou plusieurs **couches de lignes** (filtre facultatif).
3. « Départ » puis clic sur la carte ; le clic suivant place l'arrivée.
4. « Calculer » : l'itinéraire le plus court est ajouté à la couche mémoire
   « Itinéraires réseau ».

Connexion : deux tronçons sont reliés s'ils partagent un sommet (tolérance réglable
dans Options). Des lignes qui se croisent sans sommet commun ne sont pas connectées.

## Licences
- Plugin : © 2026 skycrow2, GNU GPL v2 ou ultérieure (voir LICENSE).
- Fond de carte du résultat : © contributeurs OpenStreetMap, ODbL 1.0.
