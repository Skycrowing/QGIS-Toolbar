# -*- coding: utf-8 -*-
# Network Tracer – plugin QGIS
# Copyright (C) 2026 skycrow2 <skycrow2@gmail.com>
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version. See the LICENSE file.
#
# SPDX-License-Identifier: GPL-2.0-or-later
import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction


class NetworkTracerPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dock = None
        self.action = None

    def initGui(self):
        icon = QIcon(os.path.join(os.path.dirname(__file__), "icon.svg"))
        self.action = QAction(icon, "Network Tracer", self.iface.mainWindow())
        self.action.setCheckable(True)
        self.action.toggled.connect(self._toggle)
        # Fermeture par l'icône / le menu : le trajet est effacé
        self.action.triggered.connect(
            lambda on: self.dock.close_and_clear() if not on and self.dock else None)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu("Network Tracer", self.action)

    def _toggle(self, on):
        if self.dock is None:
            from .dock import TracerDock
            self.dock = TracerDock(self.iface)
            self.dock.visibilityChanged.connect(self.action.setChecked)
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dock)
        self.dock.setVisible(on)

    def unload(self):
        if self.dock:
            self.dock.cleanup()
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginVectorMenu("Network Tracer", self.action)
