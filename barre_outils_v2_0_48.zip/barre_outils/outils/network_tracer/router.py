# -*- coding: utf-8 -*-
# Network Tracer – plugin QGIS
# Copyright (C) 2026 skycrow2 <skycrow2@gmail.com>
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version. See the LICENSE file.
#
# SPDX-License-Identifier: GPL-2.0-or-later
"""Moteur de routage sur une couche de lignes, indépendant de QGIS (Python pur).

Flux : tronçons (lon, lat) extraits de la couche -> graphe pondéré -> Dijkstra.
Deux tronçons sont connectés lorsqu'ils partagent un sommet (à la tolérance près).
"""
import heapq
import math

ALL_KEY = "__all__"          # type unique quand aucun champ « type » n'est choisi
ALL_LABEL = "Tous les tronçons"
NULL_KEY = "__null__"
NULL_LABEL = "(vide)"
DEFAULT_SPEED = 50

REF_SPEED_KMH = 50.0  # vitesse de référence pour rendre distance et temps comparables

# Profils : poids (0 = rapide, 1 = court)
PROFILES = {
    "Le plus court": dict(weight=1.0),
    "Le plus rapide": dict(weight=0.0),
    "Équilibré": dict(weight=0.5),
}


class RoutingError(Exception):
    pass


class Canceled(RoutingError):
    def __init__(self):
        super().__init__("Calcul arrêté par l'utilisateur.")


def compute_bbox(p1, p2, margin_ratio=0.25, min_margin_deg=0.02):
    """bbox (sud, ouest, nord, est) englobant les deux points (lon, lat)."""
    return compute_bbox_pts([p1, p2], margin_ratio, min_margin_deg)


def compute_bbox_pts(points, margin_ratio=0.25, min_margin_deg=0.02):
    """bbox (sud, ouest, nord, est) englobant une liste de points (lon, lat)."""
    w, e = min(p[0] for p in points), max(p[0] for p in points)
    s, n = min(p[1] for p in points), max(p[1] for p in points)
    mx = max((e - w) * margin_ratio, min_margin_deg)
    my = max((n - s) * margin_ratio, min_margin_deg)
    return (s - my, w - mx, n + my, e + mx)


# ---------------------------------------------------------------------------
# Graphe
# ---------------------------------------------------------------------------
def haversine(lon1, lat1, lon2, lat2):
    r = 6371008.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def bearing_deg(lon1, lat1, lon2, lat2):
    """Azimut (0 = nord, sens horaire) du point 1 vers le point 2."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    x = math.sin(dl) * math.cos(p2)
    y = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(x, y)) + 360.0) % 360.0


def angle_diff(a, b):
    d = abs(a - b) % 360.0
    return min(d, 360.0 - d)


class RoadGraph:
    def __init__(self, lines, settings):
        """lines : liste de dict
            fid    : identifiant de l'entité
            coords : [(lon, lat), ...] WGS84
            key    : type du tronçon (clé du tableau des types)
        settings : dict
            enabled : types utilisables
            speeds  : {type: km/h}
            factors : {type: facteur de préférence (>0, <1 favorise)}
            weight  : 0 (rapide) .. 1 (court)
            tol_m   : tolérance de connexion des sommets (m)
        """
        self.s = settings
        self.coords = {}        # node_id -> (lon, lat)
        self.seg_way = {}       # (a, b) -> (fid, nom)
        self.virt_way = {}      # nœud virtuel -> fid du tronçon qui le porte
        self.adj = {}           # node_id -> [(nbr, cost, length, time, key)]
        self._grid = None
        self._build(lines)

    def _edge_cost(self, length, speed_kmh, factor):
        w = self.s["weight"]
        time_s = length / (speed_kmh / 3.6)
        dist_equiv = length / (REF_SPEED_KMH / 3.6)
        return factor * ((1 - w) * time_s + w * dist_equiv), time_s

    def _build(self, lines):
        enabled = set(self.s["enabled"])
        tol = max(float(self.s.get("tol_m", 0.1)), 1e-4)
        lat0 = None
        for ln in lines:
            if ln["coords"]:
                lat0 = ln["coords"][0][1]
                break
        if lat0 is None:
            raise RoutingError("Aucun tronçon dans la zone.")
        # grille de fusion des sommets proches (tolérance en mètres) ; les cellules
        # voisines sont aussi examinées pour ne pas rater deux sommets à cheval
        ky = 110540.0
        kx = 111320.0 * max(math.cos(math.radians(lat0)), 0.01)
        cy, cx = tol / ky, tol / kx
        cells = {}
        self._n_nodes = 0

        def node(p):
            i, j = int(math.floor(p[0] / cx)), int(math.floor(p[1] / cy))
            best, best_d = None, tol
            for di in (-1, 0, 1):
                for dj in (-1, 0, 1):
                    for n in cells.get((i + di, j + dj), ()):
                        q = self.coords[n]
                        d = math.hypot((q[0] - p[0]) * kx, (q[1] - p[1]) * ky)
                        if d <= best_d:
                            best, best_d = n, d
            if best is not None:
                return best
            self._n_nodes += 1
            n = self._n_nodes
            self.coords[n] = (p[0], p[1])
            cells.setdefault((i, j), []).append(n)
            return n

        for ln in lines:
            key = ln["key"]
            if key not in enabled:
                continue
            speed = max(float(self.s["speeds"].get(key, DEFAULT_SPEED)), 1.0)
            factor = max(float(self.s["factors"].get(key, 1.0)), 0.01)
            nodes = [node(p) for p in ln["coords"]]
            for a, b in zip(nodes, nodes[1:]):
                if a == b:
                    continue
                self.seg_way[(a, b)] = (ln["fid"], "")
                (x1, y1), (x2, y2) = self.coords[a], self.coords[b]
                length = haversine(x1, y1, x2, y2)
                cost, t = self._edge_cost(length, speed, factor)
                self.adj.setdefault(a, [])
                self.adj.setdefault(b, [])
                self.adj[a].append((b, cost, length, t, key))
                self.adj[b].append((a, cost, length, t, key))

        if not self.adj:
            raise RoutingError("Aucun tronçon utilisable dans la zone.")
        gap = float(self.s.get("gap_m", 0) or 0)
        if gap > 0:
            self.n_gap_links = self._close_gaps(gap)

    def _close_gaps(self, gap_m):
        """Raccorde chaque extrémité libre (nœud relié à un seul voisin) au tronçon
        d'une AUTRE entité le plus proche, s'il est à moins de gap_m : sur un nœud
        existant si la projection tombe dessus, sinon en coupant le tronçon.
        Retourne le nombre de raccords créés."""
        grid = self._seg_index()
        k, c = self._k, self.SEG_CELL
        kx, ky = 111320.0 * k, 110540.0
        reach = int(math.ceil(gap_m / ky / c)) + 1
        dangling = [n for n, e in self.adj.items()
                    if n >= 0 and len({v for v, *_ in e}) == 1]
        matches = []
        for n in dangling:
            nbr = self.adj[n][0][0]
            fid = self.way_of(n, nbr)[0]
            lon, lat = self.coords[n]
            ci, cj = int(math.floor(lon * k / c)), int(math.floor(lat / c))
            best, best_d = None, gap_m
            seen = set()
            for i in range(ci - reach, ci + reach + 1):
                for j in range(cj - reach, cj + reach + 1):
                    for a, b in grid.get((i, j), ()):
                        if (a, b) in seen or n in (a, b) or self.way_of(a, b)[0] == fid:
                            continue
                        seen.add((a, b))
                        (ax, ay), (bx, by) = self.coords[a], self.coords[b]
                        dx, dy = (bx - ax) * kx, (by - ay) * ky
                        px, py = (lon - ax) * kx, (lat - ay) * ky
                        l2 = dx * dx + dy * dy
                        t = 0.0 if l2 == 0 else max(0.0, min(1.0, (px * dx + py * dy) / l2))
                        d = math.hypot(px - t * dx, py - t * dy)
                        if d <= best_d:
                            best, best_d = (a, b, t, math.sqrt(l2)), d
            if best is not None:
                nbr = self.adj[n][0]    # tronçon de l'extrémité (coût de référence)
                matches.append((n, nbr, fid, best, best_d))
        if not matches:
            return 0
        # coupe des tronçons visés (plusieurs coupes possibles par tronçon)
        cuts = {}
        snap_m = 0.05
        for idx, (n, nbr, fid, (a, b, t, seg_len), d) in enumerate(matches):
            if t * seg_len <= snap_m:
                matches[idx] = (n, nbr, fid, a, d)
            elif (1 - t) * seg_len <= snap_m:
                matches[idx] = (n, nbr, fid, b, d)
            else:
                cuts.setdefault((a, b), []).append((t, idx))
        for (a, b), lst in cuts.items():
            e_ab, e_ba = self._edge(a, b), self._edge(b, a)
            fid_ab = self.way_of(a, b)[0]
            lst.sort()
            (ax, ay), (bx, by) = self.coords[a], self.coords[b]
            chain = [(0.0, a)]
            for t, idx in lst:
                if t - chain[-1][0] < 1e-9 and chain[-1][1] != a:
                    m = chain[-1][1]
                else:
                    self._n_nodes += 1
                    m = self._n_nodes
                    self.coords[m] = (ax + t * (bx - ax), ay + t * (by - ay))
                    self.adj[m] = []
                    chain.append((t, m))
                mm = matches[idx]
                matches[idx] = (mm[0], mm[1], mm[2], m, mm[4])
            chain.append((1.0, b))
            self.adj[a] = [e for e in self.adj[a] if e[0] != b]
            self.adj[b] = [e for e in self.adj[b] if e[0] != a]
            for (t0, u), (t1, v) in zip(chain, chain[1:]):
                f = t1 - t0
                self.seg_way[(u, v)] = (fid_ab, "")
                for src, dst, e in ((u, v, e_ab), (v, u, e_ba)):
                    if e:
                        _, ec, el, et, key = e
                        self.adj[src].append((dst, ec * f, el * f, et * f, key))
        # liens de raccord (double sens), coût au prorata du tronçon de l'extrémité
        made = 0
        for n, nbr, fid, target, d in matches:
            if target == n or any(e[0] == target for e in self.adj[n]):
                continue
            _, ec, el, et, key = nbr
            r = d / el if el > 0 else 1.0
            self.seg_way[(n, target)] = (fid, "")
            self.adj[n].append((target, ec * r, d, et * r, key))
            self.adj[target].append((n, ec * r, d, et * r, key))
            made += 1
        self._grid = None   # index spatial à reconstruire (tronçons coupés)
        return made

    SEG_CELL = 0.005   # taille des cellules de l'index spatial (degrés)

    def _seg_index(self):
        """Grille régulière : cellule -> tronçons (a, b) qui la traversent."""
        if self._grid is not None:
            return self._grid
        lats = [self.coords[n][1] for n in self.adj if n >= 0]
        self._k = math.cos(math.radians((min(lats) + max(lats)) / 2))
        k, c = self._k, self.SEG_CELL
        grid = {}
        for a, b in self._segments():
            ax, ay = self.coords[a]
            bx, by = self.coords[b]
            i0, i1 = sorted((int(math.floor(ax * k / c)), int(math.floor(bx * k / c))))
            j0, j1 = sorted((int(math.floor(ay / c)), int(math.floor(by / c))))
            for i in range(i0, i1 + 1):
                for j in range(j0, j1 + 1):
                    grid.setdefault((i, j), []).append((a, b))
        keys = list(grid)
        self._grid_ext = (min(x[0] for x in keys), max(x[0] for x in keys),
                          min(x[1] for x in keys), max(x[1] for x in keys))
        self._grid = grid
        return grid

    def nearest_segment(self, lon, lat):
        """Projette le point sur le tronçon le plus proche.
        Retourne (a, b, t, (lon, lat) projeté, distance m)."""
        grid = self._seg_index()
        k, c = self._k, self.SEG_CELL
        ci, cj = int(math.floor(lon * k / c)), int(math.floor(lat / c))
        imin, imax, jmin, jmax = self._grid_ext
        max_r = max(abs(ci - imin), abs(ci - imax), abs(cj - jmin), abs(cj - jmax))
        best, best_d = None, float("inf")
        tested = set()
        r = 0
        while r <= max_r:
            if r == 0:
                cells = [(ci, cj)]
            else:
                cells = [(i, j) for i in range(ci - r, ci + r + 1) for j in (cj - r, cj + r)]
                cells += [(i, j) for j in range(cj - r + 1, cj + r) for i in (ci - r, ci + r)]
            for cell in cells:
                for a, b in grid.get(cell, ()):
                    if (a, b) in tested:
                        continue
                    tested.add((a, b))
                    ax, ay = self.coords[a]
                    bx, by = self.coords[b]
                    dx, dy = (bx - ax) * k, by - ay
                    l2 = dx * dx + dy * dy
                    t = 0.0 if l2 == 0 else max(0.0, min(1.0, (
                        (lon - ax) * k * dx + (lat - ay) * dy) / l2))
                    px, py = ax + t * (bx - ax), ay + t * (by - ay)
                    d = ((px - lon) * k) ** 2 + (py - lat) ** 2
                    if d < best_d:
                        best, best_d = (a, b, t, (px, py)), d
            if best is not None and math.sqrt(best_d) <= r * c:
                break
            r += 1
        a, b, t, p = best
        return a, b, t, p, haversine(lon, lat, p[0], p[1])

    def _segments(self):
        seen = set()
        for a, edges in self.adj.items():
            if a < 0:
                continue
            for b, *_ in edges:
                if b < 0 or (b, a) in seen or (a, b) in seen:
                    continue
                seen.add((a, b))
                yield a, b

    def way_of(self, a, b):
        """(fid, nom) du tronçon a-b (dans un sens ou l'autre)."""
        return self.seg_way.get((a, b)) or self.seg_way.get((b, a)) or (None, "")

    def snap_on_way(self, lon, lat, way_id):
        """Point le plus proche de (lon, lat) sur l'entité way_id."""
        k = math.cos(math.radians(lat))
        best, best_d = None, float("inf")
        for a, b in self._segments():
            if self.way_of(a, b)[0] != way_id:
                continue
            (ax, ay), (bx, by) = self.coords[a], self.coords[b]
            dx, dy = (bx - ax) * k, by - ay
            l2 = dx * dx + dy * dy
            t = 0.0 if l2 == 0 else max(0.0, min(1.0, (
                (lon - ax) * k * dx + (lat - ay) * dy) / l2))
            px, py = ax + t * (bx - ax), ay + t * (by - ay)
            d = ((px - lon) * k) ** 2 + (py - lat) ** 2
            if d < best_d:
                best, best_d = (a, b, t, (px, py)), d
        if best is None:
            return None
        a, b, t, p = best
        return a, b, t, p, haversine(lon, lat, p[0], p[1])

    def snap_directional(self, lon, lat, bearing, toward=None, max_m=3000.0, cone=45.0,
                         min_m=15.0):
        """Accroche dans une direction (voir l'aide). Même format que nearest_segment."""
        if bearing is None:
            return self.nearest_segment(lon, lat)
        if toward is not None:
            ns = self.nearest_segment(*toward)
            if ns[4] <= 60.0:
                snap = self.snap_on_way(lon, lat, self.way_of(ns[0], ns[1])[0])
                if snap is not None:
                    return snap
        kx = 111320.0 * math.cos(math.radians(lat))
        ky = 110540.0
        dx, dy = math.sin(math.radians(bearing)), math.cos(math.radians(bearing))

        def xy(n):
            x, y = self.coords[n]
            return (x - lon) * kx, (y - lat) * ky

        best, best_t = None, max_m
        cone_best, cone_d = None, max_m
        for a, b in self._segments():
            ax, ay = xy(a)
            bx, by = xy(b)
            sx, sy = bx - ax, by - ay
            rxs = dx * sy - dy * sx
            if abs(rxs) > 1e-12:
                t = (ax * sy - ay * sx) / rxs
                u = (ax * dy - ay * dx) / rxs
                if 0 <= u <= 1 and min_m <= t < best_t:
                    best, best_t = (a, b, u), t
            if best is None:
                l2 = sx * sx + sy * sy
                u = 0.0 if l2 == 0 else max(0.0, min(1.0, -(ax * sx + ay * sy) / l2))
                px, py = ax + u * sx, ay + u * sy
                d = math.hypot(px, py)
                if min_m <= d < cone_d and angle_diff(
                        (math.degrees(math.atan2(px, py)) + 360) % 360, bearing) <= cone:
                    cone_best, cone_d = (a, b, u), d
        pick = best or cone_best
        if pick is None:
            return self.nearest_segment(lon, lat)
        a, b, u = pick
        (x1, y1), (x2, y2) = self.coords[a], self.coords[b]
        p = (x1 + u * (x2 - x1), y1 + u * (y2 - y1))
        return a, b, u, p, haversine(lon, lat, p[0], p[1])

    def _edge(self, u, v):
        for e in self.adj.get(u, []):
            if e[0] == v:
                return e
        return None

    def add_virtual(self, vid, snap, is_start):
        """Insère un nœud virtuel sur le tronçon (a, b) au point projeté."""
        a, b, t, p, _ = snap
        self.coords[vid] = p
        self.virt_way[vid] = self.way_of(a, b)[0]
        self.adj.setdefault(vid, [])
        for u, v, frac in ((a, b, t), (b, a, 1 - t)):
            e = self._edge(u, v)
            if not e:
                continue
            _, c, l, tm, key = e
            if is_start:
                r = 1 - frac
                self.adj[vid].append((v, c * r, l * r, tm * r, key))
            else:
                self.adj[u].append((vid, c * frac, l * frac, tm * frac, key))

    def _dijkstra(self, src, dsts, max_found=1, is_canceled=None):
        dist = {src: 0.0}
        prev = {}
        heap = [(0.0, src)]
        remaining = set(dsts)
        found = []
        it = 0
        while heap and remaining and len(found) < max_found:
            it += 1
            if is_canceled and it % 5000 == 0 and is_canceled():
                raise Canceled()
            d, u = heapq.heappop(heap)
            if d > dist.get(u, float("inf")):
                continue
            if u in remaining:
                found.append(u)
                remaining.discard(u)
                continue
            for v, c, length, t, key in self.adj[u]:
                nd = d + c
                if nd < dist.get(v, float("inf")):
                    dist[v] = nd
                    prev[v] = (u, length, t, key)
                    heapq.heappush(heap, (nd, v))
        return found, prev

    def _path(self, src, dst, prev):
        path, length, time_s, per_type = [dst], 0.0, 0.0, {}
        ways = []               # [(fid, longueur m)] du départ vers l'arrivée
        n = dst
        while n != src:
            u, l, t, key = prev[n]
            length += l
            time_s += t
            per_type[key] = per_type.get(key, 0.0) + l
            if u >= 0 and n >= 0:
                fid = self.way_of(u, n)[0]
            else:
                fid = self.virt_way.get(n if n < 0 else u)
            ways.append((fid, l))
            path.append(u)
            n = u
        path.reverse()
        ways.reverse()
        merged = []
        for fid, l in ways:     # tronçons consécutifs de la même entité fusionnés
            if merged and merged[-1][0] == fid:
                merged[-1] = (fid, merged[-1][1] + l)
            elif l > 0:
                merged.append((fid, l))
        return dict(coords=[self.coords[n] for n in path], length_m=length,
                    time_s=time_s, per_type_m=per_type, dst=dst, ways=merged)

    def shortest_path(self, src, dst, is_canceled=None, not_found=None):
        dsts = dst if isinstance(dst, (set, frozenset)) else {dst}
        found, prev = self._dijkstra(src, dsts, 1, is_canceled)
        if not found:
            raise RoutingError(not_found or
                               "Aucun itinéraire trouvé entre les deux points "
                               "(réseau non connecté : vérifiez la topologie de la couche).")
        return self._path(src, found[0], prev)


def _link_same_segment(g, S, ss, T, st):
    """Départ et cible sur le même tronçon : liaison directe si le sens le permet."""
    a, b, ts = ss[0], ss[1], ss[2]
    if {a, b} == {st[0], st[1]}:
        te = st[2] if st[0] == a else 1 - st[2]
        u, v, f = (a, b, te - ts) if te >= ts else (b, a, ts - te)
        e = g._edge(u, v)
        if e:
            g.adj[S].append((T, e[1] * f, e[2] * f, e[3] * f, e[4]))


def route(lines, start, end, settings, is_canceled=None):
    """start/end : (lon, lat) WGS84. Retourne dict résultat."""
    g = RoadGraph(lines, settings)
    ss = g.snap_directional(start[0], start[1], settings.get("start_bearing"),
                            settings.get("start_toward"))
    se = g.nearest_segment(*end)
    S, E = -1, -2
    g.add_virtual(S, ss, True)
    g.add_virtual(E, se, False)
    _link_same_segment(g, S, ss, E, se)
    if is_canceled and is_canceled():
        raise Canceled()
    res = g.shortest_path(S, E, is_canceled)
    res["snap_start_m"], res["snap_end_m"] = ss[4], se[4]
    res["snap_start_name"] = g.way_of(ss[0], ss[1])[1]
    return res
