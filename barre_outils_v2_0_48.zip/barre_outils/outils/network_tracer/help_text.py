# -*- coding: utf-8 -*-
# Network Tracer – plugin QGIS
# Copyright (C) 2026 skycrow2 <skycrow2@gmail.com>
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version. See the LICENSE file.
#
# SPDX-License-Identifier: GPL-2.0-or-later
HELP_HTML = """
<h2>Network Tracer – Aide <small>(v{version})</small></h2>
<p>Calcule un itinéraire entre deux points de la carte sur le réseau formé par une
ou plusieurs <b>couches de lignes</b> du projet (routes, cours d'eau, canalisations, sentiers…).</p>

<h3>1. Réseau</h3>
<ul>
<li><b>Couches</b> : cochez une ou plusieurs couches de lignes servant de réseau. Deux tronçons
sont <b>connectés s'ils partagent un sommet</b>, y compris d'une couche à l'autre (à la <i>tolérance</i> près, réglable dans Options, 0,1 m par défaut).
Des lignes qui se croisent sans sommet commun (pont, tunnel) ne sont pas reliées.</li>
<li><b>Raccorder les lignes mal connectées</b> (Options, désactivé par défaut) : chaque <b>extrémité libre</b>
d'une ligne (bout relié à rien) située à moins de la distance indiquée (1 m par défaut) d'une
<b>autre</b> ligne y est raccordée : sur son sommet le plus proche, ou au point projeté en coupant le tronçon.
Corrige les trous, les lignes qui s'arrêtent juste avant une autre ou la dépassent légèrement.
Les croisements en milieu de ligne (ponts) restent non connectés.</li>
<li>Tous les tronçons sont parcourables dans les deux sens.</li>
<li><b>Filtre</b> (facultatif) : requête QGIS limitant les tronçons utilisables, ex.
<i>"tension" = 'BT'</i> (câbles basse tension uniquement) ou <i>"type" IN ('BT', 'Éclairage')</i>.
Bouton ε : constructeur d'expression. Les couches réseau qui n'ont pas les champs utilisés sont
<b>exclues</b>.</li>
<li><b>Uniquement les tronçons sélectionnés</b> : limite le réseau à la sélection de chaque couche.</li>
<li>Seuls les tronçons situés autour des points (emprise + marge d'au moins ~2 km) sont lus.</li>
</ul>

<h3>2. Choisir les points</h3>
<ul>
<li>Cliquez sur <b>Départ</b> puis sur la carte : le <b>clic suivant</b> place
directement l'arrivée (après la direction si l'option est cochée).</li>
<li>Vous pouvez cliquer <b>à côté du réseau</b> : le point est accroché sur le tronçon utilisable
le plus proche (distance affichée dans le résultat).</li>
<li><b>⇅</b> échange départ et arrivée.</li>
<li><b>Direction du tronçon</b> (option) : si le clic de direction tombe sur un tronçon (à moins de 60 m),
le départ s'accroche à cette entité ; sinon au <b>premier tronçon rencontré dans cette direction</b>,
en ignorant celui sur lequel se trouve le départ (moins de 15 m) (azimut en degrés, 0° = nord,
sens horaire ; à défaut, le plus proche dans un cône de ±45°). Une flèche verte l'indique.</li>
<li><b>Coord.</b> : affichage en WGS84, Lambert 72 ou Lambert 2008 (champs <i>depart</i>/<i>arrivee</i>).</li>
<li>L'itinéraire calculé est le <b>plus court</b> en distance sur les tronçons utilisables.</li>
</ul>

<h3>3. Lancer / arrêter</h3>
<ul>
<li><b>▶ Calculer</b> lit le réseau puis calcule en arrière-plan. <b>■ Arrêter</b> interrompt le calcul.</li>
</ul>

<h3>4. Style et résultat</h3>
<ul>
<li><b>Options</b> (engrenage ⚙ de la barre de titre, à gauche de l'aide) : couleur et épaisseur de la
première trace (appliquées <b>en direct</b> aux tracés affichés), tolérance de connexion, raccord des lignes mal connectées.
La fenêtre peut rester ouverte pendant le travail.</li>
<li><b>Informations du résultat</b> (repliable) : en haut, les <b>champs des couches réseau</b>
cochées ; pour chaque champ coché, le résultat affiche les valeurs des tronçons parcourus, dans l'ordre
du trajet, avec leur longueur (ex. <i>nom : Rue A 0,52 km → Rue B 1,20 km</i>). En dessous, cochez les
informations générales —
distance, total avec accroches, accroche au réseau. Appliqué en direct, sans recalcul.</li>
<li>Les traces vont dans la couche mémoire <b>« Itinéraires réseau »</b> (distance, départ, arrivée,
champ <i>source</i> = couche réseau). Un nouveau calcul <b>remplace</b> les traces ; les tracés superposés
sont décalés côte à côte.</li>
<li>L'onglet <b>Résultat</b> détaille chaque tracé avec une carte sur fond OpenStreetMap ; cliquer sur un
tracé le fait clignoter sur les deux cartes.</li>
<li><b>Effacer</b>, un nouveau calcul ou la fermeture du panneau proposent : <b>Enregistrer…</b>
(GeoPackage), <b>Conserver</b> (couche temporaire séparée), <b>Supprimer</b> ou <b>Annuler</b>.</li>
</ul>

<h3>Limites et conseils</h3>
<ul>
<li>« Aucun itinéraire trouvé » : réseau non connecté. Vérifiez la topologie (sommets communs aux
jonctions), augmentez la tolérance ou activez le raccord des lignes mal connectées.</li>
<li>Couche en coordonnées géographiques ou projetées : indifférent, les distances sont calculées sur l'ellipsoïde.</li>
</ul>

<h3>Droits d'auteur et licences</h3>
<ul>
<li><b>Réseau</b> : les droits sont ceux de la couche que vous utilisez.</li>
<li><b>Fond de carte du résultat</b> : © contributeurs OpenStreetMap,
<a href="https://www.openstreetmap.org/copyright">ODbL 1.0</a>.</li>
<li><b>Plugin</b> : Network Tracer © 2026 skycrow2 – GNU GPL v2 ou ultérieure, dérivé d'OSM Tracer.
Fourni sans aucune garantie.</li>
</ul>
"""
