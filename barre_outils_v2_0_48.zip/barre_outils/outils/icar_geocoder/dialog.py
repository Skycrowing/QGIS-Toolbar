"""Fenêtre de paramétrage du géocodage ICAR."""
import csv
import os
import unicodedata

from qgis.core import (Qgis, QgsApplication, QgsFeatureRequest, QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform, QgsFeature, QgsField, QgsGeometry,
                       QgsCoordinateTransformContext, QgsPointXY, QgsProject,
                       QgsSettings, QgsVectorFileWriter, QgsVectorLayer)
from qgis.gui import QgsFileWidget, QgsScaleWidget
from qgis.PyQt.QtCore import QRectF, QSize, Qt
from qgis.PyQt.QtGui import (QBrush, QColor, QFont, QIcon, QPainter, QPalette,
                             QPixmap)
from qgis.PyQt.QtWidgets import (QAbstractItemView, QButtonGroup, QComboBox, QDialog,
                                 QDialogButtonBox, QFormLayout, QGroupBox, QHBoxLayout,
                                 QHeaderView, QLabel, QLineEdit, QMessageBox,
                                 QProgressBar, QPushButton, QRadioButton, QTableWidget,
                                 QTableWidgetItem, QTabWidget, QToolButton, QVBoxLayout,
                                 QWidget, QFileDialog, QMenu, QSlider)

from .help_dialog import HelpDialog
from .version import plugin_version
from .xlsx_writer import FILLS, PASTEL, score_color, write_xlsx
from .geocoder import PRECISION_RANK, GeocodeTask, IcarClient, split_street_number

NO_FIELD = "— aucun champ —"
OPACITY_KEY = "icar_geocoder/opacity"
COPYRIGHT = "© SPW – Service public de Wallonie · Données ICAR / PICC"
FORMAT_KEY = "icar_geocoder/export_format"
try:  # rôle de données portant la couleur d'une ligne (Qt5/Qt6)
    ROLE_COLOR = Qt.ItemDataRole.UserRole.value + 1
except AttributeError:
    ROLE_COLOR = int(Qt.UserRole) + 1


def _field(name, kind):
    try:
        from qgis.PyQt.QtCore import QVariant
        t = {"str": QVariant.String, "int": QVariant.Int, "dbl": QVariant.Double}[kind]
    except AttributeError:  # Qt6
        from qgis.PyQt.QtCore import QMetaType
        t = {"str": QMetaType.Type.QString, "int": QMetaType.Type.Int,
             "dbl": QMetaType.Type.Double}[kind]
    return QgsField(name, t)


def _norm(s):
    s = unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode().lower()
    return "".join(ch for ch in s if ch.isalnum())


GUESS = {
    "street": ["rue", "street", "straat", "voie", "nomrue"],
    "house": ["num", "numero", "no", "n", "house", "huisnummer", "nr"],
    "city": ["commune", "city", "gemeente", "municipality", "ville"],
    "zone": ["localite", "locality", "cp", "codepostal", "postal", "zone", "postcode", "section"],
    "address": ["adresse", "address", "adres", "rueetnumero"],
}

OUT_FIELDS = [
    ("icar_statut", "str"), ("icar_precision", "str"), ("icar_score", "int"),
    ("icar_score_desc", "str"), ("icar_commune", "str"), ("icar_cp", "str"),
    ("icar_localite", "str"), ("icar_rue", "str"), ("icar_numero", "str"),
    ("icar_id_rue", "str"), ("icar_id_adresse", "str"), ("icar_nb_cand", "int"),
    ("icar_mode", "str"), ("icar_x", "dbl"), ("icar_y", "dbl"), ("icar_message", "str"),
]


def read_csv(path, encoding, delimiter):
    encodings = ["utf-8-sig", "cp1252"] if encoding == "auto" else [encoding]
    last_err = None
    for enc in encodings:
        try:
            with open(path, newline="", encoding=enc) as f:
                sample = f.read(65536)
                f.seek(0)
                delim = delimiter
                if not delim:
                    try:
                        delim = csv.Sniffer().sniff(sample, delimiters=";,\t|").delimiter
                    except csv.Error:
                        delim = ";"
                reader = csv.reader(f, delimiter=delim)
                header = next(reader, [])
                rows = [r for r in reader if any(c.strip() for c in r)]
            break
        except UnicodeDecodeError as e:
            last_err = e
    else:
        raise last_err

    # En-têtes propres et uniques
    clean, seen = [], set()
    for i, h in enumerate(header):
        h = (h or "").strip() or f"champ_{i + 1}"
        base, k = h, 2
        while h.lower() in seen:
            h, k = f"{base}_{k}", k + 1
        seen.add(h.lower())
        clean.append(h)
    n = len(clean)
    rows = [(r + [""] * n)[:n] for r in rows]
    return clean, rows, delim, enc


class FieldPicker(QWidget):
    """Combo de champ + valeur manuelle (utilisée si aucun champ ou cellule vide)."""

    def __init__(self, with_manual=True, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.combo = QComboBox()
        lay.addWidget(self.combo, 1)
        self.manual = None
        if with_manual:
            self.manual = QLineEdit()
            self.manual.setPlaceholderText("valeur manuelle (si pas de champ / cellule vide)")
            lay.addWidget(self.manual, 1)

    def set_fields(self, fields, guess_keys):
        self.combo.clear()
        self.combo.addItem(NO_FIELD)
        self.combo.addItems(fields)
        normed = [_norm(f) for f in fields]
        for key in guess_keys:
            for i, nf in enumerate(normed):
                if nf == key or (len(key) > 2 and nf.startswith(key)):
                    self.combo.setCurrentIndex(i + 1)
                    return

    def restore(self, field_name):
        """Resélectionne un champ par son nom s'il existe toujours."""
        i = self.combo.findText(field_name) if field_name and field_name != NO_FIELD else -1
        if i >= 0:
            self.combo.setCurrentIndex(i)

    def index(self):
        return self.combo.currentIndex() - 1  # -1 = aucun champ

    def value(self, row):
        i = self.index()
        v = row[i].strip() if i >= 0 else ""
        if not v and self.manual is not None:
            v = self.manual.text().strip()
        return v

    def is_set(self):
        return self.index() >= 0 or (self.manual is not None and self.manual.text().strip())


class GeocodeDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.header, self.rows, self.task = [], [], None
        self.last_results, self.out_crs = [], "EPSG:3812"
        self.mem_layer, self.row_fids, self.categories = None, [], []
        self.setWindowTitle(f"Géocodage ICAR (SPW) – v{plugin_version()}")
        self.resize(860, 560)
        # Fenêtre réductible (icônifiable) et agrandissable
        self.setWindowFlags(self.windowFlags()
                            | Qt.WindowType.WindowMinimizeButtonHint
                            | Qt.WindowType.WindowMaximizeButtonHint
                            | Qt.WindowType.WindowCloseButtonHint)
        self._build()

    def _set_opacity(self, value):
        self.setWindowOpacity(value / 100.0)
        self.opacity_lbl.setText(f"Opacité {value} %")
        QgsSettings().setValue(OPACITY_KEY, value)

    def _help_icon(self, size=18):
        """Icône d'aide moderne : pastille pleine (couleur d'accent) et « ? » blanc."""
        dpr = max(1.0, float(self.devicePixelRatioF()))
        pm = QPixmap(int(size * dpr), int(size * dpr))
        pm.setDevicePixelRatio(dpr)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(self.palette().color(QPalette.ColorRole.Highlight))
        p.drawEllipse(QRectF(0.5, 0.5, size - 1, size - 1))
        f = QFont(self.font())
        f.setBold(True)
        f.setPixelSize(int(size * 0.68))
        p.setFont(f)
        p.setPen(QColor("white"))
        p.drawText(QRectF(0, 0, size, size), int(Qt.AlignmentFlag.AlignCenter), "?")
        p.end()
        return QIcon(pm)

    # ------------------------------------------------------------------ UI
    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(6, 6, 6, 6)
        outer.setSpacing(4)
        self.tabs = QTabWidget()
        help_btn = QToolButton()
        help_btn.setIcon(self._help_icon())
        help_btn.setIconSize(QSize(18, 18))
        help_btn.setToolTip("Aide")
        help_btn.setAutoRaise(True)
        help_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        help_btn.setStyleSheet(
            "QToolButton{border:none;border-radius:12px;padding:3px;}"
            "QToolButton:hover{background:rgba(127,127,127,0.18);}"
            "QToolButton:pressed{background:rgba(127,127,127,0.32);}")
        help_btn.clicked.connect(lambda: HelpDialog(self).exec())
        # Opacité de la fenêtre (mémorisée) + aide, dans le coin supérieur droit
        corner = QWidget()
        cl = QHBoxLayout(corner)
        cl.setContentsMargins(0, 0, 2, 0)
        cl.setSpacing(4)
        self.opacity_lbl = QLabel()
        self.opacity_sl = QSlider(Qt.Orientation.Horizontal)
        self.opacity_sl.setRange(30, 100)
        self.opacity_sl.setFixedWidth(90)
        self.opacity_sl.setToolTip("Opacité de la fenêtre (rendre translucide)")
        try:
            op = int(QgsSettings().value(OPACITY_KEY, 100))
        except (TypeError, ValueError):
            op = 100
        self.opacity_sl.valueChanged.connect(self._set_opacity)
        self.opacity_sl.setValue(max(30, min(100, op)))
        self._set_opacity(self.opacity_sl.value())
        cl.addWidget(self.opacity_lbl)
        cl.addWidget(self.opacity_sl)
        cl.addWidget(help_btn)
        self.tabs.setCornerWidget(corner)  # coin supérieur droit par défaut
        outer.addWidget(self.tabs, 1)
        page = QWidget()
        main = QVBoxLayout(page)
        main.setContentsMargins(4, 4, 4, 4)
        main.setSpacing(4)
        self.tabs.addTab(page, "Paramètres")
        self.result_tabs = []

        # Fichier
        g_file = QGroupBox("Fichier CSV")
        f = QFormLayout(g_file)
        self.file_w = QgsFileWidget()
        self.file_w.setFilter("CSV (*.csv *.txt);;Tous (*.*)")
        self.enc_cb = QComboBox()
        self.enc_cb.addItem("Auto (UTF-8 puis Windows-1252)", "auto")
        for label, enc in (("UTF-8", "utf-8-sig"), ("Windows-1252", "cp1252"), ("ISO-8859-1", "latin-1")):
            self.enc_cb.addItem(label, enc)
        self.delim_cb = QComboBox()
        for label, d in (("Auto", ""), ("; (point-virgule)", ";"), (", (virgule)", ","),
                         ("Tabulation", "\t"), ("| (barre)", "|")):
            self.delim_cb.addItem(label, d)
        self.info_lbl = QLabel("")
        enc_row = QHBoxLayout()
        enc_row.setSpacing(8)
        enc_row.addWidget(self.enc_cb, 1)
        enc_row.addSpacing(16)
        enc_row.addWidget(QLabel("Séparateur"))
        enc_row.addWidget(self.delim_cb, 1)
        f.addRow("Fichier", self.file_w)
        f.addRow("Encodage", enc_row)
        f.addRow(self.info_lbl)
        self.preview = QTableWidget(0, 0)
        self.preview.setMaximumHeight(95)
        self.preview.verticalHeader().setDefaultSectionSize(20)
        self.preview.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive
                                                             if hasattr(QHeaderView, "ResizeMode")
                                                             else QHeaderView.Interactive)
        f.addRow(self.preview)
        main.addWidget(g_file)

        # Mode
        g_mode = QGroupBox("Structure de l'adresse")
        v = QVBoxLayout(g_mode)
        v.setSpacing(2)
        self.rb_sep = QRadioButton("Champs séparés : rue + n°")
        self.rb_one = QRadioButton("Champ unique : « rue n° »")
        self.rb_sep.setChecked(True)
        grp = QButtonGroup(self)
        grp.addButton(self.rb_sep)
        grp.addButton(self.rb_one)
        rb_row = QHBoxLayout()
        rb_row.addWidget(self.rb_sep)
        rb_row.addWidget(self.rb_one)
        rb_row.addStretch()
        v.addLayout(rb_row)
        self.sep_w = QWidget()
        fs = QFormLayout(self.sep_w)
        fs.setContentsMargins(0, 0, 0, 0)
        fs.setVerticalSpacing(2)
        self.street_p = FieldPicker(with_manual=False)
        self.house_p = FieldPicker(with_manual=False)
        fs.addRow("Rue", self.street_p)
        fs.addRow("N°", self.house_p)
        v.addWidget(self.sep_w)
        self.one_w = QWidget()
        fo = QFormLayout(self.one_w)
        fo.setContentsMargins(0, 0, 0, 0)
        self.addr_p = FieldPicker(with_manual=False)
        fo.addRow("Rue + n°", self.addr_p)
        v.addWidget(self.one_w)

        loc_w = QWidget()
        fl = QFormLayout(loc_w)
        fl.setContentsMargins(0, 2, 0, 0)
        fl.setVerticalSpacing(2)
        self.city_p = FieldPicker()
        self.zone_p = FieldPicker()
        fl.addRow("Commune", self.city_p)
        fl.addRow("Localité / CP", self.zone_p)
        v.addWidget(loc_w)
        main.addWidget(g_mode)

        # Options
        g_opt = QGroupBox("Options")
        fo2 = QFormLayout(g_opt)
        self.crs_cb = QComboBox()
        for c, label in (("EPSG:31370", "EPSG:31370 (Lambert 72)"),
                         ("EPSG:3812", "EPSG:3812 (Lambert 2008)"),
                         ("EPSG:4326", "EPSG:4326 (WGS 84)"),
                         ("EPSG:3857", "EPSG:3857 (Pseudo-Mercator)")):
            self.crs_cb.addItem(label, c)
        self.crs_cb.setCurrentIndex(self.crs_cb.findData("EPSG:3812"))  # Lambert 2008 par défaut
        self.nap_cb = QComboBox()
        for label, val in (("Aucune (n° exact ou voisin uniquement)", "none"),
                           ("N° le plus proche", "closest"),
                           ("Centroïde du segment de rue", "centroid"),
                           ("Position aléatoire sur la rue", "random")):
            self.nap_cb.addItem(label, val)
        self.nap_cb.setCurrentIndex(self.nap_cb.findData("closest"))  # n° le plus proche par défaut
        self.min_cb = QComboBox()
        for label, val in (("Adresse exacte", "adresse"), ("Adresse voisine", "adresse voisine"),
                           ("Rue", "rue"), ("Commune", "commune")):
            self.min_cb.addItem(label, val)
        self.min_cb.setCurrentIndex(2)
        self.name_le = QLineEdit("adresses_geocodees")
        fo2.setVerticalSpacing(2)
        r1 = QHBoxLayout()
        r1.setSpacing(8)
        r1.addWidget(self.crs_cb)
        r1.addSpacing(16)
        r1.addWidget(QLabel("N° introuvable"))
        r1.addWidget(self.nap_cb, 1)
        r2 = QHBoxLayout()
        r2.setSpacing(8)
        r2.addWidget(self.min_cb)
        r2.addSpacing(16)
        r2.addWidget(QLabel("Nom de la couche"))
        r2.addWidget(self.name_le, 1)
        w = max(self.crs_cb.sizeHint().width(), self.min_cb.sizeHint().width())
        self.crs_cb.setMinimumWidth(w)
        self.min_cb.setMinimumWidth(w)
        fo2.addRow("SCR de sortie", r1)
        fo2.addRow("Précision min.", r2)
        main.addWidget(g_opt)

        # Sortie
        g_out = QGroupBox("Sortie")
        vo = QHBoxLayout(g_out)
        self.rb_tmp = QRadioButton("Couche temporaire")
        self.rb_file = QRadioButton("Fichier :")
        self.rb_tmp.setChecked(True)
        grp2 = QButtonGroup(self)
        grp2.addButton(self.rb_tmp)
        grp2.addButton(self.rb_file)
        vo.addWidget(self.rb_tmp)
        hl = vo
        hl.addWidget(self.rb_file)
        self.out_w = QgsFileWidget()
        self.out_w.setStorageMode(QgsFileWidget.StorageMode.SaveFile
                                  if hasattr(QgsFileWidget, "StorageMode") else QgsFileWidget.SaveFile)
        self.out_w.setFilter("GeoPackage (*.gpkg);;Shapefile (*.shp);;GeoJSON (*.geojson)")
        self.out_w.setEnabled(False)
        hl.addWidget(self.out_w, 1)
        self.rb_file.toggled.connect(self.out_w.setEnabled)
        main.addWidget(g_out)

        # Progression + boutons
        self.progress = QProgressBar()
        self.progress.setValue(0)
        main.addStretch()
        # Filtres des onglets de résultats
        self.filter_w = QWidget()
        fr = QHBoxLayout(self.filter_w)
        fr.setContentsMargins(0, 0, 0, 0)
        fr.addWidget(QLabel("Filtrer :"))
        self.filter_le = QLineEdit()
        self.filter_le.setPlaceholderText("texte recherché…")
        self.filter_le.setClearButtonEnabled(True)
        self.filter_col_cb = QComboBox()
        self.filter_col_cb.addItem("Toutes les colonnes", -1)
        self.filter_color_cb = QComboBox()
        for label, key in (("Toutes couleurs", "*"), ("Vert", "green"), ("Jaune", "yellow"),
                           ("Orange", "orange"), ("Rouge", "red"), ("Sans couleur", "")):
            self.filter_color_cb.addItem(label, key)
        self.filter_count = QLabel("")
        clear_btn = QPushButton("Effacer")
        fr.addWidget(self.filter_le, 1)
        fr.addWidget(QLabel("dans"))
        fr.addWidget(self.filter_col_cb)
        fr.addWidget(self.filter_color_cb)
        fr.addWidget(clear_btn)
        fr.addWidget(self.filter_count)
        self.filter_w.setVisible(False)
        self.filter_le.textChanged.connect(lambda *_: self._apply_filter())
        self.filter_col_cb.currentIndexChanged.connect(lambda *_: self._apply_filter())
        self.filter_color_cb.currentIndexChanged.connect(lambda *_: self._apply_filter())
        clear_btn.clicked.connect(self._clear_filter)
        self.tabs.currentChanged.connect(lambda *_: self._apply_filter())
        outer.addWidget(self.filter_w)
        zoom_row = QHBoxLayout()
        zoom_row.addWidget(QLabel("Zoom sur la ligne sélectionnée à l'échelle"))
        self.scale_w = QgsScaleWidget()
        self.scale_w.setMapCanvas(self.iface.mapCanvas())
        self.scale_w.setScale(2000)
        self.scale_w.scaleChanged.connect(lambda *_: self._zoom_current())
        zoom_row.addWidget(self.scale_w)
        zoom_row.addStretch()
        outer.addLayout(zoom_row)
        outer.addWidget(self.progress)
        self.result_lbl = QLabel("")
        self.result_lbl.setWordWrap(True)
        outer.addWidget(self.result_lbl)
        self.run_btn = QPushButton("Géocoder")
        self.export_btn = QPushButton("Exporter…")
        self.export_btn.setEnabled(False)
        if hasattr(self, "fmt_cb"):
            self.fmt_cb.setEnabled(False)
        menu = QMenu(self.export_btn)
        self.act_exp_tab = menu.addAction("Onglet courant…")
        self.act_exp_all = menu.addAction("Tous les résultats…")
        self.act_exp_tab.triggered.connect(lambda: self.export_results(current_only=True))
        self.act_exp_all.triggered.connect(lambda: self.export_results(current_only=False))
        self.export_btn.setMenu(menu)
        self.cancel_btn = QPushButton("Annuler")
        self.cancel_btn.setEnabled(False)
        close_btn = QPushButton("Fermer")
        self.reset_btn = QPushButton("Réinitialiser")
        self.reset_btn.setToolTip("Tout remettre à zéro : fichier, champs, options et résultats\n"
                                  "(les couches déjà ajoutées à la carte sont conservées)")
        btn_row = QHBoxLayout()
        for b in (self.run_btn, self.cancel_btn, self.reset_btn, close_btn):
            btn_row.addWidget(b)
        btn_row.addStretch()
        # Format d'export choisi explicitement (Excel par défaut, mémorisé)
        self.fmt_cb = QComboBox()
        for flt, ext, _, _ in self.FORMATS:
            self.fmt_cb.addItem(flt.split(" (")[0] + f" ({ext})", ext)
        saved = QgsSettings().value(FORMAT_KEY, ".xlsx")
        self.fmt_cb.setCurrentIndex(max(0, self.fmt_cb.findData(saved)))
        self.fmt_cb.currentIndexChanged.connect(
            lambda _i: QgsSettings().setValue(FORMAT_KEY, self.fmt_cb.currentData()))
        self.fmt_cb.setEnabled(False)
        btn_row.addWidget(QLabel("Format :"))
        btn_row.addWidget(self.fmt_cb)
        btn_row.addWidget(self.export_btn)  # en bas à droite
        outer.addLayout(btn_row)
        copyright_lbl = QLabel(COPYRIGHT)
        copyright_lbl.setStyleSheet("color: gray; font-size: 8pt;")
        copyright_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)
        outer.addWidget(copyright_lbl)

        # Signaux
        self.file_w.fileChanged.connect(self.load_csv)
        self.enc_cb.currentIndexChanged.connect(self.load_csv)
        self.delim_cb.currentIndexChanged.connect(self.load_csv)
        self.rb_sep.toggled.connect(self._update_mode)
        self.run_btn.clicked.connect(self.start)
        self.cancel_btn.clicked.connect(self.cancel)
        close_btn.clicked.connect(self.close)
        self.reset_btn.clicked.connect(self.reset_all)
        self._update_mode()

    def _update_mode(self):
        sep = self.rb_sep.isChecked()
        self.sep_w.setEnabled(sep)
        self.one_w.setEnabled(not sep)

    # ------------------------------------------------------------- lecture
    def load_csv(self, *_):
        path = self.file_w.filePath()
        if not path or not os.path.isfile(path):
            return
        try:
            self.header, self.rows, delim, enc = read_csv(
                path, self.enc_cb.currentData(), self.delim_cb.currentData())
        except Exception as e:
            self.info_lbl.setText(f"<span style='color:#c00'>Lecture impossible : {e}</span>")
            self.header, self.rows = [], []
            return
        dname = {"\t": "tabulation"}.get(delim, delim)
        self.info_lbl.setText(f"{len(self.rows)} lignes · {len(self.header)} champs · "
                              f"séparateur « {dname} » · encodage {enc}")
        for picker, key in ((self.street_p, "street"), (self.house_p, "house"),
                            (self.addr_p, "address"), (self.city_p, "city"), (self.zone_p, "zone")):
            picker.set_fields(self.header, GUESS[key])
        if self.addr_p.index() >= 0 and self.street_p.index() < 0:
            self.rb_one.setChecked(True)
        self.preview.clear()
        self.preview.setColumnCount(len(self.header))
        self.preview.setHorizontalHeaderLabels(self.header)
        sample = self.rows[:5]
        self.preview.setRowCount(len(sample))
        for r, row in enumerate(sample):
            for c, val in enumerate(row):
                self.preview.setItem(r, c, QTableWidgetItem(val))

    # ----------------------------------------------------------- géocodage
    def _inputs(self):
        sep = self.rb_sep.isChecked()
        out = []
        for row in self.rows:
            if sep:
                street, house = self.street_p.value(row), self.house_p.value(row)
            else:
                street, house = split_street_number(self.addr_p.value(row))
            out.append({"street": street, "house": house,
                        "city": self.city_p.value(row), "zone": self.zone_p.value(row)})
        return out

    def _reload_source(self):
        """Relit le CSV source (modifié entre-temps ?) en conservant les
        champs choisis et le mode d'adresse."""
        path = self.file_w.filePath()
        if not path or not os.path.isfile(path):
            return
        pickers = (self.street_p, self.house_p, self.addr_p, self.city_p, self.zone_p)
        chosen = [p.combo.currentText() for p in pickers]
        one = self.rb_one.isChecked()
        self.load_csv()
        for p, name in zip(pickers, chosen):
            p.restore(name)
        (self.rb_one if one else self.rb_sep).setChecked(True)

    def reset_all(self):
        if self.task is not None:
            return
        if QMessageBox.question(self, "ICAR", "Tout réinitialiser (fichier, champs, options, résultats) ?") \
                != QMessageBox.StandardButton.Yes:
            return
        self.file_w.blockSignals(True)
        self.file_w.setFilePath("")
        self.file_w.blockSignals(False)
        self.header, self.rows = [], []
        self.info_lbl.setText("")
        self.preview.clear()
        self.preview.setRowCount(0)
        self.preview.setColumnCount(0)
        for p in (self.street_p, self.house_p, self.addr_p, self.city_p, self.zone_p):
            p.set_fields([], [])
            if p.manual is not None:
                p.manual.clear()
        for cb in (self.enc_cb, self.delim_cb):
            cb.blockSignals(True)
            cb.setCurrentIndex(0)
            cb.blockSignals(False)
        self.rb_sep.setChecked(True)
        self.crs_cb.setCurrentIndex(self.crs_cb.findData("EPSG:3812"))
        self.nap_cb.setCurrentIndex(self.nap_cb.findData("closest"))
        self.min_cb.setCurrentIndex(2)
        self.name_le.setText("adresses_geocodees")
        self.rb_tmp.setChecked(True)
        self.out_w.setFilePath("")
        self._clear_result_tabs()
        self.mem_layer, self.row_fids, self.categories, self.last_results = None, [], [], []
        self.progress.setValue(0)
        self.result_lbl.setText("")
        self.export_btn.setEnabled(False)
        self.fmt_cb.setEnabled(False)
        self._clear_filter()
        self.tabs.setCurrentIndex(0)

    def start(self):
        self._reload_source()  # prendre en compte un CSV modifié depuis son chargement
        if not self.rows:
            QMessageBox.warning(self, "ICAR", "Aucune donnée : choisissez un CSV.")
            return
        if self.rb_sep.isChecked() and self.street_p.index() < 0:
            QMessageBox.warning(self, "ICAR", "Choisissez le champ « Rue ».")
            return
        if self.rb_one.isChecked() and self.addr_p.index() < 0:
            QMessageBox.warning(self, "ICAR", "Choisissez le champ « Rue + n° ».")
            return
        if not (self.city_p.is_set() or self.zone_p.is_set()):
            QMessageBox.warning(self, "ICAR", "Indiquez au moins une commune ou une localité "
                                              "(champ ou valeur manuelle).")
            return
        if self.rb_file.isChecked() and not self.out_w.filePath().strip():
            QMessageBox.warning(self, "ICAR", "Choisissez le fichier de sortie.")
            return
        self.out_crs = self.crs_cb.currentData()
        self.last_results = []
        client = IcarClient(crs=self.crs_cb.currentData(), nap=self.nap_cb.currentData())
        self.task = GeocodeTask(self._inputs(), client, self._done)
        self.task.progressChanged.connect(lambda p: self.progress.setValue(int(p)))
        self.run_btn.setEnabled(False)
        self.reset_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.progress.setValue(0)
        self.result_lbl.setText("Géocodage en cours…")
        self._clear_result_tabs()
        self.export_btn.setEnabled(False)
        if hasattr(self, "fmt_cb"):
            self.fmt_cb.setEnabled(False)
        QgsApplication.taskManager().addTask(self.task)

    def cancel(self):
        if self.task:
            self.task.cancel()

    def _done(self, ok, results, error, canceled):
        self.run_btn.setEnabled(True)
        self.reset_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.task = None
        bar = self.iface.messageBar()
        if not ok:
            msg = error or ("Géocodage annulé." if canceled else "Échec du géocodage.")
            bar.pushMessage("ICAR", msg, level=Qgis.Warning if canceled else Qgis.Critical)
            return
        layer, stats = self._build_layer(results)
        self.mem_layer = layer
        n = len(results)
        out_name = layer.name()
        out_path = self.out_w.filePath().strip()
        if self.rb_file.isChecked() and os.path.splitext(out_path)[1].lower() not in (".shp", ".geojson", ".json"):
            # GeoPackage : une table par type de résultat, regroupées dans un groupe
            layers = self._save_gpkg_tables(out_path)
            if not layers:
                return
            project = QgsProject.instance()
            group = project.layerTreeRoot().insertGroup(0, out_name)
            for lyr in layers:
                project.addMapLayer(lyr, False)
                group.addLayer(lyr)
        else:
            if self.rb_file.isChecked():
                layer = self._save(layer)
                if layer is None:
                    return
            QgsProject.instance().addMapLayer(layer)

        pct = (100.0 * stats["placed"] / n) if n else 0
        summary = (f"<b>{stats['placed']} / {n} éléments géocodés ({pct:.0f} %)</b><br>"
                   f"adresse exacte : {stats['exact']} · adresse voisine : {stats['near']} · "
                   f"rue : {stats['street']} · commune : {stats['city']}<br>"
                   f"sous la précision min. : {stats['below']} · non trouvés : {stats['missing']} · "
                   f"erreurs : {stats['error']}")
        self.result_lbl.setText(summary)
        self.last_results = results
        self._build_result_tabs(results, stats)
        self.export_btn.setEnabled(True)
        self.fmt_cb.setEnabled(True)
        bar.pushMessage("ICAR", f"{stats['placed']}/{n} éléments géocodés ({pct:.0f} %) – "
                                f"sortie « {out_name} »",
                        level=Qgis.Success, duration=10)

    CATS = [("exact", "Adresse exacte"), ("near", "Adresse voisine"), ("street", "Rue"),
            ("city", "Commune"), ("below", "Sous précision min."), ("missing", "Non trouvés"),
            ("error", "Erreurs")]
    TAB_ICAR = [("statut", "icar_statut"), ("score", "icar_score"), ("score_desc", "icar_score_desc"),
                ("commune", "icar_commune"), ("cp", "icar_cp"), ("rue", "icar_rue"),
                ("numero", "icar_numero"), ("message", "icar_message")]

    def _clear_filter(self):
        for w in (self.filter_le, self.filter_col_cb, self.filter_color_cb):
            w.blockSignals(True)
        self.filter_le.clear()
        self.filter_col_cb.setCurrentIndex(0)
        self.filter_color_cb.setCurrentIndex(0)
        for w in (self.filter_le, self.filter_col_cb, self.filter_color_cb):
            w.blockSignals(False)
        self._apply_filter()

    def _apply_filter(self):
        """Masque les lignes de l'onglet courant ne correspondant pas au filtre
        (texte, colonne, couleur). L'export ne reprend que les lignes visibles."""
        t = self.tabs.currentWidget()
        is_res = t in getattr(self, "result_tabs", [])
        self.filter_w.setVisible(is_res)
        if not is_res:
            return
        text = self.filter_le.text().strip().lower()
        col = self.filter_col_cb.currentData()
        color = self.filter_color_cb.currentData()
        shown = 0
        for r in range(t.rowCount()):
            ok = True
            if color != "*":
                it0 = t.item(r, 0)
                ok = (it0.data(ROLE_COLOR) or "") == color if it0 is not None else False
            if ok and text:
                cols = range(t.columnCount()) if col is None or col < 0 else [col]
                ok = any(t.item(r, c) is not None and text in t.item(r, c).text().lower() for c in cols)
            t.setRowHidden(r, not ok)
            shown += ok
        self.filter_count.setText(f"{shown} / {t.rowCount()}")

    def _clear_result_tabs(self):
        for w in self.result_tabs:
            i = self.tabs.indexOf(w)
            if i >= 0:
                self.tabs.removeTab(i)
            w.deleteLater()
        self.result_tabs = []

    def _build_result_tabs(self, results, stats):
        self._clear_result_tabs()
        self._tab_cats = {}
        cols = ["ligne"] + list(self.header) + [c for _, c in self.TAB_ICAR]
        edit_none = (QAbstractItemView.EditTrigger.NoEditTriggers
                     if hasattr(QAbstractItemView, "EditTrigger") else QAbstractItemView.NoEditTriggers)
        sel_rows = (QAbstractItemView.SelectionBehavior.SelectRows
                    if hasattr(QAbstractItemView, "SelectionBehavior") else QAbstractItemView.SelectRows)
        single = (QAbstractItemView.SelectionMode.SingleSelection
                  if hasattr(QAbstractItemView, "SelectionMode") else QAbstractItemView.SingleSelection)
        try:
            role_disp = Qt.ItemDataRole.DisplayRole
        except AttributeError:
            role_disp = Qt.DisplayRole
        role_user = getattr(Qt, "UserRole", None) or Qt.ItemDataRole.UserRole
        for key, label in self.CATS:
            idx = [i for i, c in enumerate(self.categories) if c == key]
            if not idx:  # pas d'onglet pour les valeurs à zéro
                continue
            t = QTableWidget(len(idx), len(cols))
            t.setHorizontalHeaderLabels(cols)
            t.setEditTriggers(edit_none)
            t.setSelectionBehavior(sel_rows)
            t.setSelectionMode(single)
            t.verticalHeader().setVisible(False)
            t.verticalHeader().setDefaultSectionSize(20)
            t.setSortingEnabled(False)
            for r, i in enumerate(idx):
                it = QTableWidgetItem()
                it.setData(role_disp, i + 1)      # n° de ligne CSV (tri numérique)
                it.setData(role_user, i)          # index interne
                t.setItem(r, 0, it)
                vals = list(self.rows[i]) + [results[i].get(k) for k, _ in self.TAB_ICAR]
                for c, v in enumerate(vals, start=1):
                    t.setItem(r, c, QTableWidgetItem("" if v is None else str(v)))
                color = score_color(results[i].get("score"))
                it.setData(ROLE_COLOR, color or "")
                if color:  # mêmes règles que l'export Excel, en pastel
                    bg, fg = QBrush(QColor(PASTEL[color])), QBrush(QColor("#000000"))
                    for c in range(len(cols)):
                        cell = t.item(r, c)
                        cell.setBackground(bg)
                        cell.setForeground(fg)
            t.setSortingEnabled(True)
            t.resizeColumnsToContents()
            t.itemSelectionChanged.connect(self._zoom_current)
            self.tabs.addTab(t, f"{label} ({len(idx)})")
            self._tab_cats[t] = (key, label)
            self.result_tabs.append(t)
        self.filter_col_cb.blockSignals(True)
        while self.filter_col_cb.count() > 1:
            self.filter_col_cb.removeItem(1)
        for c, name in enumerate(cols):
            self.filter_col_cb.addItem(name, c)
        self.filter_col_cb.blockSignals(False)
        self._clear_filter()
        if self.result_tabs:
            self.tabs.setCurrentWidget(self.result_tabs[0])

    def _zoom_current(self):
        t = self.tabs.currentWidget()
        if t not in self.result_tabs or t.currentRow() < 0 or not t.selectedItems():
            return
        item = t.item(t.currentRow(), 0)
        if item is None:
            return
        role_user = getattr(Qt, "UserRole", None) or Qt.ItemDataRole.UserRole
        i = item.data(role_user)
        if i is None or i >= len(self.last_results):
            return
        res = self.last_results[i]
        x, y = res.get("x"), res.get("y")
        if x is None or y is None:
            self.iface.statusBarIface().showMessage(
                f"Ligne {i + 1} : pas de coordonnées à afficher", 4000)
            return
        canvas = self.iface.mapCanvas()
        src = QgsCoordinateReferenceSystem(self.out_crs)
        dst = canvas.mapSettings().destinationCrs()
        try:
            pt = QgsCoordinateTransform(src, dst, QgsProject.instance()).transform(QgsPointXY(x, y))
        except Exception as e:
            self.iface.statusBarIface().showMessage(f"Transformation impossible : {e}", 4000)
            return
        canvas.setCenter(pt)
        canvas.zoomScale(self.scale_w.scale())
        canvas.refresh()
        canvas.flashGeometries([QgsGeometry.fromPointXY(QgsPointXY(x, y))], src)

    FORMATS = [  # (filtre, extension, driver, options de couche)
        ("GeoPackage (*.gpkg)", ".gpkg", "GPKG", []),
        ("Shapefile (*.shp)", ".shp", "ESRI Shapefile", []),
        ("GeoJSON (*.geojson)", ".geojson", "GeoJSON", []),
        ("CSV avec X/Y (*.csv)", ".csv", "CSV", ["GEOMETRY=AS_XY", "SEPARATOR=SEMICOLON"]),
        ("Excel (*.xlsx)", ".xlsx", "XLSX", []),
        ("LibreOffice Calc (*.ods)", ".ods", "ODS", []),
        ("KML – Google Earth (*.kml)", ".kml", "KML", []),
    ]

    def _write(self, layer, path, name, ext=None, append=False):
        """Écrit la couche ; renvoie (chemin, erreur ou None)."""
        fmts = {f[1]: f for f in self.FORMATS}
        ext = ext or os.path.splitext(path)[1].lower()
        if ext == ".json":
            ext = ".geojson"
        if ext not in fmts:
            ext = ".gpkg"
        if not path.lower().endswith(ext) and not (ext == ".geojson" and path.lower().endswith(".json")):
            path += ext
        _, _, driver, lopts = fmts[ext]
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = driver
        opts.fileEncoding = "UTF-8"
        opts.layerName = name
        opts.layerOptions = list(lopts)
        if driver == "KML":
            opts.ct = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:4326"),
                                             QgsProject.instance())
        if (append or ext == ".gpkg") and os.path.exists(path):
            act = getattr(QgsVectorFileWriter, "CreateOrOverwriteLayer", None)
            if act is None:
                act = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer
            opts.actionOnExistingFile = act
        res = QgsVectorFileWriter.writeAsVectorFormatV3(layer, path, QgsCoordinateTransformContext(), opts)
        no_err = getattr(QgsVectorFileWriter, "NoError", None)
        if no_err is None:
            no_err = QgsVectorFileWriter.WriterError.NoError
        if res[0] != no_err:
            return path, (res[1] if len(res) > 1 else str(res[0]))
        return path, None

    def _save(self, mem_layer):
        name = self.name_le.text().strip() or "adresses_geocodees"
        path, err = self._write(mem_layer, self.out_w.filePath().strip(), name)
        if err:
            self.result_lbl.setText(f"<span style='color:#c00'>Écriture impossible : {err}</span>")
            QMessageBox.critical(self, "ICAR", f"Écriture impossible :\n{err}")
            return None
        uri = f"{path}|layername={name}" if path.lower().endswith(".gpkg") else path
        layer = QgsVectorLayer(uri, name, "ogr")
        if not layer.isValid():
            QMessageBox.critical(self, "ICAR", f"Fichier écrit mais illisible : {path}")
            return None
        return layer

    def _save_gpkg_tables(self, path):
        """Écrit un GeoPackage avec une table par type de résultat
        (Adresse exacte, Rue, Non trouvés…) ; renvoie les couches lues."""
        if not path.lower().endswith(".gpkg"):
            path += ".gpkg"
        base = self.name_le.text().strip() or "adresses_geocodees"
        if os.path.exists(path):
            # Supprimer uniquement les tables de résultats d'un précédent
            # géocodage du même nom ; toutes les autres tables sont conservées.
            own = {f"{base}_{self._slug(lbl)}" for _, lbl in self.CATS}
            try:
                from osgeo import ogr
                ds = ogr.Open(path, 1)
                if ds is not None:
                    for i in reversed(range(ds.GetLayerCount())):
                        tn = ds.GetLayerByIndex(i).GetName()
                        if tn in own:
                            ds.DeleteLayer(i)
                    ds = None
            except Exception as e:
                QMessageBox.critical(self, "ICAR", f"GeoPackage inaccessible (ouvert ailleurs ?) :\n{e}")
                return None
        layers, errors = [], []
        for key, label in self.CATS:
            idx = [i for i, c in enumerate(self.categories) if c == key]
            if not idx:
                continue
            table = f"{base}_{self._slug(label)}"
            sub = self._sub_layer(idx, table)
            _, err = self._write(sub, path, table, ".gpkg", append=True)
            if err:
                errors.append(f"{label} : {err}")
                continue
            lyr = QgsVectorLayer(f"{path}|layername={table}", label, "ogr")
            if lyr.isValid():
                layers.append(lyr)
        if errors:
            QMessageBox.warning(self, "ICAR", "Écriture partielle :\n" + "\n".join(errors))
        if not layers:
            self.result_lbl.setText("<span style='color:#c00'>Écriture du GeoPackage impossible.</span>")
        return layers

    MULTI_LAYER = (".gpkg", ".xlsx", ".ods")  # un fichier, une couche/feuille par onglet

    def _tab_indexes(self, t):
        """Index des lignes CSV dans l'ordre affiché de l'onglet (tri compris)."""
        try:
            role_user = Qt.ItemDataRole.UserRole
        except AttributeError:
            role_user = Qt.UserRole
        out = []
        for r in range(t.rowCount()):
            if t.isRowHidden(r):  # lignes masquées par le filtre : non exportées
                continue
            it = t.item(r, 0)
            if it is not None and it.data(role_user) is not None:
                out.append(int(it.data(role_user)))
        return out

    def _sub_layer(self, idx, name):
        """Couche mémoire avec les lignes idx, dans cet ordre."""
        src = self.mem_layer
        sub = QgsVectorLayer(f"Point?crs={src.crs().authid()}", name, "memory")
        sub.dataProvider().addAttributes(src.fields().toList())
        sub.updateFields()
        fids = [self.row_fids[i] for i in idx]
        by_id = {f.id(): f for f in src.getFeatures(QgsFeatureRequest().setFilterFids(fids))}
        feats = []
        for fid in fids:
            f = by_id.get(fid)
            if f is not None:
                nf = QgsFeature(sub.fields())
                nf.setAttributes(f.attributes())
                if f.hasGeometry():
                    nf.setGeometry(f.geometry())
                feats.append(nf)
        sub.dataProvider().addFeatures(feats)
        sub.updateExtents()
        return sub

    @staticmethod
    def _slug(text):
        return "".join(ch if ch.isalnum() else "_" for ch in text.lower()).strip("_")

    def export_results(self, current_only=True):
        if self.mem_layer is None or not self.row_fids or not self.result_tabs:
            QMessageBox.warning(self, "ICAR", "Aucun résultat à exporter.")
            return
        base = self.name_le.text().strip() or "adresses_geocodees"
        if current_only:
            t = self.tabs.currentWidget()
            if t not in self.result_tabs:
                QMessageBox.information(self, "ICAR", "Sélectionnez d'abord un onglet de résultats.")
                return
            tabs = [t]
            default = f"{base}_{self._slug(self._tab_cats[t][1])}"
            title = f"Exporter l'onglet « {self._tab_cats[t][1]} »"
        else:
            tabs = list(self.result_tabs)
            default = base
            title = "Exporter tous les onglets"

        ext = self.fmt_cb.currentData() or ".xlsx"
        flt = next(f[0] for f in self.FORMATS if f[1] == ext)
        start_dir = os.path.dirname(self.file_w.filePath() or "")
        path, _ = QFileDialog.getSaveFileName(
            self, f"{title} – {self.fmt_cb.currentText()}",
            os.path.join(start_dir, default + ext), flt)
        if not path:
            return
        root = path[:-len(ext)] if path.lower().endswith(ext) else path

        if ext == ".xlsx":
            self._export_xlsx(tabs, root + ext)
            return

        written, errors, total = [], [], 0
        multi = ext in self.MULTI_LAYER and len(tabs) > 1
        for n, t in enumerate(tabs):
            label = self._tab_cats[t][1]
            idx = self._tab_indexes(t)
            if not idx:
                continue
            layer_name = label.replace(".", "")[:31] if len(tabs) > 1 else (
                f"{base}_{self._slug(label)}" if current_only else base)
            sub = self._sub_layer(idx, layer_name)
            if multi:
                target = root + ext
                out, err = self._write(sub, target, layer_name, ext, append=n > 0)
                if err and n > 0:  # pilote sans ajout de couche : fichier séparé
                    out, err = self._write(sub, f"{root}_{self._slug(label)}{ext}", layer_name, ext)
            elif len(tabs) > 1:
                out, err = self._write(sub, f"{root}_{self._slug(label)}{ext}", layer_name, ext)
            else:
                out, err = self._write(sub, root + ext, layer_name, ext)
            if err:
                errors.append(f"{label} : {err}")
            else:
                total += len(idx)
                if out not in written:
                    written.append(out)
        if errors:
            QMessageBox.warning(self, "ICAR", "Export partiel :\n" + "\n".join(errors))
        if written:
            files = ", ".join(os.path.basename(w) for w in written)
            self.iface.messageBar().pushMessage(
                "ICAR", f"{total} éléments exportés ({len(tabs)} onglet(s)) → {files}",
                level=Qgis.Success, duration=10)

    def _export_xlsx(self, tabs, path):
        """Excel : une feuille par type de résultat, lignes colorées selon
        le score ICAR, plus une feuille de légende."""
        fields = self.mem_layer.fields()
        headers = [f.name() for f in fields]
        score_i = next((i for i in range(len(headers) - 1, -1, -1)
                        if headers[i].lstrip("_") == "icar_score"), -1)
        by_id = {f.id(): f for f in self.mem_layer.getFeatures()}
        sheets, total = [], 0
        for t in tabs:
            idx = self._tab_indexes(t)
            if not idx:
                continue
            rows, colors = [], []
            for i in idx:
                f = by_id.get(self.row_fids[i])
                if f is None:
                    continue
                vals = [None if (v is None or (hasattr(v, "isNull") and v.isNull())) else v
                        for v in f.attributes()]
                color = None
                if score_i >= 0 and vals[score_i] is not None:
                    color = score_color(vals[score_i])
                    vals[score_i] = str(int(vals[score_i])).zfill(3)  # garder « 011 »
                rows.append(vals)
                colors.append(color)
            total += len(rows)
            sheets.append((self._tab_cats[t][1], headers, rows, colors))
        sheets.append(("Légende", ["Couleur", "Règle (score ICAR)"],
                       [["", FILLS[k][1]] for k in ("green", "yellow", "orange", "red")],
                       ["green", "yellow", "orange", "red"]))
        try:
            write_xlsx(path, sheets)
        except OSError as e:
            QMessageBox.critical(self, "ICAR", f"Écriture impossible :\n{e}")
            return
        self.iface.messageBar().pushMessage(
            "ICAR", f"{total} éléments exportés ({len(sheets) - 1} feuille(s)) → {os.path.basename(path)}",
            level=Qgis.Success, duration=10)

    def _build_layer(self, results):
        crs = self.crs_cb.currentData()
        layer = QgsVectorLayer(f"Point?crs={crs}", self.name_le.text().strip() or "adresses_geocodees",
                               "memory")
        pr = layer.dataProvider()
        taken = {h.lower() for h in self.header}
        out_names = []
        for name, _ in OUT_FIELDS:
            n = name
            while n.lower() in taken:
                n = "_" + n
            taken.add(n.lower())
            out_names.append(n)
        fields = [_field(h, "str") for h in self.header]
        fields += [_field(n, k) for n, (_, k) in zip(out_names, OUT_FIELDS)]
        pr.addAttributes(fields)
        layer.updateFields()

        min_rank = PRECISION_RANK[self.min_cb.currentData()]
        self.categories = []
        stats = {"placed": 0, "exact": 0, "near": 0, "street": 0, "city": 0,
                 "below": 0, "missing": 0, "error": 0}
        prec_key = {"adresse": "exact", "adresse voisine": "near", "rue": "street", "commune": "city"}
        feats = []
        for row, res in zip(self.rows, results):
            ft = QgsFeature(layer.fields())
            prec = res.get("precision", "aucune")
            x, y = res.get("x"), res.get("y")
            if x is not None and PRECISION_RANK.get(prec, 0) >= min_rank:
                ft.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
                stats["placed"] += 1
                stats[prec_key[prec]] += 1
                cat = prec_key[prec]
            elif x is not None:
                stats["below"] += 1
                cat = "below"
            elif res.get("statut") == "erreur":
                cat = "error"
            else:
                cat = "missing"
            self.categories.append(cat)
            if res.get("statut") == "erreur":
                stats["error"] += 1
            elif res.get("statut") != "trouvé":
                stats["missing"] += 1
            vals = {
                "icar_statut": res.get("statut"), "icar_precision": prec,
                "icar_score": int(res["score"]) if str(res.get("score", "")).isdigit() else None,
                "icar_score_desc": res.get("score_desc"), "icar_commune": res.get("commune"),
                "icar_cp": res.get("cp"), "icar_localite": res.get("localite"),
                "icar_rue": res.get("rue"), "icar_numero": res.get("numero"),
                "icar_id_rue": res.get("id_rue"), "icar_id_adresse": res.get("id_adresse"),
                "icar_nb_cand": res.get("nb_candidats"), "icar_mode": res.get("mode"),
                "icar_x": x, "icar_y": y, "icar_message": res.get("message"),
            }
            attrs = list(row)
            for name, _ in OUT_FIELDS:
                v = vals[name]
                attrs.append(str(v) if name in ("icar_cp", "icar_id_rue", "icar_id_adresse")
                             and v is not None else v)
            ft.setAttributes(attrs)
            feats.append(ft)
        ok_add, added = pr.addFeatures(feats)
        self.row_fids = [f.id() for f in added] if ok_add else []
        layer.updateExtents()
        return layer, stats

    def closeEvent(self, e):
        if self.task:
            self.task.cancel()
        super().closeEvent(e)
