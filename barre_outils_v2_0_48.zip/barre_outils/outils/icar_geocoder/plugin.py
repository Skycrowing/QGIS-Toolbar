import os

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

MENU = "&ICAR Géocodeur"


class IcarGeocoderPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.help_action = None
        self.dlg = None

    def initGui(self):
        icon = QIcon(os.path.join(os.path.dirname(__file__), "icon.png"))
        self.action = QAction(icon, "Géocoder un CSV (ICAR – SPW)…", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu(MENU, self.action)
        self.iface.addToolBarIcon(self.action)
        self.help_action = QAction("Aide", self.iface.mainWindow())
        self.help_action.triggered.connect(self.show_help)
        self.iface.addPluginToMenu(MENU, self.help_action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu(MENU, self.action)
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu(MENU, self.help_action)
        if self.dlg:
            self.dlg.close()
            self.dlg = None

    def run(self):
        if self.dlg is None:
            from .dialog import GeocodeDialog
            self.dlg = GeocodeDialog(self.iface, self.iface.mainWindow())
        if self.dlg.isMinimized():
            self.dlg.showNormal()  # restaurer une fenêtre icônifiée
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()

    def show_help(self):
        from .help_dialog import HelpDialog
        HelpDialog(self.iface.mainWindow()).exec()
