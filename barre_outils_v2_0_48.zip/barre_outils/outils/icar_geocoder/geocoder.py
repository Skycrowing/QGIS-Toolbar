"""Client du service de géocodage ICAR du SPW (geocodeWS) et tâche de fond."""
import json
import re
from urllib.parse import quote, urlencode

from qgis.core import QgsBlockingNetworkRequest, QgsTask
from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtNetwork import QNetworkRequest

BASE_URL = "https://geoservices.wallonie.be/geocodeWS"

try:
    _NO_ERROR = QgsBlockingNetworkRequest.ErrorCode.NoError
except AttributeError:  # QGIS 3 / PyQt5
    _NO_ERROR = QgsBlockingNetworkRequest.NoError


class IcarError(Exception):
    pass


# --------------------------------------------------------------------------
# Découpage local "rue + n°"
# --------------------------------------------------------------------------
_BOX = re.compile(r"[\s,]*(?:bte|bt\.|boite|boîte|bus|box)\.?\s*[A-Za-z0-9]+\s*$", re.I)
_NUM = r"\d+(?:\s?[A-Za-z]{1,2}\b)?(?:\s*[/\-]\s*[A-Za-z0-9]+)?"
_NUM_END = re.compile(r"^(?P<street>.*?\D)[\s,]+(?P<num>" + _NUM + r")\s*$")
_NUM_START = re.compile(r"^\s*(?P<num>" + _NUM + r")[\s,]+(?P<street>\D.*)$")


def split_street_number(text):
    """'Rue de l'Ange 10 bte 2' -> ('Rue de l'Ange', '10'). Retourne (rue, n°)."""
    t = (text or "").strip().rstrip(",")
    t = _BOX.sub("", t).strip()
    m = _NUM_END.match(t)
    if m:
        return m.group("street").strip(" ,"), m.group("num").replace(" ", "")
    m = _NUM_START.match(t)
    if m:
        return m.group("street").strip(" ,"), m.group("num").replace(" ", "")
    return t, ""


# --------------------------------------------------------------------------
# Interprétation du score ICAR (code à 3 chiffres)
# --------------------------------------------------------------------------
_CITY = {0: "commune non trouvée", 1: "commune exacte", 2: "commune approx. (Levenshtein)",
         3: "commune approx. (phonétique)", 8: "commune via identifiant"}
_STREET = {0: "rue non trouvée", 1: "rue exacte", 2: "rue approx. (Levenshtein)",
           3: "rue approx. (phonétique)", 8: "rue via identifiant"}
_HOUSE = {0: "n° non trouvé", 1: "n° exact", 2: "n° trouvé après nettoyage",
          3: "n° voisin (±2/±4)", 4: "n° voisin, côté opposé probable",
          5: "n° alloué aléatoirement sur la rue", 6: "centroïde du segment de rue",
          8: "n° via identifiant"}


def score_digits(score):
    try:
        s = str(int(score)).zfill(3)
        return int(s[-3]), int(s[-2]), int(s[-1])
    except (TypeError, ValueError):
        return None


def describe_score(score):
    d = score_digits(score)
    if not d:
        return ""
    c, s, h = d
    return " ; ".join([_CITY.get(c, f"commune code {c}"),
                       _STREET.get(s, f"rue code {s}"),
                       _HOUSE.get(h, f"n° code {h}")])


def precision_from(score, level_with_geom):
    d = score_digits(score)
    if d:
        c, s, h = d
        if h in (1, 2, 8):
            return "adresse"
        if h in (3, 4):
            return "adresse voisine"
        if s:
            return "rue"
        if c:
            return "commune"
    return level_with_geom or "aucune"


PRECISION_RANK = {"adresse": 4, "adresse voisine": 3, "rue": 2, "commune": 1, "aucune": 0}


# --------------------------------------------------------------------------
# Client
# --------------------------------------------------------------------------
class IcarClient:
    def __init__(self, crs="EPSG:31370", nap="none", lang=""):
        self.crs = crs
        self.nap = nap
        self.lang = lang
        self._cache = {}

    def _get(self, endpoint, params):
        key = (endpoint, tuple(sorted(params.items())))
        if key in self._cache:
            return self._cache[key]
        url = f"{BASE_URL}/{endpoint}?{urlencode(params, quote_via=quote)}"
        req = QNetworkRequest(QUrl.fromEncoded(url.encode("ascii")))
        req.setRawHeader(b"Accept", b"application/json")
        br = QgsBlockingNetworkRequest()
        if br.get(req) != _NO_ERROR:
            raise IcarError(br.errorMessage())
        try:
            data = json.loads(bytes(br.reply().content()).decode("utf-8"))
        except ValueError as e:
            raise IcarError(f"Réponse non JSON : {e}")
        self._cache[key] = data
        return data

    def city_from_zone(self, zone):
        """Localité (nom ou code postal) -> nom de commune via /geolist."""
        res = self._get("geolist", {"zone": zone})
        for c in res.get("candidates") or []:
            name = (c.get("city") or {}).get("name")
            if name:
                return name
        return ""

    def geocode(self, street="", house="", city="", zone=""):
        street, house = (street or "").strip(), (house or "").strip()
        city, zone = (city or "").strip(), (zone or "").strip()

        if not city and zone:
            city = self.city_from_zone(zone)

        attempts = []
        if city:
            p = {"city": city}
            if street:
                p["street"] = street
                if house:
                    p["house"] = house
            if zone:
                attempts.append(("composantes", dict(p, zone=zone)))
            attempts.append(("composantes", p))
        if street:
            loc = " ".join(x for x in (zone, city) if x)
            if loc:
                attempts.append(("texte libre", {"address": f"{street} {house}".strip() + ", " + loc}))

        if not attempts:
            return {"statut": "non trouvé", "message": "commune/localité manquante"}

        base = {"geom": "true", "bbox": "true", "crs": self.crs, "nap": self.nap}
        if self.lang:
            base["lang"] = self.lang

        fallback = None
        for mode, p in attempts:
            res = self._get("geocode", dict(base, **p))
            cands = res.get("candidates") or []
            if not cands:
                continue
            out = self._parse(cands[0], len(cands), mode)
            d = score_digits(out.get("score"))
            # Rue demandée mais non trouvée : on garde en réserve et on essaie la suite
            if street and d and d[1] == 0:
                fallback = fallback or out
                continue
            return out
        return fallback or {"statut": "non trouvé", "message": "aucun candidat"}

    @staticmethod
    def _point(obj):
        if not obj:
            return None
        g = obj.get("geometry")
        if g:
            if g.get("type") == "Point":
                return tuple(g["coordinates"][:2])
            try:
                from osgeo import ogr
                geom = ogr.CreateGeometryFromJson(json.dumps(g))
                if geom:
                    c = geom.Centroid()
                    return c.GetX(), c.GetY()
            except Exception:
                pass
        bb = obj.get("bbox")
        if bb and len(bb) >= 4:
            return (bb[0] + bb[2]) / 2.0, (bb[1] + bb[3]) / 2.0
        return None

    def _parse(self, c, n, mode):
        pt, level = None, None
        for key, lvl in (("house", "adresse"), ("street", "rue"), ("zone", "commune"), ("city", "commune")):
            pt = self._point(c.get(key))
            if pt:
                level = lvl
                break
        score = c.get("score")
        return {
            "statut": "trouvé" if pt else "sans coordonnées",
            "score": score,
            "score_desc": describe_score(score),
            "precision": precision_from(score, level) if pt else "aucune",
            "commune": (c.get("city") or {}).get("name"),
            "cp": (c.get("zone") or {}).get("ident"),
            "localite": (c.get("zone") or {}).get("name"),
            "rue": (c.get("street") or {}).get("name"),
            "numero": (c.get("house") or {}).get("name"),
            "id_rue": (c.get("street") or {}).get("ident"),
            "id_adresse": (c.get("house") or {}).get("ident"),
            "nb_candidats": n,
            "mode": mode,
            "x": pt[0] if pt else None,
            "y": pt[1] if pt else None,
        }


# --------------------------------------------------------------------------
# Tâche de fond
# --------------------------------------------------------------------------
class GeocodeTask(QgsTask):
    def __init__(self, inputs, client, on_done):
        super().__init__("Géocodage ICAR", QgsTask.CanCancel)
        self.inputs = inputs
        self.client = client
        self.on_done = on_done
        self.results = []
        self.error = None

    def run(self):
        n = len(self.inputs) or 1
        consecutive_errors = 0
        for i, args in enumerate(self.inputs):
            if self.isCanceled():
                return False
            try:
                res = self.client.geocode(**args)
                consecutive_errors = 0
            except Exception as e:  # réseau, JSON…
                res = {"statut": "erreur", "message": str(e)}
                consecutive_errors += 1
                if consecutive_errors >= 5 and i == consecutive_errors - 1:
                    self.error = f"Service injoignable : {e}"
                    return False
            self.results.append(res)
            self.setProgress(100.0 * (i + 1) / n)
        return True

    def finished(self, ok):
        self.on_done(ok, self.results, self.error, self.isCanceled())
