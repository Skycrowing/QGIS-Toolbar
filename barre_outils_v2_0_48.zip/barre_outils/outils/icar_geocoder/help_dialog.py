import os

from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox, QTextBrowser, QVBoxLayout

from .version import plugin_version


class HelpDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Aide – ICAR Géocodeur v{plugin_version()}")
        self.resize(700, 650)
        lay = QVBoxLayout(self)
        tb = QTextBrowser()
        tb.setOpenExternalLinks(True)
        path = os.path.join(os.path.dirname(__file__), "help", "index.html")
        with open(path, encoding="utf-8") as f:
            html = f.read().replace("{{VERSION}}", plugin_version())
        tb.setSearchPaths([os.path.dirname(path)])
        tb.setHtml(html)
        lay.addWidget(tb)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close
                              if hasattr(QDialogButtonBox, "StandardButton")
                              else QDialogButtonBox.Close)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
