def classFactory(iface):
    from .plugin import IcarGeocoderPlugin
    return IcarGeocoderPlugin(iface)
