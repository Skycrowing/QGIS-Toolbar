"""Écriture XLSX minimale (sans dépendance) : une feuille par onglet,
en-tête en gras figé avec filtre, lignes colorées selon le score ICAR."""
import re
import zipfile
from xml.sax.saxutils import escape

from .geocoder import score_digits

# clé couleur -> (ARGB fond, libellé)
FILLS = {
    "green": ("FFC6EFCE", "Score 111"),
    "yellow": ("FFFFEB9C", "Contient un 2 (n° ou commune, ex. 112)"),
    "orange": ("FFF8CBAD", "Contient un 3 ou un 4, ou rue approx. (ex. 121)"),
    "red": ("FFFFC7CE", "Rue non trouvée ou au moins deux 0"),
}
# Versions pastel pour les onglets de résultats de la fenêtre
PASTEL = {"green": "#E6F4EA", "yellow": "#FFF8DC", "orange": "#FDEBDD", "red": "#FDE7E9"}
_FILL_ORDER = ["green", "yellow", "orange", "red"]
_ILLEGAL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def score_color(score):
    """Score ICAR = (commune, rue, n°). Par ordre de priorité :
    rouge  : rue non trouvée (x0x) ou au moins deux 0 ;
    orange : un 3 ou un 4, ou rue approximative (x2x, ex. 121) ;
    jaune  : un 2 ailleurs (ex. 112, 211) ;
    vert   : 111 ; autre ou pas de score : aucune couleur."""
    d = score_digits(score)
    if not d:
        return None
    c, s, h = d
    if s == 0 or d.count(0) >= 2:
        return "red"
    if 3 in d or 4 in d or s == 2:
        return "orange"
    if 2 in d:
        return "yellow"
    if d == (1, 1, 1):
        return "green"
    return None


def _col(n):
    s = ""
    n += 1
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def _sheet_name(name, used):
    base = re.sub(r"[\[\]:*?/\\]", "_", name or "Feuille").strip("'")[:31] or "Feuille"
    out, i = base, 2
    while out.lower() in used:
        suffix = f" ({i})"
        out = base[:31 - len(suffix)] + suffix
        i += 1
    used.add(out.lower())
    return out


def _cell(ref, value, style):
    s = f' s="{style}"' if style else ""
    if value is None or value == "":
        return f'<c r="{ref}"{s}/>' if style else ""
    if isinstance(value, bool):
        value = str(value)
    if isinstance(value, (int, float)):
        return f'<c r="{ref}"{s}><v>{value}</v></c>'
    text = escape(_ILLEGAL.sub("", str(value)))
    return f'<c r="{ref}"{s} t="inlineStr"><is><t xml:space="preserve">{text}</t></is></c>'


def _sheet_xml(headers, rows, colors):
    ncols = len(headers)
    widths = [min(max(len(str(h)), 6) + 2, 60) for h in headers]
    for row in rows[:500]:
        for c, v in enumerate(row[:ncols]):
            if v is not None:
                widths[c] = min(max(widths[c], len(str(v)) + 2), 60)
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
           '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" '
           'activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>', '<cols>']
    out += [f'<col min="{i + 1}" max="{i + 1}" width="{w}" customWidth="1"/>' for i, w in enumerate(widths)]
    out.append('</cols><sheetData>')
    out.append('<row r="1">' + "".join(_cell(f"{_col(c)}1", h, 1) for c, h in enumerate(headers)) + "</row>")
    for r, (row, color) in enumerate(zip(rows, colors), start=2):
        style = 2 + _FILL_ORDER.index(color) if color in FILLS else 0
        cells = "".join(_cell(f"{_col(c)}{r}", (row[c] if c < len(row) else None), style)
                        for c in range(ncols))
        out.append(f'<row r="{r}">{cells}</row>')
    out.append("</sheetData>")
    if ncols:
        out.append(f'<autoFilter ref="A1:{_col(ncols - 1)}{max(len(rows) + 1, 1)}"/>')
    out.append("</worksheet>")
    return "".join(out)


def _styles_xml():
    fills = ['<fill><patternFill patternType="none"/></fill>',
             '<fill><patternFill patternType="gray125"/></fill>']
    fills += [f'<fill><patternFill patternType="solid"><fgColor rgb="{FILLS[k][0]}"/>'
              f'<bgColor indexed="64"/></patternFill></fill>' for k in _FILL_ORDER]
    xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>',
           '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>']
    xfs += [f'<xf numFmtId="0" fontId="0" fillId="{i + 2}" borderId="0" xfId="0" applyFill="1"/>'
            for i in range(len(_FILL_ORDER))]
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>'
            '<font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
            f'<fills count="{len(fills)}">{"".join(fills)}</fills>'
            '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            f'<cellXfs count="{len(xfs)}">{"".join(xfs)}</cellXfs>'
            '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            '</styleSheet>')


def write_xlsx(path, sheets):
    """sheets : liste de (nom, en-têtes, lignes, couleurs) ; couleurs = clé de
    FILLS ou None, une par ligne."""
    used, names = set(), []
    for name, *_ in sheets:
        names.append(_sheet_name(name, used))
    n = len(sheets)
    ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
          '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
          '<Default Extension="xml" ContentType="application/xml"/>'
          '<Override PartName="/xl/workbook.xml" '
          'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
          '<Override PartName="/xl/styles.xml" '
          'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
          + "".join(f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" '
                    'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                    for i in range(n)) + "</Types>")
    rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/'
            'relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
    wb = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
          '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'
          + "".join(f'<sheet name="{escape(nm, {chr(34): "&quot;"})}" sheetId="{i + 1}" r:id="rId{i + 1}"/>'
                    for i, nm in enumerate(names))
          + "</sheets>"
          + "</workbook>")
    wb_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
               + "".join(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/'
                         f'officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i + 1}.xml"/>'
                         for i in range(n))
               + f'<Relationship Id="rId{n + 1}" Type="http://schemas.openxmlformats.org/officeDocument/'
                 '2006/relationships/styles" Target="styles.xml"/></Relationships>')
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", ct)
        z.writestr("_rels/.rels", rels)
        z.writestr("xl/workbook.xml", wb)
        z.writestr("xl/_rels/workbook.xml.rels", wb_rels)
        z.writestr("xl/styles.xml", _styles_xml())
        for i, (_, headers, rows, colors) in enumerate(sheets):
            z.writestr(f"xl/worksheets/sheet{i + 1}.xml", _sheet_xml(headers, rows, colors))
