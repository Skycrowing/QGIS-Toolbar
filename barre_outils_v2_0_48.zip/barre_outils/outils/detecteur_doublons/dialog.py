import os

from qgis.PyQt.QtCore import QSize, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTextBrowser,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
)
from qgis.core import QgsFeature, QgsProject, QgsVectorLayer, QgsWkbTypes

from .finder import find_duplicates

ROLE = Qt.ItemDataRole.UserRole
CHECKED = Qt.CheckState.Checked
UNCHECKED = Qt.CheckState.Unchecked
MAX_GROUPS_SHOWN = 5000

HELP_HTML = """
<h2>Détecteur de doublons</h2>
<p>Recherche les entités identiques entre plusieurs couches vectorielles
(et, si souhaité, à l'intérieur d'une même couche).</p>

<h3>1. Choisir les couches</h3>
<ul>
<li>Cochez les couches à comparer (au moins deux pour une comparaison entre couches).</li>
<li><i>Entités sélectionnées uniquement</i> : limite la recherche à la sélection en cours de chaque couche.</li>
<li><i>Actualiser</i> recharge la liste si vous avez ajouté des couches au projet.</li>
</ul>

<h3>2. Définir les critères</h3>
<ul>
<li><b>Géométrie</b> : deux entités sont doublons si leurs géométries sont identiques.
Les couches sont reprojetées dans le SCR de la <b>première couche cochée</b>.</li>
<li><b>Tolérance</b> : les coordonnées sont arrondies sur une grille de cette taille
(unités du SCR de la première couche, ex. mètres). 0 = égalité exacte.</li>
<li><b>Champs communs</b> : seuls les champs présents dans toutes les couches cochées sont proposés.
Les valeurs des champs cochés doivent toutes être égales.</li>
<li>Vous pouvez combiner géométrie et champs, ou n'utiliser que l'un des deux.</li>
<li><i>Ignorer la casse</i> / <i>Ignorer les espaces</i> : « Bruxelles » = « bruxelles  ».</li>
<li><b>Portée</b> : <i>Entre couches uniquement</i> ne signale que les groupes répartis sur au moins
deux couches ; l'autre option inclut aussi les doublons internes à une couche.</li>
</ul>

<h3>3. Exploiter les résultats</h3>
<ul>
<li>Chaque <b>groupe</b> rassemble les entités identiques.</li>
<li><b>Double-clic</b> sur une entité : zoom et clignotement sur la carte.</li>
<li><b>Sélectionner dans les couches</b> : sélectionne tous les doublons, ou seulement les
lignes/groupes choisis dans la liste (Ctrl/Maj pour une sélection multiple).</li>
<li><b>Exporter en table</b> : crée une couche temporaire « Doublons »
(groupe, couche, ID d'entité, valeurs).</li>
<li>Le bouton <i>Annuler</i> interrompt une recherche longue.</li>
</ul>

<h3>Remarques</h3>
<ul>
<li>Les entités sans géométrie sont ignorées quand la géométrie est comparée.</li>
<li>Une même forme avec un point de départ différent est reconnue comme identique.</li>
<li>Avec une tolérance, deux points proches peuvent tomber de part et d'autre d'une ligne
de la grille : augmentez légèrement la tolérance en cas de doute.</li>
</ul>
"""


def _checkable(text, data, checked):
    item = QListWidgetItem(text)
    item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
    item.setCheckState(CHECKED if checked else UNCHECKED)
    item.setData(ROLE, data)
    return item


class DuplicateFinderDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.groups = []
        self._running = False
        self._cancel = False
        self.setWindowTitle("Détecteur de doublons")
        self.resize(760, 800)
        self._build_ui()
        QgsProject.instance().layersAdded.connect(self.refresh_layers)
        QgsProject.instance().layersRemoved.connect(self.refresh_layers)

    def cleanup(self):
        for sig in (QgsProject.instance().layersAdded, QgsProject.instance().layersRemoved):
            try:
                sig.disconnect(self.refresh_layers)
            except (TypeError, RuntimeError):
                pass

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        root = QVBoxLayout(self)

        # En-tête avec bouton d'aide
        head = QHBoxLayout()
        title = QLabel("<b>Comparer les couches cochées pour trouver les doublons</b>")
        head.addWidget(title)
        head.addStretch()
        self.btn_help = QToolButton()
        self.btn_help.setIcon(QIcon(os.path.join(os.path.dirname(__file__), "help.svg")))
        self.btn_help.setIconSize(QSize(24, 24))
        self.btn_help.setAutoRaise(True)
        self.btn_help.setToolTip("Aide")
        self.btn_help.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_help.clicked.connect(self.show_help)
        head.addWidget(self.btn_help)
        root.addLayout(head)

        # Couches
        self.box_layers = QGroupBox("Couches à comparer")
        lay = QVBoxLayout(self.box_layers)
        self.list_layers = QListWidget()
        self.list_layers.itemChanged.connect(self.update_fields)
        lay.addWidget(self.list_layers)
        row = QHBoxLayout()
        for text, slot in (("Tout cocher", lambda: self._set_all(self.list_layers, True)),
                           ("Tout décocher", lambda: self._set_all(self.list_layers, False)),
                           ("Actualiser", self.refresh_layers)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            row.addWidget(b)
        row.addStretch()
        lay.addLayout(row)
        self.chk_selected = QCheckBox("Entités sélectionnées uniquement")
        lay.addWidget(self.chk_selected)
        root.addWidget(self.box_layers, 2)

        # Critères
        self.box_crit = QGroupBox("Critères de comparaison")
        lay = QVBoxLayout(self.box_crit)
        row = QHBoxLayout()
        self.chk_geom = QCheckBox("Comparer la géométrie")
        self.chk_geom.setChecked(False)
        self.chk_geom.toggled.connect(lambda on: self.spin_tol.setEnabled(on))
        row.addWidget(self.chk_geom)
        row.addSpacing(20)
        row.addWidget(QLabel("Tolérance :"))
        self.spin_tol = QDoubleSpinBox()
        self.spin_tol.setDecimals(6)
        self.spin_tol.setRange(0, 1e7)
        self.spin_tol.setValue(0.0)
        self.spin_tol.setEnabled(False)
        self.spin_tol.setToolTip("Taille de grille d'accrochage, dans les unités du SCR "
                                 "de la première couche cochée. 0 = égalité exacte.")
        row.addWidget(self.spin_tol)
        row.addStretch()
        lay.addLayout(row)

        self.lbl_fields = QLabel("Champs communs :")
        lay.addWidget(self.lbl_fields)
        self.list_fields = QListWidget()
        lay.addWidget(self.list_fields)
        row = QHBoxLayout()
        self.chk_case = QCheckBox("Ignorer la casse")
        self.chk_strip = QCheckBox("Ignorer les espaces de début/fin")
        row.addWidget(self.chk_case)
        row.addWidget(self.chk_strip)
        row.addStretch()
        lay.addLayout(row)

        row = QHBoxLayout()
        row.addWidget(QLabel("Portée :"))
        self.cmb_scope = QComboBox()
        self.cmb_scope.addItems(["Entre couches uniquement",
                                 "Entre couches et au sein d'une même couche"])
        row.addWidget(self.cmb_scope)
        row.addStretch()
        lay.addLayout(row)
        root.addWidget(self.box_crit, 2)

        # Lancement
        row = QHBoxLayout()
        self.btn_run = QPushButton("Rechercher les doublons")
        self.btn_run.clicked.connect(self.run_search)
        row.addWidget(self.btn_run)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        row.addWidget(self.progress)
        root.addLayout(row)

        # Résultats
        self.lbl_summary = QLabel("")
        root.addWidget(self.lbl_summary)
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Groupe / Couche", "ID entité", "Valeurs"])
        self.tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tree.itemDoubleClicked.connect(self.zoom_to_item)
        root.addWidget(self.tree, 3)

        row = QHBoxLayout()
        b = QPushButton("Sélectionner dans les couches")
        b.setToolTip("Sélectionne les doublons (ou seulement les lignes choisies dans la liste).")
        b.clicked.connect(self.select_in_layers)
        row.addWidget(b)
        b = QPushButton("Exporter en table")
        b.clicked.connect(self.export_table)
        row.addWidget(b)
        row.addStretch()
        b = QPushButton("Fermer")
        b.clicked.connect(self.close)
        row.addWidget(b)
        root.addLayout(row)

    def show_help(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Aide – Détecteur de doublons")
        dlg.resize(560, 600)
        lay = QVBoxLayout(dlg)
        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        browser.setHtml(HELP_HTML)
        lay.addWidget(browser)
        btn = QPushButton("Fermer")
        btn.clicked.connect(dlg.accept)
        row = QHBoxLayout()
        row.addStretch()
        row.addWidget(btn)
        lay.addLayout(row)
        dlg.exec()

    @staticmethod
    def _set_all(widget, checked):
        for i in range(widget.count()):
            widget.item(i).setCheckState(CHECKED if checked else UNCHECKED)

    # -------------------------------------------------------------- couches
    def refresh_layers(self, *args):
        prev = {it.data(ROLE) for it in self._checked_items(self.list_layers)}
        self.list_layers.blockSignals(True)
        self.list_layers.clear()
        layers = [l for l in QgsProject.instance().mapLayers().values()
                  if isinstance(l, QgsVectorLayer) and l.isValid()]
        for lyr in sorted(layers, key=lambda l: l.name().lower()):
            geom = QgsWkbTypes.displayString(lyr.wkbType()) or "Sans géométrie"
            n = lyr.featureCount()
            info = f"{geom}, {n} entités" if n >= 0 else geom
            self.list_layers.addItem(_checkable(f"{lyr.name()}  [{info}]", lyr.id(), lyr.id() in prev))
        self.list_layers.blockSignals(False)
        self.update_fields()

    @staticmethod
    def _checked_items(widget):
        return [widget.item(i) for i in range(widget.count())
                if widget.item(i).checkState() == CHECKED]

    def checked_layers(self):
        project = QgsProject.instance()
        layers = [project.mapLayer(it.data(ROLE)) for it in self._checked_items(self.list_layers)]
        return [l for l in layers if l is not None]

    def update_fields(self, *args):
        prev = {it.data(ROLE) for it in self._checked_items(self.list_fields)}
        self.list_fields.clear()
        layers = self.checked_layers()
        if not layers:
            self.lbl_fields.setText("Champs communs : (cochez des couches)")
            return
        others = [set(l.fields().names()) for l in layers[1:]]
        common = [n for n in layers[0].fields().names() if all(n in s for s in others)]
        for name in common:
            self.list_fields.addItem(_checkable(name, name, name in prev))
        self.lbl_fields.setText(f"Champs communs ({len(common)}) :")

    # -------------------------------------------------------------- recherche
    def _on_progress(self, pct):
        self.progress.setValue(int(pct))
        QApplication.processEvents()
        return not self._cancel

    def run_search(self):
        if self._running:
            self._cancel = True
            return

        layers = self.checked_layers()
        fields = [it.data(ROLE) for it in self._checked_items(self.list_fields)]
        use_geom = self.chk_geom.isChecked()
        between = self.cmb_scope.currentIndex() == 0

        if not layers:
            return QMessageBox.warning(self, "Doublons", "Cochez au moins une couche.")
        if between and len(layers) < 2:
            return QMessageBox.warning(self, "Doublons",
                                       "Cochez au moins deux couches, ou changez la portée.")
        if not use_geom and not fields:
            return QMessageBox.warning(self, "Doublons",
                                       "Choisissez la géométrie et/ou au moins un champ.")

        self._running, self._cancel = True, False
        self.btn_run.setText("Annuler")
        self.box_layers.setEnabled(False)
        self.box_crit.setEnabled(False)
        self.tree.clear()
        self.groups = []
        self.progress.setValue(0)
        self.lbl_summary.setText("Recherche en cours…")
        try:
            result = find_duplicates(
                layers, fields,
                use_geometry=use_geom,
                tolerance=self.spin_tol.value(),
                ignore_case=self.chk_case.isChecked(),
                strip=self.chk_strip.isChecked(),
                selected_only=self.chk_selected.isChecked(),
                between_layers_only=between,
                progress=self._on_progress,
            )
        except Exception as e:  # noqa: BLE001
            result = None
            QMessageBox.critical(self, "Doublons", f"Erreur pendant la recherche :\n{e}")
        finally:
            self._running = False
            self.btn_run.setText("Rechercher les doublons")
            self.box_layers.setEnabled(True)
            self.box_crit.setEnabled(True)

        if result is None:
            self.lbl_summary.setText("Recherche annulée." if self._cancel else "")
            self.progress.setValue(0)
            return

        self.groups, skipped = result
        self._fill_tree()
        n_feats = sum(len(g) for g in self.groups)
        txt = f"{len(self.groups)} groupe(s) de doublons, {n_feats} entité(s) concernée(s)."
        if skipped:
            txt += f" {skipped} entité(s) ignorée(s) (géométrie vide ou non reprojetable)."
        if len(self.groups) > MAX_GROUPS_SHOWN:
            txt += f" Affichage limité aux {MAX_GROUPS_SHOWN} premiers groupes."
        self.lbl_summary.setText(txt)

    def _fill_tree(self):
        project = QgsProject.instance()
        names = {}
        self.tree.setUpdatesEnabled(False)
        for i, group in enumerate(self.groups[:MAX_GROUPS_SHOWN]):
            top = QTreeWidgetItem([f"Groupe {i + 1}", f"{len(group)} entités", group[0][2]])
            top.setData(0, ROLE, ("group", i))
            for lid, fid, label in group:
                if lid not in names:
                    lyr = project.mapLayer(lid)
                    names[lid] = lyr.name() if lyr else lid
                child = QTreeWidgetItem([names[lid], str(fid), label])
                child.setData(0, ROLE, ("feat", lid, fid))
                top.addChild(child)
            self.tree.addTopLevelItem(top)
        self.tree.setUpdatesEnabled(True)
        for c in range(3):
            self.tree.resizeColumnToContents(c)

    # -------------------------------------------------------------- actions
    def _targets(self):
        """{layer_id: set(fid)} selon la sélection dans la liste (ou tout)."""
        targets = {}
        selected = self.tree.selectedItems()
        if selected:
            for item in selected:
                data = item.data(0, ROLE)
                if data[0] == "group":
                    members = self.groups[data[1]]
                else:
                    members = [(data[1], data[2], None)]
                for lid, fid, _ in members:
                    targets.setdefault(lid, set()).add(fid)
        else:
            for group in self.groups:
                for lid, fid, _ in group:
                    targets.setdefault(lid, set()).add(fid)
        return targets

    def select_in_layers(self):
        if not self.groups:
            return QMessageBox.information(self, "Doublons", "Aucun résultat à sélectionner.")
        targets = self._targets()
        involved = {lid for g in self.groups for lid, _, _ in g}
        project = QgsProject.instance()
        total = 0
        for lid in involved:
            lyr = project.mapLayer(lid)
            if lyr is None:
                continue
            fids = list(targets.get(lid, []))
            if fids:
                lyr.selectByIds(fids)
                total += len(fids)
            else:
                lyr.removeSelection()
        self.iface.messageBar().pushInfo("Doublons", f"{total} entité(s) sélectionnée(s).")

    def zoom_to_item(self, item, _col):
        data = item.data(0, ROLE)
        if not data or data[0] != "feat":
            return
        lyr = QgsProject.instance().mapLayer(data[1])
        if lyr is None or not lyr.isSpatial():
            return
        canvas = self.iface.mapCanvas()
        canvas.zoomToFeatureIds(lyr, [data[2]])
        canvas.flashFeatureIds(lyr, [data[2]])

    def export_table(self):
        if not self.groups:
            return QMessageBox.information(self, "Doublons", "Aucun résultat à exporter.")
        uri = ("None?field=groupe:integer&field=couche:string(254)"
               "&field=id_couche:string(254)&field=id_entite:integer"
               "&field=valeurs:string(1000)")
        out = QgsVectorLayer(uri, "Doublons", "memory")
        project = QgsProject.instance()
        feats = []
        for i, group in enumerate(self.groups, 1):
            for lid, fid, label in group:
                lyr = project.mapLayer(lid)
                f = QgsFeature(out.fields())
                f.setAttributes([i, lyr.name() if lyr else "", lid, int(fid), label])
                feats.append(f)
        out.dataProvider().addFeatures(feats)
        out.updateExtents()
        project.addMapLayer(out)
        self.iface.messageBar().pushSuccess("Doublons", f"Table « Doublons » créée ({len(feats)} lignes).")
