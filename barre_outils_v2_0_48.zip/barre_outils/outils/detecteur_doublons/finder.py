"""Logique de détection des doublons (sans interface)."""

from qgis.core import (
    Qgis,
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsGeometry,
    QgsProject,
)

try:
    from qgis.PyQt.QtCore import QVariant
except ImportError:  # pragma: no cover
    QVariant = None

try:
    NO_GEOMETRY = Qgis.FeatureRequestFlag.NoGeometry
except AttributeError:
    NO_GEOMETRY = QgsFeatureRequest.NoGeometry


def _is_null(v):
    if v is None:
        return True
    if QVariant is not None and isinstance(v, QVariant):
        return v.isNull()
    return False


def _norm(v, ignore_case, strip):
    """Valeur normalisée et hachable servant de clé de comparaison."""
    if _is_null(v):
        return None
    if isinstance(v, str):
        if strip:
            v = v.strip()
        if ignore_case:
            v = v.casefold()
        return ("s", v)
    if isinstance(v, bool):
        return ("b", v)
    if isinstance(v, (int, float)):
        return ("n", round(float(v), 9))
    if hasattr(v, "toString"):  # QDate, QDateTime, QTime
        return ("t", v.toString())
    try:
        hash(v)
        return ("o", v)
    except TypeError:
        return ("o", repr(v))


def _label(v):
    if _is_null(v):
        return "NULL"
    if hasattr(v, "toString") and not isinstance(v, str):
        return v.toString()
    return str(v)


def find_duplicates(layers, fields, use_geometry=True, tolerance=0.0,
                    ignore_case=False, strip=False, selected_only=False,
                    between_layers_only=True, progress=None):
    """Retourne (groupes, nb_ignorées) ou None si annulé.

    Chaque groupe est une liste de tuples (layer_id, feature_id, libellé).
    La géométrie est comparée dans le SCR de la première couche.
    `progress(pct)` doit renvoyer False pour annuler.
    """
    project = QgsProject.instance()
    target_crs = layers[0].crs()
    index = {}
    skipped = 0

    total = 0
    for lyr in layers:
        n = lyr.selectedFeatureCount() if selected_only else lyr.featureCount()
        total += max(n, 0)
    total = max(total, 1)
    done = 0

    for lyr in layers:
        ct = None
        if use_geometry and lyr.crs() != target_crs:
            ct = QgsCoordinateTransform(lyr.crs(), target_crs, project)

        req = QgsFeatureRequest()
        if not use_geometry:
            req.setFlags(NO_GEOMETRY)
        if fields:
            req.setSubsetOfAttributes(fields, lyr.fields())
        else:
            req.setNoAttributes()

        it = lyr.getSelectedFeatures(req) if selected_only else lyr.getFeatures(req)
        lid = lyr.id()

        for feat in it:
            done += 1
            if progress is not None and done % 500 == 0:
                if not progress(100.0 * done / total):
                    return None

            key = []
            if use_geometry:
                g = feat.geometry()
                if g is None or g.isNull() or g.isEmpty():
                    skipped += 1
                    continue
                g = QgsGeometry(g)
                if ct is not None:
                    try:
                        g.transform(ct)
                    except Exception:
                        skipped += 1
                        continue
                if tolerance > 0:
                    g = g.snappedToGrid(tolerance, tolerance)
                try:
                    g.normalize()
                except AttributeError:
                    pass
                key.append(bytes(g.asWkb()))

            vals = [feat[f] for f in fields]
            key.extend(_norm(v, ignore_case, strip) for v in vals)
            label = " | ".join(_label(v) for v in vals)
            index.setdefault(tuple(key), []).append((lid, feat.id(), label))

    groups = [m for m in index.values() if len(m) > 1]
    if between_layers_only:
        groups = [m for m in groups if len({x[0] for x in m}) > 1]
    groups.sort(key=len, reverse=True)

    if progress is not None:
        progress(100)
    return groups, skipped
