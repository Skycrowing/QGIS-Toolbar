import os

try:
    from qgis.PyQt.QtGui import QAction, QIcon
except ImportError:
    from qgis.PyQt.QtGui import QIcon
    from qgis.PyQt.QtWidgets import QAction

MENU = "&Détecteur de doublons"


class DuplicateFinderPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dlg = None

    def initGui(self):
        icon = QIcon(os.path.join(os.path.dirname(__file__), "icon.svg"))
        self.action = QAction(icon, "Détecteur de doublons", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu(MENU, self.action)

    def unload(self):
        self.iface.removePluginVectorMenu(MENU, self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.dlg is not None:
            self.dlg.cleanup()
            self.dlg.close()
            self.dlg.deleteLater()
            self.dlg = None

    def run(self):
        if self.dlg is None:
            from .dialog import DuplicateFinderDialog
            self.dlg = DuplicateFinderDialog(self.iface, self.iface.mainWindow())
        self.dlg.refresh_layers()
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()
