def classFactory(iface):
    from .plugin import DuplicateFinderPlugin
    return DuplicateFinderPlugin(iface)
