from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTreeWidget,
    QTreeWidgetItem, QPushButton, QLineEdit, QLabel, QMessageBox
)
from qgis.PyQt.QtGui import QIcon
try:
    from qgis.PyQt.QtWidgets import QAction
except ImportError:  # Qt6
    from qgis.PyQt.QtGui import QAction
from qgis.core import QgsProject, QgsLayerTreeGroup, QgsLayerTreeLayer
import os


class RenameLayersGroupsPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()
        self.action = QAction(icon, "Renommer couches / groupes", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&Rename Layers & Groups", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu("&Rename Layers & Groups", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        dlg = RenameDialog(self.iface.mainWindow())
        dlg.exec()


class RenameDialog(QDialog):
    """Fenêtre listant couches + groupes du projet avec renommage à côté."""

    NODE_ROLE = Qt.ItemDataRole.UserRole

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Renommer les couches et groupes")
        self.resize(650, 500)

        layout = QVBoxLayout(self)

        info = QLabel(
            "Modifiez uniquement les noms que vous voulez changer.\n"
            "Les lignes laissées identiques au nom actuel ne seront pas touchées."
        )
        layout.addWidget(info)

        self.tree = QTreeWidget()
        self.tree.setColumnCount(2)
        self.tree.setHeaderLabels(["Nom actuel (couche / groupe)", "Nouveau nom"])
        self.tree.setColumnWidth(0, 320)
        layout.addWidget(self.tree)

        self.populate()

        btn_row = QHBoxLayout()
        self.apply_btn = QPushButton("Appliquer")
        self.apply_btn.clicked.connect(self.apply_renames)
        self.close_btn = QPushButton("Fermer")
        self.close_btn.clicked.connect(self.reject)
        btn_row.addStretch()
        btn_row.addWidget(self.apply_btn)
        btn_row.addWidget(self.close_btn)
        layout.addLayout(btn_row)

    def populate(self):
        self.tree.clear()
        root = QgsProject.instance().layerTreeRoot()
        self._add_children(root, self.tree.invisibleRootItem())
        self.tree.expandAll()

    def _add_children(self, tree_node, parent_item):
        for child in tree_node.children():
            current_name = child.name()
            item = QTreeWidgetItem(parent_item)
            item.setText(0, current_name)
            item.setData(0, self.NODE_ROLE, child)

            editor = QLineEdit(current_name)
            self.tree.setItemWidget(item, 1, editor)

            if isinstance(child, QgsLayerTreeGroup):
                item.setIcon(0, QIcon.fromTheme("folder"))
                self._add_children(child, item)
            elif isinstance(child, QgsLayerTreeLayer):
                pass

    def apply_renames(self):
        renamed_count = 0
        renamed_count = self._apply_recursive(self.tree.invisibleRootItem(), renamed_count)

        if renamed_count == 0:
            QMessageBox.information(self, "Rien à faire", "Aucun nom n'a été modifié.")
        else:
            QMessageBox.information(
                self, "Terminé", f"{renamed_count} élément(s) renommé(s)."
            )
            self.populate()  # rafraîchit avec les nouveaux noms comme référence

    def _apply_recursive(self, item, count):
        for i in range(item.childCount()):
            child_item = item.child(i)
            node = child_item.data(0, self.NODE_ROLE)
            editor = self.tree.itemWidget(child_item, 1)
            new_name = editor.text().strip() if editor else ""
            old_name = node.name()

            if new_name and new_name != old_name:
                if isinstance(node, QgsLayerTreeGroup):
                    node.setName(new_name)
                elif isinstance(node, QgsLayerTreeLayer):
                    layer = node.layer()
                    if layer is not None:
                        layer.setName(new_name)
                    else:
                        node.setName(new_name)
                count += 1

            count = self._apply_recursive(child_item, count)
        return count
