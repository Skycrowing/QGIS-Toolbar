def classFactory(iface):
    from .rename_layers_groups import RenameLayersGroupsPlugin
    return RenameLayersGroupsPlugin(iface)
