import configparser
import os


def plugin_version():
    cp = configparser.ConfigParser(interpolation=None)
    try:
        cp.read(os.path.join(os.path.dirname(__file__), "metadata.txt"), encoding="utf-8")
        return cp.get("general", "version")
    except Exception:
        return "?"
