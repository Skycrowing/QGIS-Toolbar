import os

try:
    from qgis.PyQt.QtGui import QAction
except ImportError:
    from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtCore import Qt, QTimer, QRectF, QSize
from qgis.PyQt.QtGui import QIcon, QPixmap, QPainter, QPen, QColor, QFont
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QToolButton,
    QTreeWidget, QTreeWidgetItem, QPushButton, QCheckBox, QLabel, QHeaderView,
    QDialog, QDialogButtonBox, QTextBrowser, QAbstractItemView,
)
from qgis.core import QgsProject, QgsVectorLayer, QgsApplication
from qgis.gui import QgsDockWidget

from .version import plugin_version

HERE = os.path.dirname(__file__)
MENU = "Compteur d'entités"
SCOPE = "CompteurEntites"
P_LEGENDE = "compteur_entites/legende"   # marque : showFeatureCount posé par l'outil
ROLE = 256            # Qt.UserRole (entier : compatible PyQt5/PyQt6)
ROLE_ID = 257
COL_NOM, COL_NB, COL_SEL = 0, 1, 2


def _fmt(n):
    return "?" if n is None or n < 0 else f"{n:,}".replace(",", " ")


def help_icon(widget, size=18):
    """Icône d'aide moderne : pastille bleu clair cerclée de bleu et « ? » bleu (style de la barre)."""
    dpr = max(1.0, float(widget.devicePixelRatioF()))
    pm = QPixmap(int(size * dpr), int(size * dpr))
    pm.setDevicePixelRatio(dpr)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
    p.setPen(QPen(QColor("#166fbf"), 1.4))
    p.setBrush(QColor("#c8e1f6"))
    p.drawEllipse(QRectF(1, 1, size - 2, size - 2))
    f = QFont(widget.font())
    f.setBold(True)
    f.setPixelSize(int(size * 0.68))
    p.setFont(f)
    p.setPen(QColor("#166fbf"))
    p.drawText(QRectF(0, 0, size, size), int(Qt.AlignmentFlag.AlignCenter), "?")
    p.end()
    return QIcon(pm)


def round_button(icon, tip):
    b = QToolButton()
    b.setIcon(icon)
    b.setIconSize(QSize(18, 18))
    b.setToolTip(tip)
    b.setAutoRaise(True)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.setStyleSheet(
        "QToolButton{border:none;border-radius:12px;padding:3px;}"
        "QToolButton:hover{background:rgba(127,127,127,0.18);}"
        "QToolButton:pressed{background:rgba(127,127,127,0.32);}")
    return b


class HelpDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Aide – Compteur d'entités v{plugin_version()}")
        self.resize(560, 560)
        lay = QVBoxLayout(self)
        tb = QTextBrowser()
        tb.setOpenExternalLinks(True)
        with open(os.path.join(HERE, "help", "index.html"), encoding="utf-8") as f:
            tb.setHtml(f.read().replace("{{VERSION}}", plugin_version()))
        lay.addWidget(tb)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)


class _Item(QTreeWidgetItem):
    """Tri numérique des colonnes de comptes."""

    def __lt__(self, other):
        col = self.treeWidget().sortColumn() if self.treeWidget() else 0
        if col == COL_NOM:
            return self.text(0).lower() < other.text(0).lower()
        a, b = self.data(col, ROLE), other.data(col, ROLE)
        a = -2 if a is None else a
        b = -2 if b is None else b
        return a < b


class Panneau(QgsDockWidget):
    def __init__(self, parent=None):
        super().__init__("Compteur d'entités", parent)
        self.setObjectName("CompteurEntitesDock")
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(4)

        haut = QHBoxLayout()
        self.filtre = QLineEdit()
        self.filtre.setPlaceholderText("Filtrer…")
        self.filtre.setClearButtonEnabled(True)
        haut.addWidget(self.filtre, 1)
        self.btn_maj = round_button(QgsApplication.getThemeIcon("mActionRefresh.svg"), "Actualiser les comptes")
        haut.addWidget(self.btn_maj)
        self.btn_aide = round_button(help_icon(self), f"Aide (v{plugin_version()})")
        self.btn_aide.clicked.connect(lambda: HelpDialog(self).exec())
        haut.addWidget(self.btn_aide)
        lay.addLayout(haut)

        self.liste = QTreeWidget()
        self.liste.setColumnCount(3)
        self.liste.setHeaderLabels(["Couche", "Entités", "Sélection"])
        self.liste.setRootIsDecorated(False)
        self.liste.setUniformRowHeights(True)
        self.liste.setAlternatingRowColors(True)
        self.liste.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.liste.setSortingEnabled(True)
        self.liste.sortByColumn(COL_NOM, Qt.SortOrder.AscendingOrder)
        h = self.liste.header()
        h.setSectionResizeMode(COL_NOM, QHeaderView.ResizeMode.Stretch)
        for c in (COL_NB, COL_SEL):
            h.setSectionResizeMode(c, QHeaderView.ResizeMode.ResizeToContents)
        h.setStretchLastSection(False)
        lay.addWidget(self.liste, 1)

        self.total = QLabel()
        self.total.setStyleSheet("font-weight:bold;")
        lay.addWidget(self.total)

        opts = QHBoxLayout()
        self.chk_cochees = QCheckBox("Cochées seulement")
        self.chk_legende = QCheckBox("Dans le panneau Couches")
        self.chk_legende.setToolTip("Affiche aussi [n] à côté du nom des couches cochées dans le panneau Couches")
        opts.addWidget(self.chk_cochees)
        opts.addWidget(self.chk_legende)
        opts.addStretch(1)
        lay.addLayout(opts)

        bas = QHBoxLayout()
        self.btn_tout = QPushButton("Tout cocher")
        self.btn_rien = QPushButton("Tout décocher")
        bas.addWidget(self.btn_tout)
        bas.addWidget(self.btn_rien)
        lay.addLayout(bas)

        self.setWidget(w)


class CompteurEntites:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.panneau = None
        self.items = {}          # id couche -> item
        self.connectees = {}     # id couche -> [(signal, slot)]
        self._remplissage = False
        self.timer = None

    # ---------- interface ----------
    def initGui(self):
        fen = self.iface.mainWindow()
        self.panneau = Panneau(fen)
        self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.panneau)
        self.panneau.hide()

        self.action = QAction(QIcon(os.path.join(HERE, "icon.svg")), "Compteur d'entités", fen)
        self.action.setCheckable(True)
        self.action.setToolTip(f"Compteur d'entités (v{plugin_version()})")
        self.panneau.setToggleVisibilityAction(self.action)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(MENU, self.action)

        self.timer = QTimer()
        self.timer.setSingleShot(True)
        self.timer.setInterval(150)
        self.timer.timeout.connect(self.compter)

        p = self.panneau
        p.liste.itemChanged.connect(self.case_changee)
        p.liste.itemDoubleClicked.connect(self.activer_couche)
        p.filtre.textChanged.connect(self.appliquer_filtre)
        p.chk_cochees.toggled.connect(self.option_cochees)
        p.chk_legende.toggled.connect(self.option_legende)
        p.btn_tout.clicked.connect(lambda: self.tout(True))
        p.btn_rien.clicked.connect(lambda: self.tout(False))
        p.btn_maj.clicked.connect(self.compter)
        p.visibilityChanged.connect(lambda v: v and self.compter())

        prj = QgsProject.instance()
        prj.readProject.connect(self.actualiser)
        prj.cleared.connect(self.actualiser)
        prj.layersAdded.connect(self.actualiser)
        prj.layersRemoved.connect(self._couches_retirees)
        self.actualiser()

    def unload(self):
        prj = QgsProject.instance()
        for s, f in ((prj.readProject, self.actualiser), (prj.cleared, self.actualiser),
                     (prj.layersAdded, self.actualiser), (prj.layersRemoved, self._couches_retirees)):
            try:
                s.disconnect(f)
            except TypeError:
                pass
        self._deconnecter_tout()
        for lid in list(self.items):          # retire les [n] ajoutés par l'outil
            c = prj.mapLayer(lid)
            if c is not None:
                self._legende(c, False)
        if self.timer:
            self.timer.stop()
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu(MENU, self.action)
        self.iface.removeDockWidget(self.panneau)
        self.panneau.deleteLater()
        self.action = self.panneau = self.timer = None
        self.items = {}

    # ---------- projet ----------
    def _cochees_projet(self):
        return set(QgsProject.instance().readListEntry(SCOPE, "couches", [])[0])

    def _sauver(self):
        prj = QgsProject.instance()
        prj.writeEntry(SCOPE, "couches", sorted(self._cochees()))
        prj.writeEntryBool(SCOPE, "cochees_seulement", self.panneau.chk_cochees.isChecked())
        prj.writeEntryBool(SCOPE, "legende", self.panneau.chk_legende.isChecked())

    def _cochees(self):
        return {lid for lid, it in self.items.items() if it.checkState(0) == Qt.CheckState.Checked}

    def actualiser(self, *args):
        """Reconstruit la liste des couches vectorielles du projet."""
        prj = QgsProject.instance()
        p = self.panneau
        cochees = self._cochees_projet()
        self._deconnecter_tout()
        self._remplissage = True
        p.liste.setSortingEnabled(False)
        p.liste.clear()
        self.items = {}
        for c in prj.mapLayers().values():
            if not isinstance(c, QgsVectorLayer):
                continue
            it = _Item([c.name(), "", ""])
            it.setData(0, ROLE_ID, c.id())
            it.setToolTip(0, c.source() if len(c.source()) < 300 else c.name())
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(0, Qt.CheckState.Checked if c.id() in cochees else Qt.CheckState.Unchecked)
            it.setIcon(0, QgsApplication.getThemeIcon(self._icone(c)))
            for col in (COL_NB, COL_SEL):
                it.setTextAlignment(col, int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter))
            p.liste.addTopLevelItem(it)
            self.items[c.id()] = it
            self._connecter(c)
        p.liste.setSortingEnabled(True)
        for chk, cle in ((p.chk_cochees, "cochees_seulement"), (p.chk_legende, "legende")):
            chk.blockSignals(True)
            chk.setChecked(prj.readBoolEntry(SCOPE, cle, False)[0])
            chk.blockSignals(False)
        self._remplissage = False
        self.appliquer_filtre()
        self.compter()

    def _couches_retirees(self, ids):
        self.actualiser()

    @staticmethod
    def _icone(c):
        g = c.geometryType()
        g = int(getattr(g, "value", g))
        return {0: "mIconPointLayer.svg", 1: "mIconLineLayer.svg",
                2: "mIconPolygonLayer.svg"}.get(g, "mIconTableLayer.svg")

    # ---------- signaux des couches ----------
    def _connecter(self, c):
        lid = c.id()
        liens = [(c.nameChanged, lambda lid=lid: self._renommer(lid))]
        for nom in ("featureAdded", "featuresDeleted", "selectionChanged",
                    "subsetStringChanged", "dataSourceChanged", "afterCommitChanges",
                    "afterRollBack", "dataChanged"):
            sig = getattr(c, nom, None)
            if sig is not None:
                liens.append((sig, self._planifier))
        for s, f in liens:
            s.connect(f)
        self.connectees[lid] = liens

    def _deconnecter_tout(self):
        for liens in self.connectees.values():
            for s, f in liens:
                try:
                    s.disconnect(f)
                except (TypeError, RuntimeError):
                    pass
        self.connectees = {}

    def _renommer(self, lid):
        c = QgsProject.instance().mapLayer(lid)
        it = self.items.get(lid)
        if c and it:
            it.setText(0, c.name())

    def _planifier(self, *args):
        if self.timer:
            self.timer.start()

    # ---------- comptes ----------
    def compter(self):
        if self.panneau is None:
            return
        prj = QgsProject.instance()
        tot_n = tot_s = nb = 0
        inconnu = False
        legende = self.panneau.chk_legende.isChecked()
        self._remplissage = True
        self.panneau.liste.setSortingEnabled(False)
        for lid, it in self.items.items():
            c = prj.mapLayer(lid)
            if c is None:
                continue
            coche = it.checkState(0) == Qt.CheckState.Checked
            if coche:
                n = c.featureCount()
                s = c.selectedFeatureCount()
                it.setText(COL_NB, _fmt(n))
                it.setText(COL_SEL, _fmt(s) if s else "")
                it.setData(COL_NB, ROLE, n)
                it.setData(COL_SEL, ROLE, s)
                nb += 1
                tot_s += s
                if n is None or n < 0:
                    inconnu = True
                else:
                    tot_n += n
            else:
                for col in (COL_NB, COL_SEL):
                    it.setText(col, "")
                    it.setData(col, ROLE, None)
            self._legende(c, coche and legende)
        self.panneau.liste.setSortingEnabled(True)
        self._remplissage = False
        if nb:
            txt = f"Total : {_fmt(tot_n)}{'+?' if inconnu else ''} entités"
            if tot_s:
                txt += f" · {_fmt(tot_s)} sélectionnées"
            txt += f" ({nb} couche{'s' if nb > 1 else ''})"
        else:
            txt = "Cochez les couches à compter."
        self.panneau.total.setText(txt)

    def _legende(self, c, afficher):
        """Affiche/retire [n] dans le panneau Couches (sans toucher aux réglages de l'utilisateur)."""
        noeud = QgsProject.instance().layerTreeRoot().findLayer(c.id())
        if noeud is None:
            return
        deja = str(noeud.customProperty("showFeatureCount", False)).lower() in ("true", "1")
        notre = str(noeud.customProperty(P_LEGENDE, False)).lower() in ("true", "1")
        if afficher and not deja:
            noeud.setCustomProperty("showFeatureCount", True)
            noeud.setCustomProperty(P_LEGENDE, True)
        elif not afficher and notre:
            noeud.setCustomProperty("showFeatureCount", False)
            noeud.removeCustomProperty(P_LEGENDE)

    # ---------- événements ----------
    def case_changee(self, item, col):
        if self._remplissage or col != 0:
            return
        self._sauver()
        self.appliquer_filtre()
        self.compter()

    def tout(self, etat):
        cible = Qt.CheckState.Checked if etat else Qt.CheckState.Unchecked
        self._remplissage = True
        for it in self.items.values():
            if not it.isHidden():
                it.setCheckState(0, cible)
        self._remplissage = False
        self._sauver()
        self.appliquer_filtre()
        self.compter()

    def appliquer_filtre(self, *args):
        p = self.panneau
        txt = p.filtre.text().strip().lower()
        seulement = p.chk_cochees.isChecked()
        for it in self.items.values():
            cache = (txt and txt not in it.text(0).lower()) or \
                    (seulement and it.checkState(0) != Qt.CheckState.Checked)
            it.setHidden(bool(cache))

    def option_cochees(self, *args):
        self._sauver()
        self.appliquer_filtre()

    def option_legende(self, *args):
        self._sauver()
        self.compter()

    def activer_couche(self, item, col):
        c = QgsProject.instance().mapLayer(item.data(0, ROLE_ID))
        if c is not None:
            self.iface.setActiveLayer(c)
