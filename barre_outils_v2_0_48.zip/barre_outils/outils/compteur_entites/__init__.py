def classFactory(iface):
    from .plugin import CompteurEntites
    return CompteurEntites(iface)
