# -*- coding: utf-8 -*-
# OSM Tracer – plugin QGIS
# Copyright (C) 2026 skycrow2 <skycrow2@gmail.com>
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version. See the LICENSE file.
#
# SPDX-License-Identifier: GPL-2.0-or-later
# Données routières : © contributeurs OpenStreetMap, licence ODbL 1.0
"""Moteur de routage OSM indépendant de QGIS (testable en Python pur).

Flux : requête Overpass -> parsing JSON -> graphe pondéré -> Dijkstra.
"""
import heapq
import math
import re

# ---------------------------------------------------------------------------
# Catégories de voies : clé, libellé, valeurs highway OSM, vitesse par défaut
# (km/h), activé par défaut
# ---------------------------------------------------------------------------
ROAD_TYPES = [
    ("motorway", "Autoroute", ["motorway", "motorway_link"], 120, True),
    ("trunk", "Voie rapide (2x2)", ["trunk", "trunk_link"], 90, True),
    ("primary", "Nationale", ["primary", "primary_link"], 70, True),
    ("secondary", "Régionale", ["secondary", "secondary_link"], 60, True),
    ("tertiary", "Tertiaire", ["tertiary", "tertiary_link"], 50, True),
    ("local", "Locale / résidentielle",
     ["unclassified", "residential", "living_street", "road"], 30, True),
    ("service", "Desserte / service", ["service"], 15, False),
    ("track", "Chemin agricole / forestier", ["track"], 15, False),
    ("ravel", "RAVeL", [], 18, False),
    ("cycleway", "Piste cyclable", ["cycleway"], 18, False),
    ("path", "Sentier / piétonnier",
     ["path", "footway", "pedestrian", "bridleway", "steps"], 5, False),
]
ROAD_KEYS = [r[0] for r in ROAD_TYPES]
HIGHWAY_TO_KEY = {hw: r[0] for r in ROAD_TYPES for hw in r[2]}

# Ce qu'il faut télécharger en plus quand le RAVeL est demandé : un tronçon
# RAVeL peut porter n'importe lequel de ces highway.
RAVEL_HIGHWAYS = ["cycleway", "track", "path", "service", "unclassified",
                  "residential", "footway", "bridleway", "living_street"]

REF_SPEED_KMH = 50.0  # vitesse de référence pour rendre distance et temps comparables

# Profils prédéfinis : poids (0 = rapide, 1 = court), sens uniques, voies,
# vitesses et facteurs de préférence spécifiques.
PROFILES = {
    "Le plus rapide": dict(weight=0.0, oneway=True, motor=True,
                           enabled=["motorway", "trunk", "primary", "secondary",
                                    "tertiary", "local", "service"]),
    "Le plus court": dict(weight=1.0, oneway=False, motor=False,
                          enabled=["trunk", "primary", "secondary",
                                   "tertiary", "local", "service", "ravel"]),
    "Équilibré": dict(weight=0.5, oneway=True, motor=True,
                      enabled=["motorway", "trunk", "primary", "secondary",
                               "tertiary", "local", "service"]),
    "Sans autoroute": dict(weight=0.3, oneway=True, motor=True,
                           enabled=["primary", "secondary", "tertiary",
                                    "local", "service"]),
    "Vélo (RAVeL privilégié)": dict(
        weight=0.7, oneway=False, motor=False,
        enabled=["tertiary", "local", "service", "track", "ravel", "cycleway"],
        speeds=dict(tertiary=18, local=18, service=16, track=14, ravel=20,
                    cycleway=20, secondary=18, primary=18),
        factors=dict(ravel=0.5, cycleway=0.7, track=1.3, tertiary=1.5)),
    "Piéton": dict(
        weight=1.0, oneway=False, motor=False,
        enabled=["tertiary", "local", "service", "track", "ravel",
                 "cycleway", "path"],
        speeds={k: 5 for k in ROAD_KEYS}, factors=dict(tertiary=1.3)),
}


class RoutingError(Exception):
    pass


class Canceled(RoutingError):
    def __init__(self):
        super().__init__("Calcul arrêté par l'utilisateur.")


# ---------------------------------------------------------------------------
# Overpass
# ---------------------------------------------------------------------------
def compute_bbox(p1, p2, margin_ratio=0.25, min_margin_deg=0.02):
    """bbox (sud, ouest, nord, est) englobant les deux points (lon, lat)."""
    return compute_bbox_pts([p1, p2], margin_ratio, min_margin_deg)


def compute_bbox_pts(points, margin_ratio=0.25, min_margin_deg=0.02):
    """bbox (sud, ouest, nord, est) englobant une liste de points (lon, lat)."""
    w, e = min(p[0] for p in points), max(p[0] for p in points)
    s, n = min(p[1] for p in points), max(p[1] for p in points)
    mx = max((e - w) * margin_ratio, min_margin_deg)
    my = max((n - s) * margin_ratio, min_margin_deg)
    return (s - my, w - mx, n + my, e + mx)


def build_overpass_query(bbox, enabled_keys, timeout=180):
    """Requête allégée : seules les voies cochées sont téléchargées sur toute
    la zone ; pour le RAVeL, on ne prend que les tronçons des relations RAVeL
    (ou nommés RAVeL) au lieu de tous les chemins / sentiers."""
    types = dict((r[0], r[2]) for r in ROAD_TYPES)
    highways = set()
    for key in enabled_keys:
        highways.update(types[key])
    ravel = "ravel" in enabled_keys
    if not highways and not ravel:
        raise RoutingError("Aucun type de voie sélectionné.")
    b = "%.6f,%.6f,%.6f,%.6f" % bbox
    q = "[out:json][timeout:%d];\n(\n" % timeout
    if highways:
        q += '  way["highway"~"^(%s)$"](%s);\n' % ("|".join(sorted(highways)), b)
    if ravel:
        q = ('[out:json][timeout:%d];\n'
             '(\n'
             '  rel["route"~"^(bicycle|mtb)$"]["name"~"ravel",i](%s);\n'
             '  rel["route"~"^(bicycle|mtb)$"]["ref"~"ravel",i](%s);\n'
             '  rel["route"~"^(bicycle|mtb)$"]["network"~"ravel",i](%s);\n'
             ')->.r;\n(\n' % (timeout, b, b, b)) + q.split("(\n", 1)[1]
        q += '  way(r.r)["highway"](%s);\n' % b
        q += '  way["highway"]["name"~"ravel",i](%s);\n' % b
    q += ")->.w;\n.w out body;\n.w >;\nout skel qt;\n"
    if ravel:
        q += ".r out body;\n"
    return q


def bbox_too_large(bbox, max_deg2=1.0):
    return (bbox[2] - bbox[0]) * (bbox[3] - bbox[1]) > max_deg2


# ---------------------------------------------------------------------------
# Graphe
# ---------------------------------------------------------------------------
def haversine(lon1, lat1, lon2, lat2):
    r = 6371008.8
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def bearing_deg(lon1, lat1, lon2, lat2):
    """Azimut (0 = nord, sens horaire) du point 1 vers le point 2."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    x = math.sin(dl) * math.cos(p2)
    y = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(x, y)) + 360.0) % 360.0


def angle_diff(a, b):
    d = abs(a - b) % 360.0
    return min(d, 360.0 - d)


def _is_ravel_tags(tags):
    for k in ("name", "ref", "network", "operator", "description", "name:fr"):
        if "ravel" in tags.get(k, "").lower():
            return True
    return False


def _parse_maxspeed(value):
    if not value:
        return None
    m = re.match(r"\s*(\d+(?:\.\d+)?)\s*(mph)?", value)
    if not m:
        return None
    v = float(m.group(1))
    return v * 1.609 if m.group(2) else v


def classify_way(tags, ravel_ids, way_id):
    if way_id in ravel_ids or _is_ravel_tags(tags):
        return "ravel"
    return HIGHWAY_TO_KEY.get(tags.get("highway"))


class RoadGraph:
    def __init__(self, osm_json, settings):
        """settings : dict
            enabled  : liste de clés de ROAD_TYPES
            speeds   : {clé: km/h}
            factors  : {clé: facteur de préférence (>0, <1 favorise)}
            weight   : 0 (rapide) .. 1 (court)
            oneway   : respecter les sens uniques
            motor    : profil motorisé (utilise maxspeed, respecte access)
        """
        self.s = settings
        self.coords = {}        # node_id -> (lon, lat)
        self.seg_way = {}       # (a, b) -> (way_id, nom de la voie)
        self.adj = {}           # node_id -> [(nbr, cost, length, time, key)]
        self._grid = None       # index spatial des tronçons (créé à la demande)
        self._build(osm_json)

    def _edge_cost(self, length, speed_kmh, factor):
        w = self.s["weight"]
        time_s = length / (speed_kmh / 3.6)
        dist_equiv = length / (REF_SPEED_KMH / 3.6)
        return factor * ((1 - w) * time_s + w * dist_equiv), time_s

    def _accessible(self, tags, key):
        access = tags.get("access", "")
        if self.s["motor"]:
            mv = tags.get("motor_vehicle", tags.get("motorcar", ""))
            if mv in ("no", "private", "agricultural", "forestry", "destination"):
                return mv == "destination"
            return access not in ("no", "private", "agricultural", "forestry")
        bike = tags.get("bicycle", tags.get("foot", ""))
        if bike in ("yes", "designated", "permissive"):
            return True
        if bike == "no":
            return False
        if key in ("motorway", "trunk") and tags.get("highway", "").startswith(
                ("motorway", "trunk")):
            return False
        return access not in ("no", "private")

    def _build(self, data):
        elements = data.get("elements", [])
        ravel_ids = set()
        for el in elements:
            if el["type"] == "node":
                self.coords[el["id"]] = (el["lon"], el["lat"])
            elif el["type"] == "relation" and _is_ravel_tags(el.get("tags", {})):
                for m in el.get("members", []):
                    if m.get("type") == "way":
                        ravel_ids.add(m["ref"])

        enabled = set(self.s["enabled"])
        for el in elements:
            if el["type"] != "way":
                continue
            tags = el.get("tags", {})
            key = classify_way(tags, ravel_ids, el["id"])
            if key not in enabled or not self._accessible(tags, key):
                continue
            speed = float(self.s["speeds"].get(key, 30))
            if self.s["motor"]:
                ms = _parse_maxspeed(tags.get("maxspeed"))
                if ms:
                    speed = min(speed, ms)
            speed = max(speed, 1.0)
            factor = max(float(self.s["factors"].get(key, 1.0)), 0.01)

            fwd, bwd = True, True
            if self.s["oneway"]:
                ow = tags.get("oneway", "")
                implied = tags.get("junction") in ("roundabout", "circular") or \
                    tags.get("highway") in ("motorway", "motorway_link")
                if ow == "-1":
                    fwd, bwd = False, True
                elif ow in ("yes", "true", "1") or (implied and ow != "no"):
                    bwd = False

            nodes = el.get("nodes", [])
            wname = tags.get("name") or tags.get("ref") or ""
            for a, b in zip(nodes, nodes[1:]):
                if a not in self.coords or b not in self.coords:
                    continue
                self.seg_way[(a, b)] = (el["id"], wname)
                (x1, y1), (x2, y2) = self.coords[a], self.coords[b]
                length = haversine(x1, y1, x2, y2)
                cost, t = self._edge_cost(length, speed, factor)
                if fwd:
                    self.adj.setdefault(a, []).append((b, cost, length, t, key))
                if bwd:
                    self.adj.setdefault(b, []).append((a, cost, length, t, key))
                self.adj.setdefault(a, [])
                self.adj.setdefault(b, [])

        if not self.adj:
            raise RoutingError("Aucun tronçon routable trouvé dans la zone "
                               "pour les types de voies sélectionnés.")

    SEG_CELL = 0.005   # taille des cellules de l'index spatial (degrés)

    def _seg_index(self):
        """Grille régulière : cellule -> tronçons (a, b) qui la traversent."""
        if self._grid is not None:
            return self._grid
        lats = [self.coords[n][1] for n in self.adj if n >= 0]
        self._k = math.cos(math.radians((min(lats) + max(lats)) / 2))
        k, c = self._k, self.SEG_CELL
        grid, seen = {}, set()
        for a, edges in self.adj.items():
            if a < 0:
                continue
            ax, ay = self.coords[a]
            for b, *_ in edges:
                if b < 0 or (b, a) in seen or (a, b) in seen:
                    continue
                seen.add((a, b))
                bx, by = self.coords[b]
                i0, i1 = sorted((int(math.floor(ax * k / c)), int(math.floor(bx * k / c))))
                j0, j1 = sorted((int(math.floor(ay / c)), int(math.floor(by / c))))
                for i in range(i0, i1 + 1):
                    for j in range(j0, j1 + 1):
                        grid.setdefault((i, j), []).append((a, b))
        keys = list(grid)
        self._grid_ext = (min(x[0] for x in keys), max(x[0] for x in keys),
                          min(x[1] for x in keys), max(x[1] for x in keys))
        self._grid = grid
        return grid

    def nearest_segment(self, lon, lat):
        """Projette le point sur le tronçon le plus proche.
        Retourne (a, b, t, (lon, lat) projeté, distance m)."""
        grid = self._seg_index()
        k, c = self._k, self.SEG_CELL
        ci, cj = int(math.floor(lon * k / c)), int(math.floor(lat / c))
        imin, imax, jmin, jmax = self._grid_ext
        max_r = max(abs(ci - imin), abs(ci - imax), abs(cj - jmin), abs(cj - jmax))
        best, best_d = None, float("inf")
        tested = set()
        r = 0
        while r <= max_r:
            if r == 0:
                cells = [(ci, cj)]
            else:
                cells = [(i, j) for i in range(ci - r, ci + r + 1) for j in (cj - r, cj + r)]
                cells += [(i, j) for j in range(cj - r + 1, cj + r) for i in (ci - r, ci + r)]
            for cell in cells:
                for a, b in grid.get(cell, ()):
                    if (a, b) in tested:
                        continue
                    tested.add((a, b))
                    ax, ay = self.coords[a]
                    bx, by = self.coords[b]
                    dx, dy = (bx - ax) * k, by - ay
                    l2 = dx * dx + dy * dy
                    t = 0.0 if l2 == 0 else max(0.0, min(1.0, (
                        (lon - ax) * k * dx + (lat - ay) * dy) / l2))
                    px, py = ax + t * (bx - ax), ay + t * (by - ay)
                    d = ((px - lon) * k) ** 2 + (py - lat) ** 2
                    if d < best_d:
                        best, best_d = (a, b, t, (px, py)), d
            # Tout point à moins de r*c a été examiné : on peut s'arrêter
            if best is not None and math.sqrt(best_d) <= r * c:
                break
            r += 1
        a, b, t, p = best
        return a, b, t, p, haversine(lon, lat, p[0], p[1])

    def _segments(self):
        seen = set()
        for a, edges in self.adj.items():
            if a < 0:
                continue
            for b, *_ in edges:
                if b < 0 or (b, a) in seen or (a, b) in seen:
                    continue
                seen.add((a, b))
                yield a, b

    def way_of(self, a, b):
        """(way_id, nom) du tronçon a-b (dans un sens ou l'autre)."""
        return self.seg_way.get((a, b)) or self.seg_way.get((b, a)) or (None, "")

    def snap_on_way(self, lon, lat, way_id):
        """Point le plus proche de (lon, lat) sur la voie OSM way_id."""
        k = math.cos(math.radians(lat))
        best, best_d = None, float("inf")
        for a, b in self._segments():
            if self.way_of(a, b)[0] != way_id:
                continue
            (ax, ay), (bx, by) = self.coords[a], self.coords[b]
            dx, dy = (bx - ax) * k, by - ay
            l2 = dx * dx + dy * dy
            t = 0.0 if l2 == 0 else max(0.0, min(1.0, (
                (lon - ax) * k * dx + (lat - ay) * dy) / l2))
            px, py = ax + t * (bx - ax), ay + t * (by - ay)
            d = ((px - lon) * k) ** 2 + (py - lat) ** 2
            if d < best_d:
                best, best_d = (a, b, t, (px, py)), d
        if best is None:
            return None
        a, b, t, p = best
        return a, b, t, p, haversine(lon, lat, p[0], p[1])

    def snap_directional(self, lon, lat, bearing, toward=None, max_m=3000.0, cone=45.0,
                         min_m=15.0):
        """Accroche dans une direction.
        1. toward (point cliqué pour la direction) à moins de 60 m d'une voie :
           on s'accroche à CETTE voie, au point le plus proche du départ ;
        2. sinon, première voie coupée par la demi-droite selon l'azimut ;
        3. à défaut, la plus proche dans un cône de ±cone° ; puis la plus proche.
        Les voies à moins de min_m du départ (celle sur laquelle on a cliqué le
        départ) sont ignorées pour 2 et 3 : on cherche une AUTRE voie.
        Même format que nearest_segment."""
        if bearing is None:
            return self.nearest_segment(lon, lat)
        if toward is not None:
            ns = self.nearest_segment(*toward)
            if ns[4] <= 60.0:
                snap = self.snap_on_way(lon, lat, self.way_of(ns[0], ns[1])[0])
                if snap is not None:
                    return snap
        kx = 111320.0 * math.cos(math.radians(lat))
        ky = 110540.0
        dx, dy = math.sin(math.radians(bearing)), math.cos(math.radians(bearing))

        def xy(n):
            x, y = self.coords[n]
            return (x - lon) * kx, (y - lat) * ky

        best, best_t = None, max_m
        cone_best, cone_d = None, max_m
        for a, b in self._segments():
            ax, ay = xy(a)
            bx, by = xy(b)
            sx, sy = bx - ax, by - ay
            rxs = dx * sy - dy * sx
            if abs(rxs) > 1e-12:
                t = (ax * sy - ay * sx) / rxs
                u = (ax * dy - ay * dx) / rxs
                if 0 <= u <= 1 and min_m <= t < best_t:
                    best, best_t = (a, b, u), t
            if best is None:   # repli : plus proche dans le cône
                l2 = sx * sx + sy * sy
                u = 0.0 if l2 == 0 else max(0.0, min(1.0, -(ax * sx + ay * sy) / l2))
                px, py = ax + u * sx, ay + u * sy
                d = math.hypot(px, py)
                if min_m <= d < cone_d and angle_diff(
                        (math.degrees(math.atan2(px, py)) + 360) % 360, bearing) <= cone:
                    cone_best, cone_d = (a, b, u), d
        pick = best or cone_best
        if pick is None:
            return self.nearest_segment(lon, lat)
        a, b, u = pick
        (x1, y1), (x2, y2) = self.coords[a], self.coords[b]
        p = (x1 + u * (x2 - x1), y1 + u * (y2 - y1))
        return a, b, u, p, haversine(lon, lat, p[0], p[1])

    def _edge(self, u, v):
        for e in self.adj.get(u, []):
            if e[0] == v:
                return e
        return None

    def add_virtual(self, vid, snap, is_start):
        """Insère un nœud virtuel sur le tronçon (a, b) au point projeté."""
        a, b, t, p, _ = snap
        self.coords[vid] = p
        self.adj.setdefault(vid, [])
        for u, v, frac in ((a, b, t), (b, a, 1 - t)):
            e = self._edge(u, v)          # tronçon u -> v circulable ?
            if not e:
                continue
            _, c, l, tm, key = e
            if is_start:   # vid -> v : reste du tronçon
                r = 1 - frac
                self.adj[vid].append((v, c * r, l * r, tm * r, key))
            else:          # u -> vid : début du tronçon
                self.adj[u].append((vid, c * frac, l * frac, tm * frac, key))

    def _dijkstra(self, src, dsts, max_found=1, is_canceled=None):
        """Dijkstra depuis src ; s'arrête quand max_found cibles sont atteintes.
        Retourne (cibles atteintes par coût croissant, prev)."""
        dist = {src: 0.0}
        prev = {}
        heap = [(0.0, src)]
        remaining = set(dsts)
        found = []
        it = 0
        while heap and remaining and len(found) < max_found:
            it += 1
            if is_canceled and it % 5000 == 0 and is_canceled():
                raise Canceled()
            d, u = heapq.heappop(heap)
            if d > dist.get(u, float("inf")):
                continue
            if u in remaining:
                found.append(u)
                remaining.discard(u)
                continue
            for v, c, length, t, key in self.adj[u]:
                nd = d + c
                if nd < dist.get(v, float("inf")):
                    dist[v] = nd
                    prev[v] = (u, length, t, key)
                    heapq.heappush(heap, (nd, v))
        return found, prev

    def _path(self, src, dst, prev):
        path, length, time_s, per_type = [dst], 0.0, 0.0, {}
        n = dst
        while n != src:
            u, l, t, key = prev[n]
            length += l
            time_s += t
            per_type[key] = per_type.get(key, 0.0) + l
            path.append(u)
            n = u
        path.reverse()
        return dict(coords=[self.coords[n] for n in path], length_m=length,
                    time_s=time_s, per_type_m=per_type, dst=dst)

    def shortest_path(self, src, dst, is_canceled=None, not_found=None):
        """dst : un nœud ou un ensemble de nœuds (s'arrête au premier atteint)."""
        dsts = dst if isinstance(dst, (set, frozenset)) else {dst}
        found, prev = self._dijkstra(src, dsts, 1, is_canceled)
        if not found:
            raise RoutingError(not_found or
                               "Aucun itinéraire trouvé entre les deux points "
                               "(réseau non connecté : élargissez les types de voies).")
        return self._path(src, found[0], prev)


def _link_same_segment(g, S, ss, T, st):
    """Départ et cible sur le même tronçon : liaison directe si le sens le permet."""
    a, b, ts = ss[0], ss[1], ss[2]
    if {a, b} == {st[0], st[1]}:
        te = st[2] if st[0] == a else 1 - st[2]
        u, v, f = (a, b, te - ts) if te >= ts else (b, a, ts - te)
        e = g._edge(u, v)
        if e:
            g.adj[S].append((T, e[1] * f, e[2] * f, e[3] * f, e[4]))


def format_address(nominatim):
    """Adresse lisible (style belge : « Rue 12, 1000 Ville ») depuis une
    réponse Nominatim reverse (format jsonv2, addressdetails=1)."""
    if not nominatim or "error" in nominatim:
        return None
    a = nominatim.get("address") or {}
    road = next((a[k] for k in ("road", "pedestrian", "footway", "path", "cycleway",
                                "square", "place", "hamlet") if a.get(k)), "")
    street = ("%s %s" % (road, a["house_number"])).strip() if a.get("house_number") \
        else road
    city = next((a[k] for k in ("city", "town", "village", "municipality",
                                "suburb") if a.get(k)), "")
    locality = ("%s %s" % (a.get("postcode", ""), city)).strip()
    parts = [p for p in (street, locality) if p]
    return ", ".join(parts) if parts else nominatim.get("display_name")


def route(osm_json, start, end, settings, is_canceled=None):
    """start/end : (lon, lat) WGS84. Retourne dict résultat."""
    g = RoadGraph(osm_json, settings)
    ss = g.snap_directional(start[0], start[1], settings.get("start_bearing"),
                            settings.get("start_toward"))
    se = g.nearest_segment(*end)
    S, E = -1, -2
    g.add_virtual(S, ss, True)
    g.add_virtual(E, se, False)
    _link_same_segment(g, S, ss, E, se)
    if is_canceled and is_canceled():
        raise Canceled()
    res = g.shortest_path(S, E, is_canceled)
    res["snap_start_m"], res["snap_end_m"] = ss[4], se[4]
    res["snap_start_name"] = g.way_of(ss[0], ss[1])[1]
    return res


def route_to_all(osm_json, start, targets, settings, max_routes=5, is_canceled=None):
    """Itinéraires du départ vers les max_routes cibles les plus proches PAR LA
    ROUTE (un seul Dijkstra). targets : liste de (lon, lat).
    Retourne une liste de résultats triés, chacun avec target_index."""
    if not targets:
        raise RoutingError("Aucune cible à atteindre.")
    g = RoadGraph(osm_json, settings)
    ss = g.snap_directional(start[0], start[1], settings.get("start_bearing"),
                            settings.get("start_toward"))
    S = -1
    g.add_virtual(S, ss, True)
    ids, snaps = {}, []
    for i, t in enumerate(targets):
        if is_canceled and i % 50 == 0 and is_canceled():
            raise Canceled()
        st = g.nearest_segment(*t)
        snaps.append(st)
        T = -2 - i
        ids[T] = i
        g.add_virtual(T, st, False)
        _link_same_segment(g, S, ss, T, st)
    found, prev = g._dijkstra(S, set(ids), max(1, max_routes), is_canceled)
    if not found:
        raise RoutingError("Aucun élément trouvé n'est atteignable depuis le départ "
                           "(réseau non connecté : élargissez les types de voies).")
    out = []
    for T in found:
        res = g._path(S, T, prev)
        i = ids[T]
        res["target_index"] = i
        res["snap_start_m"], res["snap_end_m"] = ss[4], snaps[i][4]
        res["snap_start_name"] = g.way_of(ss[0], ss[1])[1]
        out.append(res)
    return out


def route_to_nearest(osm_json, start, targets, settings, is_canceled=None):
    """Itinéraire vers la cible la plus proche par la route."""
    return route_to_all(osm_json, start, targets, settings, 1, is_canceled)[0]
