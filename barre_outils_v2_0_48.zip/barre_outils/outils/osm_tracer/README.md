# OSM Tracer (plugin QGIS 3.28+ / 4.x)

Installation : Extensions > Installer depuis un ZIP > `osm_tracer_vX.Y.Z.zip`.
Version : voir `metadata.txt` et `CHANGELOG.md`. Numérotation : changement mineur → version mineure (x.**Y**.0), correctif → x.y.**Z**. Build : `python build.py [major|minor|patch]`.

1. Cliquer l'icône OSM Tracer (panneau à droite).
2. « Départ » puis clic sur la carte ; le clic suivant place l'arrivée.
3. Choisir un profil, ajuster le curseur Rapide ↔ Court, cocher les voies,
   modifier vitesses (km/h) et préférence (<1 favorise, >1 pénalise).
   Variante : cocher « Recherche d'élément(s) dans un rayon », puis dans le groupe
   « Recherche de la destination » (bas du panneau) choisir la couche, le rayon autour du départ et un filtre éventuel :
   l'itinéraire va vers l'élément du rayon le plus proche par la route.
4. « Calculer » : le tracé est ajouté à la couche mémoire « Itinéraires OSM »
   (distance, durée, détail km par type de voie).

Données : API Overpass (serveur modifiable dans le panneau). La dernière zone
téléchargée est mise en cache : changer les poids ne retélécharge rien.
Limite : ~100 km entre les points (charge Overpass).
RAVeL : détecté via les relations vélo / tags contenant « RAVeL ».

## Licences
- Données : © contributeurs OpenStreetMap, ODbL 1.0 — https://www.openstreetmap.org/copyright
  (toute carte utilisant une trace doit citer « © contributeurs OpenStreetMap »).
- Plugin : © 2026 skycrow2, GNU GPL v2 ou ultérieure (voir LICENSE).
