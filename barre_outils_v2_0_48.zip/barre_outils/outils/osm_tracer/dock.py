# -*- coding: utf-8 -*-
# OSM Tracer – plugin QGIS
# Copyright (C) 2026 skycrow2 <skycrow2@gmail.com>
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version. See the LICENSE file.
#
# SPDX-License-Identifier: GPL-2.0-or-later
# Données routières : © contributeurs OpenStreetMap, licence ODbL 1.0
import html
import os
import re

from qgis.core import (QgsApplication, QgsCoordinateReferenceSystem, QgsRasterLayer,
                       QgsVectorFileWriter,
                       QgsCoordinateTransform, QgsProject, QgsVectorLayer,
                       QgsFeature, QgsGeometry, QgsPointXY, QgsSettings, Qgis)
from qgis.core import (QgsProperty, QgsSymbolLayer, QgsFeatureRequest, QgsExpression,
                       QgsExpressionContext, QgsExpressionContextUtils,
                       QgsRectangle, QgsWkbTypes, QgsMessageLog,
                       QgsDistanceArea, QgsMapLayer)
from qgis.gui import (QgsMapToolEmitPoint, QgsVertexMarker, QgsColorButton,
                      QgsExpressionLineEdit, QgsRubberBand, QgsMapCanvasItem,
                      QgsMapCanvas, QgsMapToolPan)
from qgis.PyQt.QtCore import Qt, pyqtSignal, QTimer, QPointF, QRectF, QEvent, QSize
from qgis.PyQt.QtGui import QColor, QCursor, QIcon, QPixmap, QPainter, QPainterPath, QPen, QBrush, QFont, QPolygonF
from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QPushButton,
    QLineEdit, QComboBox, QLabel, QTableWidget, QTableWidgetItem,
    QCheckBox, QDoubleSpinBox, QSpinBox, QGroupBox, QHeaderView, QDialog, QTextBrowser,
    QDialogButtonBox, QScrollArea, QFrame, QTabWidget, QListWidget, QListWidgetItem,
    QSplitter, QMessageBox, QMenu, QToolButton, QStyle, QSizePolicy, QFileDialog)

from .help_text import HELP_HTML
from .version import __version__

from . import osm_router
from .tracer_task import RouteTask, OVERPASS_SERVERS, AUTO

WGS84 = QgsCoordinateReferenceSystem("EPSG:4326")
DEFAULT_OVERPASS = AUTO
DEFAULT_PROFILE = "Le plus court"
OSM_ATTRIBUTION = "© contributeurs OpenStreetMap"
OSM_LICENSE = "ODbL 1.0"
OSM_COPYRIGHT_URL = "https://www.openstreetmap.org/copyright"
TRACE_PALETTE = ["#e6007e", "#1f78b4", "#33a02c", "#ff7f00", "#6a3d9a",
                 "#e31a1c", "#00a6a6", "#b15928", "#7f7f7f", "#000000"]
START_COLOR = "#1a9641"
END_COLOR = "#d7191c"
MAX_TARGETS = 300   # nombre max. d'éléments candidats (les plus proches)
DISPLAY_CRS = [("WGS84 (EPSG:4326)", "EPSG:4326"),
               ("Lambert 72 (EPSG:31370)", "EPSG:31370"),
               ("Lambert 2008 (EPSG:3812)", "EPSG:3812")]


def _is_geom_vector(lyr):
    vt = getattr(QgsMapLayer, "LayerType", QgsMapLayer)
    vec = getattr(vt, "VectorLayer", None)
    if vec is None:
        vec = getattr(Qgis.LayerType, "Vector")
    return lyr.type() == vec and lyr.isSpatial()


def _polygon_type():
    gt = getattr(Qgis, "GeometryType", None)
    return gt.Polygon if gt is not None else QgsWkbTypes.PolygonGeometry


def _line_type():
    gt = getattr(Qgis, "GeometryType", None)
    return gt.Line if gt is not None else QgsWkbTypes.LineGeometry


def _meters_per_pixel(canvas):
    """Mètres par pixel au centre de la carte (quel que soit le SCR)."""
    da = QgsDistanceArea()
    da.setSourceCrs(canvas.mapSettings().destinationCrs(),
                    QgsProject.instance().transformContext())
    da.setEllipsoid("EPSG:7030")
    c = canvas.extent().center()
    upp = canvas.mapUnitsPerPixel()
    if upp <= 0:
        return 0
    d = da.measureLine(QgsPointXY(c.x(), c.y()), QgsPointXY(c.x() + upp * 100, c.y()))
    return d / 100.0


def _style_point(m, color, size=13):
    """Marqueur « point » : disque de la couleur du tracé, contour blanc."""
    m.setIconType(QgsVertexMarker.IconType.ICON_CIRCLE)
    m.setIconSize(size)
    m.setPenWidth(2)
    m.setColor(QColor("#ffffff"))
    fill = QColor(color)
    if hasattr(m, "setFillColor"):
        m.setFillColor(fill)
    else:
        m.setColor(fill)


OSM_XYZ = ("type=xyz&url=https://tile.openstreetmap.org/%7Bz%7D/%7Bx%7D/%7By%7D.png"
           "&zmax=19&zmin=0")


class PinMarker(QgsMapCanvasItem):
    """Repère en forme d'épingle (pointe = position), couleur pleine, cœur blanc."""

    def __init__(self, canvas, color, size=26):
        super().__init__(canvas)
        self.color = QColor(color)
        self.size = size
        self.center = None
        self.setZValue(20)

    def setCenter(self, pt):
        self.center = QgsPointXY(pt)
        self.updatePosition()

    def updatePosition(self):
        if self.center is not None:
            self.setPos(self.toCanvasCoordinates(self.center))

    def boundingRect(self):
        s = self.size
        return QRectF(-s / 2 - 2, -s - 2, s + 4, s + 4)

    def paint(self, p, *_args):
        s = self.size
        r = s * 0.34                      # rayon de la tête
        cy = -s + r + 1                   # centre de la tête
        path = QPainterPath()
        path.moveTo(0, 0)
        path.cubicTo(-r * 0.35, -s * 0.3, -r, cy + r * 0.55, -r, cy)
        path.arcTo(QRectF(-r, cy - r, 2 * r, 2 * r), 180, -180)
        path.cubicTo(r, cy + r * 0.55, r * 0.35, -s * 0.3, 0, 0)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(QPen(QColor(255, 255, 255, 230), 1.4))
        p.setBrush(QBrush(self.color))
        p.drawPath(path)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor("#ffffff")))
        p.drawEllipse(QPointF(0, cy), r * 0.42, r * 0.42)


class Section(QWidget):
    """Groupe repliable maison (en-tête flèche + titre, corps masquable), état
    mémorisé. Remplace QgsCollapsibleGroupBox dont le titre pouvait être rogné."""

    def __init__(self, title, key, collapsed=True):
        super().__init__()
        self.key = "osm_tracer/section_" + key
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(2)
        self.btn = QToolButton()
        self.btn.setText(title)
        self.btn.setCheckable(True)
        self.btn.setAutoRaise(True)
        self.btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.btn.setStyleSheet("QToolButton { border: none; font-weight: bold; "
                               "padding: 3px 2px; text-align: left; }")
        self.body = QFrame()
        self.body.setFrameShape(QFrame.Shape.StyledPanel)
        v.addWidget(self.btn)
        v.addWidget(self.body)
        open_ = not QgsSettings().value(self.key, collapsed, type=bool)
        self.btn.setChecked(open_)
        self._apply(open_)
        self.btn.toggled.connect(self._toggled)

    def _apply(self, open_):
        self.body.setVisible(open_)
        self.btn.setArrowType(Qt.ArrowType.DownArrow if open_ else Qt.ArrowType.RightArrow)

    def _toggled(self, open_):
        self._apply(open_)
        QgsSettings().setValue(self.key, not open_)

    def setTitle(self, title):
        self.btn.setText(title)

    def setCollapsed(self, collapsed):
        self.btn.setChecked(not collapsed)

    def isCollapsed(self):
        return not self.btn.isChecked()


class ResultMapTool(QgsMapToolPan):
    """Déplacement de la carte du résultat + clic simple (sans glisser) signalé."""
    clicked = pyqtSignal(QgsPointXY)

    def __init__(self, canvas):
        super().__init__(canvas)
        self._press = None
        self.hit_test = None    # fonction(point carte) -> index du tracé ou None
        self._hand = False

    def canvasMoveEvent(self, e):
        if e.buttons() == Qt.MouseButton.NoButton and self.hit_test is not None:
            hit = self.hit_test(e.mapPoint()) is not None
            if hit != self._hand:   # main au survol d'un tracé cliquable
                self._hand = hit
                self.canvas().setCursor(QCursor(Qt.CursorShape.PointingHandCursor if hit
                                                else Qt.CursorShape.OpenHandCursor))
            return
        super().canvasMoveEvent(e)

    def canvasPressEvent(self, e):
        self._press = e.pos()
        super().canvasPressEvent(e)

    def canvasReleaseEvent(self, e):
        p0, self._press = self._press, None
        super().canvasReleaseEvent(e)
        if p0 is not None and (e.pos() - p0).manhattanLength() <= 4:
            self.clicked.emit(e.mapPoint())


class MapOverlay(QWidget):
    """Échelle graphique + flèche du nord translucides, par-dessus une carte."""

    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        canvas.installEventFilter(self)
        canvas.extentsChanged.connect(self.update)
        self.resize(canvas.size())

    def eventFilter(self, obj, e):
        if obj is self.canvas and e.type() == QEvent.Type.Resize:
            self.resize(self.canvas.size())
        return False

    def paintEvent(self, _e):
        mpp = _meters_per_pixel(self.canvas)
        if mpp <= 0:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        bg = QBrush(QColor(255, 255, 255, 150))
        ink = QColor(40, 40, 40, 190)
        f = QFont(self.font())
        f.setPointSizeF(8)
        p.setFont(f)
        # --- échelle graphique (bas gauche)
        target = mpp * max(60, self.width() / 4)
        mag = 10 ** int(len(str(int(target))) - 1) if target >= 1 else 1
        nice = max(n * mag for n in (1, 2, 5, 10) if n * mag <= target) if target >= 1 else 1
        px = nice / mpp
        label = ("%g km" % (nice / 1000)) if nice >= 1000 else "%g m" % nice
        scale = "1:%s" % format(int(round(self.canvas.scale())), ",").replace(",", " ")
        x0, y0 = 10, self.height() - 14
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(bg)
        p.drawRoundedRect(QRectF(x0 - 6, y0 - 30, px + 12 + 70, 40), 4, 4)
        p.setPen(QPen(ink, 1.5))
        p.drawLine(QPointF(x0, y0), QPointF(x0 + px, y0))
        for x in (x0, x0 + px / 2, x0 + px):
            p.drawLine(QPointF(x, y0), QPointF(x, y0 - (6 if x != x0 + px / 2 else 4)))
        p.drawText(QPointF(x0, y0 - 10), label)
        p.drawText(QPointF(x0 + px + 8, y0 - 1), scale)
        # --- flèche du nord (haut droit)
        cx, cy, r = self.width() - 26, 30, 14
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(bg)
        p.drawEllipse(QPointF(cx, cy + 2), r + 6, r + 6)
        p.translate(cx, cy + 2)
        p.rotate(-self.canvas.rotation())
        p.setBrush(QBrush(ink))
        p.drawPolygon(QPolygonF([QPointF(0, -r), QPointF(r * 0.5, r * 0.6),
                                 QPointF(0, r * 0.25), QPointF(-r * 0.5, r * 0.6)]))
        p.resetTransform()
        p.setPen(QPen(ink))
        p.drawText(QRectF(cx - 10, cy - r - 4, 20, 10), Qt.AlignmentFlag.AlignCenter, "N")
        # --- attribution du fond OSM (bas droit)
        txt = "© contributeurs OpenStreetMap"
        tw = p.fontMetrics().horizontalAdvance(txt) + 8
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(bg)
        p.drawRect(QRectF(self.width() - tw, self.height() - 14, tw, 14))
        p.setPen(QPen(ink))
        p.drawText(QRectF(self.width() - tw, self.height() - 14, tw, 14),
                   Qt.AlignmentFlag.AlignCenter, txt)
        p.end()


def _local_crs(lonlat):
    """Projection azimutale équidistante centrée sur le point (mètres)."""
    return QgsCoordinateReferenceSystem.fromProj(
        "+proj=aeqd +lat_0=%.8f +lon_0=%.8f +datum=WGS84 +units=m +no_defs"
        % (lonlat[1], lonlat[0]))


class PointPickTool(QgsMapToolEmitPoint):
    picked = pyqtSignal(QgsPointXY)

    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvasClicked.connect(lambda pt, _btn: self.picked.emit(pt))


class HeightGrip(QFrame):
    """Poignée à glisser verticalement pour redimensionner un widget."""

    def __init__(self, target, settings_key, min_h=60, max_h=1200):
        super().__init__()
        self.target, self.key = target, settings_key
        self.min_h, self.max_h = min_h, max_h
        self.setFixedHeight(8)
        self.setCursor(Qt.CursorShape.SizeVerCursor)
        self.setToolTip("Glisser pour redimensionner (double-clic : taille d'origine)")
        self.setFrameShape(QFrame.Shape.HLine)
        self.setFrameShadow(QFrame.Shadow.Sunken)
        self._y0 = self._h0 = None

    def mousePressEvent(self, e):
        self._y0 = e.globalPosition().y() if hasattr(e, "globalPosition") else e.globalY()
        self._h0 = self.target.height()

    def mouseMoveEvent(self, e):
        if self._y0 is None:
            return
        y = e.globalPosition().y() if hasattr(e, "globalPosition") else e.globalY()
        h = int(max(self.min_h, min(self.max_h, self._h0 + y - self._y0)))
        self.target.setFixedHeight(h)

    def mouseReleaseEvent(self, e):
        if self._y0 is not None:
            QgsSettings().setValue(self.key, self.target.height())
        self._y0 = None

    def mouseDoubleClickEvent(self, e):
        QgsSettings().remove(self.key)
        self.target.setFixedHeight(self.default_h)


class TracerDock(QDockWidget):
    def __init__(self, iface):
        super().__init__("OSM Tracer v%s" % __version__)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.points = {"start": None, "end": None}       # WGS84 (lon, lat)
        self.markers = {"start": None, "end": None}
        self.found_markers = []     # croix sur les éléments atteints
        self.circle = None      # cercle du rayon de recherche
        self.dir_arrow = None   # flèche de la direction de départ
        self._res_markers = []  # marqueurs de la carte du résultat
        self._job = None        # contexte du calcul en cours
        self.task = None
        self.layer = None
        self.tool = PointPickTool(self.canvas)
        self.tool.picked.connect(self._on_picked)
        self._picking = None
        self._prev_tool = None
        self._build_ui()
        self.cb_profile.setCurrentText(DEFAULT_PROFILE)
        self._apply_profile(self.cb_profile.currentText())
        self.canvas.destinationCrsChanged.connect(self._update_circle)
        self.canvas.scaleChanged.connect(self._update_circle)
        prj = QgsProject.instance()
        prj.layersAdded.connect(self._refresh_layer_list)
        prj.layersRemoved.connect(self._refresh_layer_list)
        prj.layersRemoved.connect(lambda *_: QTimer.singleShot(0, self._update_clear_button))
        # Le cercle disparaît à la fermeture du panneau et au rafraîchissement de la carte
        self.visibilityChanged.connect(
            lambda visible: self._update_circle() if visible else self._remove_circle())
        self.iface.actionDraw().triggered.connect(self._remove_circle)

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        st = QgsSettings()
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(4)

        # Points
        g = QGroupBox("Points")
        gl = QGridLayout(g)
        gl.setContentsMargins(6, 4, 6, 4)
        gl.setVerticalSpacing(2)
        self.le, self.btn_pick = {}, {}
        for row, (key, label) in enumerate((("start", "Départ"), ("end", "Arrivée"))):
            btn = QPushButton(" " + label)
            btn.setIcon(QIcon(os.path.join(os.path.dirname(__file__), "icons", key + ".svg")))
            btn.setIconSize(QSize(18, 18))
            btn.setToolTip("Cliquer puis sélectionner le point sur la carte")
            btn.clicked.connect(lambda _=False, k=key: self._start_pick(k))
            le = QLineEdit()
            le.setReadOnly(True)
            self.le[key] = le
            self.btn_pick[key] = btn
            gl.addWidget(btn, row, 0)
            gl.addWidget(le, row, 1, 1, 2)
        self.cb_crs = QComboBox()
        for label, authid in DISPLAY_CRS:
            self.cb_crs.addItem(label, authid)
        self.cb_crs.setToolTip("Système d'affichage des coordonnées")
        idx = self.cb_crs.findData(st.value("osm_tracer/display_crs", "EPSG:4326"))
        self.cb_crs.setCurrentIndex(max(idx, 0))
        self.cb_crs.currentIndexChanged.connect(self._refresh_coords)
        self.btn_swap = swap = QPushButton("⇅")
        swap.setToolTip("Inverser départ et arrivée")
        swap.setFixedWidth(32)
        swap.clicked.connect(self._swap)
        gl.addWidget(QLabel("Coord."), 2, 0)
        gl.addWidget(self.cb_crs, 2, 1)
        gl.addWidget(swap, 2, 2)
        self.chk_search = QCheckBox("Recherche d'élément(s) dans un rayon")
        self.chk_search.setIcon(QIcon(os.path.join(os.path.dirname(__file__), "icons",
                                                   "search.svg")))
        self.chk_search.setToolTip(
            "Pas de point d'arrivée : la destination est l'élément de la couche choisie, "
            "situé dans le rayon autour du départ, le plus proche par la route")
        gl.addWidget(self.chk_search, 3, 0, 1, 3)
        self.chk_dir = QCheckBox("Direction de la voie")
        self.chk_dir.setIcon(QIcon(os.path.join(os.path.dirname(__file__), "icons",
                                                "direction.svg")))
        self.chk_dir.setToolTip("Option : le départ s'accroche à la première voie rencontrée "
                                "dans cette direction (azimut, 0° = nord, sens horaire) "
                                "au lieu de la voie la plus proche")
        self.spin_dir = QDoubleSpinBox()
        self.spin_dir.setRange(0, 359.9)
        self.spin_dir.setDecimals(0)
        self.spin_dir.setWrapping(True)
        self.spin_dir.setSingleStep(15)
        self.spin_dir.setSuffix(" °")
        self.spin_dir.setEnabled(False)
        self.btn_dir = QPushButton("Pointer")
        self.btn_dir.setToolTip("Cliquer sur la carte un point dans la direction de la voie")
        self.btn_dir.setEnabled(False)
        self.btn_dir.clicked.connect(lambda: self._start_pick("dir"))
        self.chk_dir.toggled.connect(self.spin_dir.setEnabled)
        self.chk_dir.toggled.connect(self.btn_dir.setEnabled)
        self.chk_dir.toggled.connect(self._update_circle)
        self.chk_dir.toggled.connect(
            lambda on: self._start_pick("dir") if on and self.points["start"] else None)
        self.spin_dir.valueChanged.connect(lambda *_: setattr(self, "_arrow_faded", False))
        self.spin_dir.valueChanged.connect(self._update_circle)
        self._dir_point = None
        # angle saisi à la main : on oublie la voie visée par le clic
        self.spin_dir.editingFinished.connect(lambda: setattr(self, "_dir_point", None))
        hd = QHBoxLayout()
        hd.addWidget(self.chk_dir)
        hd.addWidget(self.spin_dir, 1)
        hd.addWidget(self.btn_dir)
        gl.addLayout(hd, 4, 0, 1, 3)
        lay.addWidget(g)

        # Profil
        g = QGroupBox("Profil")
        gl = QGridLayout(g)
        gl.setContentsMargins(6, 4, 6, 4)
        gl.setVerticalSpacing(2)
        self.cb_profile = QComboBox()
        self.cb_profile.addItems(list(osm_router.PROFILES))
        self.cb_profile.currentTextChanged.connect(self._apply_profile)
        self.chk_oneway = QCheckBox("Sens uniques")
        self.chk_oneway.setToolTip("Respecter les sens uniques")
        self.chk_motor = QCheckBox("Motorisé")
        self.chk_motor.setToolTip("Véhicule motorisé : limitations de vitesse et interdictions d'accès")
        gl.addWidget(self.cb_profile, 0, 0, 1, 2)
        gl.addWidget(self.chk_oneway, 1, 0)
        gl.addWidget(self.chk_motor, 1, 1)
        lay.addWidget(g)

        # Actions + résultat (toujours visibles en haut)
        h = QHBoxLayout()
        self.btn_run = QPushButton("▶ Calculer")
        self.btn_run.clicked.connect(self.run)
        self.btn_stop = QPushButton("■ Arrêter")
        self.btn_stop.setToolTip("Arrêter le téléchargement / calcul en cours")
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self.stop)
        self.btn_clear = clear = QPushButton()
        clear.setIcon(QIcon(os.path.join(os.path.dirname(__file__), "icons", "refresh.svg")))
        clear.setIconSize(QSize(18, 18))
        clear.setFixedWidth(34)
        clear.setToolTip("Effacer les tracés et réinitialiser")
        clear.setEnabled(False)       # actif seulement s'il y a des tracés
        clear.clicked.connect(self._on_clear_clicked)
        for b in (self.btn_run, self.btn_stop, clear):
            h.addWidget(b)
        lay.addLayout(h)
        self.lbl_result = QLabel()
        self.lbl_result.setWordWrap(True)
        self.lbl_result.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.lbl_result.setFrameShape(QFrame.Shape.StyledPanel)
        self.lbl_result.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.lbl_result.setStyleSheet("QLabel { padding: 4px 8px; font-size: 9pt; }")
        self.lbl_result.setVisible(False)
        self.txt_result = QTextBrowser()
        self.txt_result.setFrameShape(QFrame.Shape.NoFrame)
        self.txt_result.setStyleSheet("QTextBrowser { padding: 6px; font-size: 10pt; }")
        self.txt_result.setOpenLinks(False)
        self.txt_result.document().setDefaultStyleSheet("a { text-decoration: none; }")
        self.txt_result.setToolTip("Cliquer sur un tracé pour le faire clignoter sur les cartes")
        self.txt_result.anchorClicked.connect(self._on_result_clicked)

        # Types de voies (repliable)
        self.grp_types = Section("Types de voies", "types")
        vl = QVBoxLayout(self.grp_types.body)
        vl.setContentsMargins(2, 2, 2, 2)
        self.table = QTableWidget(len(osm_router.ROAD_TYPES), 3)
        self.table.setHorizontalHeaderLabels(["Voie", "km/h", "Préf."])
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        vh = self.table.verticalHeader()
        vh.setVisible(False)
        vh.setDefaultSectionSize(22)
        self.table.setToolTip("Préf. : < 1 favorise la voie, > 1 la pénalise")
        self.spin_speed, self.spin_factor = {}, {}
        for i, (key, label, _hw, speed, on) in enumerate(osm_router.ROAD_TYPES):
            it = QTableWidgetItem(label)
            it.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            it.setCheckState(Qt.CheckState.Checked if on else Qt.CheckState.Unchecked)
            it.setData(Qt.ItemDataRole.UserRole, key)
            self.table.setItem(i, 0, it)
            sp = QDoubleSpinBox()
            sp.setRange(1, 200)
            sp.setDecimals(0)
            sp.setValue(speed)
            sp.setFrame(False)
            self.spin_speed[key] = sp
            self.table.setCellWidget(i, 1, sp)
            fp = QDoubleSpinBox()
            fp.setRange(0.1, 10)
            fp.setSingleStep(0.1)
            fp.setValue(1.0)
            fp.setFrame(False)
            self.spin_factor[key] = fp
            self.table.setCellWidget(i, 2, fp)
        full_h = hh.height() + 22 * self.table.rowCount() + 4
        self.table.setFixedHeight(int(st.value("osm_tracer/types_height", full_h)))
        self.table.itemChanged.connect(self._update_types_title)
        vl.addWidget(self.table)
        grip = HeightGrip(self.table, "osm_tracer/types_height")
        grip.default_h = full_h
        vl.addWidget(grip)
        lay.addWidget(self.grp_types)

        # Recherche de destination (visible si la case est cochée)
        self.grp_search = self._build_search_tab(st)
        lay.addWidget(self.grp_search)

        # Options : style + serveur (fenêtre ouverte par l'engrenage de la barre de titre)
        self._opt_dlg = dlg = QDialog(self)
        dlg.setWindowTitle("OSM Tracer – Options")
        dlg.setWindowFlags(Qt.WindowType.Tool | Qt.WindowType.WindowCloseButtonHint)
        dv = QVBoxLayout(dlg)
        dv.setContentsMargins(8, 8, 8, 8)
        g = QWidget()
        gl = QGridLayout(g)
        gl.setContentsMargins(0, 0, 0, 0)
        self.btn_color = QgsColorButton()
        self.btn_color.setColor(QColor(st.value("osm_tracer/color", "#e6007e")))
        self.btn_color.setToolTip("Couleur de la première trace ; les suivantes prennent automatiquement une autre couleur")
        self.spin_width = QDoubleSpinBox()
        self.spin_width.setRange(0.1, 10)
        self.spin_width.setSingleStep(0.1)
        self.spin_width.setSuffix(" mm")
        w0 = float(st.value("osm_tracer/width", 0.4))
        # anciens défauts (1,2 puis 0,6 mm) jugés trop épais -> 0,4 mm
        self.spin_width.setValue(0.4 if any(abs(w0 - v) < 1e-6 for v in (1.2, 0.6)) else w0)
        gl.addWidget(QLabel("Trace"), 0, 0)
        gl.addWidget(self.btn_color, 0, 1)
        gl.addWidget(self.spin_width, 0, 2)
        self.cb_server = QComboBox()
        self.cb_server.setEditable(True)
        self.cb_server.addItems([AUTO] + OVERPASS_SERVERS)
        self.cb_server.setToolTip("Auto : essaie chaque serveur jusqu'à réussite. "
                                  "Vous pouvez aussi saisir une autre URL.")
        saved = st.value("osm_tracer/overpass", DEFAULT_OVERPASS)
        if saved == OVERPASS_SERVERS[0]:   # ancien défaut (v1.1.0) -> Auto
            saved = AUTO
        self.cb_server.setCurrentText(saved)
        gl.addWidget(QLabel("Overpass"), 1, 0)
        gl.addWidget(self.cb_server, 1, 1, 1, 2)
        self.chk_time = QCheckBox("Afficher la durée (minutes)")
        self.chk_time.setChecked(st.value("osm_tracer/show_time", False, type=bool))
        self.chk_time.toggled.connect(
            lambda v: (QgsSettings().setValue("osm_tracer/show_time", v), self._show_result()))
        gl.addWidget(self.chk_time, 2, 0, 1, 3)
        self.chk_speed = QCheckBox("Afficher la colonne km/h (Types de voies)")
        self.chk_speed.setChecked(st.value("osm_tracer/show_speed", False, type=bool))
        self.chk_speed.toggled.connect(self._toggle_speed_col)
        gl.addWidget(self.chk_speed, 3, 0, 1, 3)
        self._toggle_speed_col(self.chk_speed.isChecked())
        self.chk_pref = QCheckBox("Afficher la colonne Préférence (Types de voies)")
        self.chk_pref.setChecked(st.value("osm_tracer/show_pref", False, type=bool))
        self.chk_pref.toggled.connect(self._toggle_pref_col)
        gl.addWidget(self.chk_pref, 4, 0, 1, 3)
        self._toggle_pref_col(self.chk_pref.isChecked())
        dv.addWidget(g)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        bb.rejected.connect(dlg.close)
        dv.addWidget(bb)

        lay.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(w)
        # Résultat épinglé en bas du panneau, hors zone de défilement
        outer = QWidget()
        ov = QVBoxLayout(outer)
        ov.setContentsMargins(0, 0, 0, 4)
        ov.setSpacing(4)
        self.tabs = QTabWidget()
        self.tabs.addTab(scroll, "Itinéraire")
        self.res_canvas = QgsMapCanvas()
        self.res_canvas.setMinimumHeight(160)
        self.res_canvas.enableAntiAliasing(True)
        self.res_pan = ResultMapTool(self.res_canvas)
        self.res_pan.clicked.connect(self._on_result_map_clicked)
        self.res_pan.hit_test = self._hit_route
        self.res_canvas.setMapTool(self.res_pan)
        self.res_overlay = MapOverlay(self.res_canvas)
        self.res_split = QSplitter(Qt.Orientation.Vertical)
        self.res_split.addWidget(self.txt_result)
        self.res_split.addWidget(self.res_canvas)
        self.res_split.setStretchFactor(0, 1)
        self.res_split.setStretchFactor(1, 1)
        self.osm_bg = None   # fond OSM (couche hors projet, créée à la demande)
        self.tabs.addTab(self.res_split, "Résultat")
        self._set_result_html(None)
        ov.addWidget(self.tabs, 1)
        ov.addWidget(self.lbl_result)
        attr = QLabel("<small>Données <a href='%s'>%s</a> (%s) · "
                      "OSM Tracer v%s – GPL v2+</small>"
                      % (OSM_COPYRIGHT_URL, OSM_ATTRIBUTION, OSM_LICENSE, __version__))
        attr.setOpenExternalLinks(True)
        attr.setAlignment(Qt.AlignmentFlag.AlignRight)
        ov.addWidget(attr)
        self.setWidget(outer)
        self.setTitleBarWidget(self._build_title_bar())
        self._refresh_coords()
        self.chk_search.toggled.connect(self._toggle_search)
        self.chk_search.setChecked(st.value("osm_tracer/search_mode", False, type=bool))
        self._toggle_search(self.chk_search.isChecked())
        # Bouton Calculer mis en évidence quand tout est prêt (et pas encore calculé)
        self._dirty = True
        for sig in (self.chk_search.toggled, self.chk_dir.toggled, self.spin_dir.valueChanged,
                    self.cb_profile.currentTextChanged, self.chk_oneway.toggled,
                    self.chk_motor.toggled, self.table.itemChanged,
                    self.lst_layers.itemChanged, self.spin_radius.valueChanged,
                    self.spin_routes.valueChanged, self.le_filter.expressionChanged,
                    self.chk_selected.toggled):
            sig.connect(self._mark_dirty)
        for sp in list(self.spin_speed.values()) + list(self.spin_factor.values()):
            sp.valueChanged.connect(self._mark_dirty)
        self._update_run_button()

    def _mark_dirty(self, *_):
        self._dirty = True
        self._update_run_button()

    def _is_ready(self):
        if not self.points["start"]:
            return False
        if self.chk_search.isChecked():
            if not self._search_layers():
                return False
        elif not self.points["end"]:
            return False
        return any(self.table.item(i, 0).checkState() == Qt.CheckState.Checked
                   for i in range(self.table.rowCount()))

    def _update_run_button(self):
        if not hasattr(self, "btn_run"):
            return
        hot = self.btn_run.isEnabled() and getattr(self, "_dirty", True) and self._is_ready()
        self.btn_run.setStyleSheet(
            "QPushButton { background-color: #cfe3fa; color: #1b4f8a; font-weight: bold; "
            "border: 1px solid #8fb8e8; border-radius: 3px; padding: 3px 8px; }"
            "QPushButton:hover { background-color: #bcd7f7; }" if hot else "")
        self.btn_run.setToolTip("Prêt : lancer le calcul" if hot else "Lancer le calcul")
    def _build_title_bar(self):
        """Barre de titre : nom + version, aide, détacher, fermer."""
        bar = QWidget()
        h = QHBoxLayout(bar)
        h.setContentsMargins(6, 2, 2, 2)
        h.setSpacing(2)
        here = os.path.dirname(__file__)
        self.btn_options = b = QToolButton()
        b.setIcon(QIcon(os.path.join(here, "icons", "settings.svg")))
        b.setToolTip("Options : trace, serveur Overpass, affichage")
        b.setAutoRaise(True)
        b.setIconSize(QSize(16, 16))
        b.clicked.connect(self.show_options)
        h.addWidget(QLabel("OSM Tracer <span style='color:#8a8a8a'>v%s</span>" % __version__))
        h.addStretch()
        h.addWidget(b)                      # engrenage en haut à droite, avant l'aide

        def tool(icon, tip, slot):
            b = QToolButton()
            b.setIcon(icon)
            b.setToolTip(tip)
            b.setAutoRaise(True)
            b.setIconSize(QSize(16, 16))
            b.clicked.connect(slot)
            h.addWidget(b)
            return b

        st = self.style()
        tool(QIcon(os.path.join(here, "icons", "help.svg")), "Aide", self.show_help)
        tool(st.standardIcon(QStyle.StandardPixmap.SP_TitleBarNormalButton), "Détacher / ancrer",
             lambda: self.setFloating(not self.isFloating()))
        tool(st.standardIcon(QStyle.StandardPixmap.SP_TitleBarCloseButton), "Fermer", self.close)
        return bar

    def _build_search_tab(self, st):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(2)
        g = Section("Recherche de la destination", "search", collapsed=False)
        g.setToolTip("Éléments dans le rayon autour du départ ; destination = le plus "
                     "proche par la route (lignes / polygones : point le plus proche)")
        gl = QGridLayout(g.body)
        gl.setContentsMargins(6, 4, 6, 4)
        self.lst_layers = QListWidget()
        self.lst_layers.setToolTip("Cochez les couches (points, lignes, polygones) où chercher")
        self.lst_layers.setMaximumHeight(110)
        ids = st.value("osm_tracer/search_layers", "") or st.value("osm_tracer/search_layer", "")
        self._search_ids = set(i for i in str(ids).split(";") if i)
        self.lst_layers.itemChanged.connect(self._on_layer_item)
        gl.addWidget(QLabel("Couches"), 0, 0, Qt.AlignmentFlag.AlignTop)
        gl.addWidget(self.lst_layers, 0, 1)
        self.spin_radius = QDoubleSpinBox()
        self.spin_radius.setRange(1, 50000)
        self.spin_radius.setDecimals(0)
        self.spin_radius.setSingleStep(100)
        self.spin_radius.setSuffix(" m")
        self.spin_radius.setValue(float(st.value("osm_tracer/search_radius", 1000)))
        self.spin_radius.setToolTip("Rayon à vol d'oiseau autour du point de départ")
        self.spin_radius.valueChanged.connect(self._update_circle)
        gl.addWidget(QLabel("Rayon"), 1, 0)
        gl.addWidget(self.spin_radius, 1, 1)
        self.spin_routes = QSpinBox()
        self.spin_routes.setRange(1, 50)
        self.spin_routes.setValue(int(st.value("osm_tracer/search_routes", 5)))
        self.spin_routes.setToolTip("Nombre maximum de tracés : les éléments les plus "
                                    "proches par la route, un tracé (et une couleur) chacun")
        gl.addWidget(QLabel("Tracés max"), 5, 0)
        gl.addWidget(self.spin_routes, 5, 1)
        self.le_filter = QgsExpressionLineEdit()
        self.le_filter.setToolTip("Filtre optionnel (expression QGIS), ex. \"type\" = 'hôpital'")
        self.le_filter.setExpression(st.value("osm_tracer/search_filter", ""))
        gl.addWidget(QLabel("Filtre"), 2, 0)
        gl.addWidget(self.le_filter, 2, 1)
        self.chk_selected = QCheckBox("Uniquement les entités sélectionnées")
        self.chk_selected.setChecked(st.value("osm_tracer/search_selected", False, type=bool))
        gl.addWidget(self.chk_selected, 3, 0, 1, 2)
        self.chk_circle = QCheckBox("Afficher le rayon sur la carte")
        self.chk_circle.setChecked(st.value("osm_tracer/search_circle", True, type=bool))
        self.chk_circle.toggled.connect(self._update_circle)
        gl.addWidget(self.chk_circle, 4, 0, 1, 2)
        v.addWidget(g)
        self.le_filter.setToolTip(
            "Filtre optionnel (expression QGIS), ex. \"type\" = 'hôpital'. Appliqué aux "
            "couches qui possèdent les champs utilisés.")
        self._refresh_layer_list()
        return w

    def _search_layers(self):
        prj = QgsProject.instance()
        return [l for l in (prj.mapLayer(i) for i in self._search_ids) if l is not None]

    def _refresh_layer_list(self, *_):
        """(Re)remplit la liste des couches cochables de recherche."""
        if not hasattr(self, "lst_layers"):
            return
        self.lst_layers.blockSignals(True)
        self.lst_layers.clear()
        route_id = self.layer.id() if self._route_layer_in_project() else None
        layers = [l for l in QgsProject.instance().mapLayers().values()
                  if _is_geom_vector(l) and l.id() != route_id]
        for l in sorted(layers, key=lambda x: x.name().lower()):
            it = QListWidgetItem(l.name())
            it.setData(Qt.ItemDataRole.UserRole, l.id())
            it.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            it.setCheckState(Qt.CheckState.Checked if l.id() in self._search_ids
                             else Qt.CheckState.Unchecked)
            self.lst_layers.addItem(it)
        self.lst_layers.blockSignals(False)
        self._sync_filter_layer()

    def _on_layer_item(self, it):
        lid = it.data(Qt.ItemDataRole.UserRole)
        if it.checkState() == Qt.CheckState.Checked:
            self._search_ids.add(lid)
        else:
            self._search_ids.discard(lid)
        QgsSettings().setValue("osm_tracer/search_layers", ";".join(sorted(self._search_ids)))
        self._sync_filter_layer()

    def _sync_filter_layer(self):
        lyrs = self._search_layers()
        self.le_filter.setLayer(lyrs[0] if lyrs else None)

    def _remove_circle(self, *_):
        """Retire les repères temporaires : cercle de recherche et flèche de direction."""
        for attr in ("circle", "dir_arrow"):
            item = getattr(self, attr)
            if item is not None:
                self.canvas.scene().removeItem(item)
                setattr(self, attr, None)

    def _toggle_search(self, on):
        QgsSettings().setValue("osm_tracer/search_mode", on)
        self.btn_pick["end"].setVisible(not on)
        self.le["end"].setVisible(not on)
        self.btn_swap.setEnabled(not on)
        if self.markers["end"]:
            self.markers["end"].setVisible(not on)
        for m in self.found_markers:
            m.setVisible(on)
        self.grp_search.setVisible(on)
        self._update_circle()

    def _update_circle(self, *_):
        QgsSettings().setValue("osm_tracer/search_circle", self.chk_circle.isChecked())
        self._remove_circle()
        if self.points["start"] and self.chk_dir.isChecked():
            self._draw_dir_arrow()
        if not (self.chk_search.isChecked() and self.chk_circle.isChecked()
                and self.points["start"]):
            return
        geom = QgsGeometry.fromPointXY(QgsPointXY(0, 0)).buffer(self.spin_radius.value(), 36)
        self.circle = QgsRubberBand(self.canvas, _polygon_type())
        self.circle.setStrokeColor(QColor(30, 120, 220, 200))
        self.circle.setFillColor(QColor(30, 120, 220, 30))
        self.circle.setWidth(2)
        self.circle.setToGeometry(geom, _local_crs(self.points["start"]))

    def _draw_dir_arrow(self):
        """Flèche (60 px) partant du départ dans la direction choisie."""
        import math
        ms = self.canvas.mapSettings()
        L = self.canvas.scale() * 0.0254 / max(ms.outputDpi(), 1) * 32
        a = math.radians(self.spin_dir.value())
        def pt(r, ang):
            return QgsPointXY(r * math.sin(ang), r * math.cos(ang))
        tip = pt(L, a)
        h = L * 0.3
        head1 = QgsPointXY(tip.x() + h * math.sin(a + math.radians(150)),
                           tip.y() + h * math.cos(a + math.radians(150)))
        head2 = QgsPointXY(tip.x() + h * math.sin(a - math.radians(150)),
                           tip.y() + h * math.cos(a - math.radians(150)))
        geom = QgsGeometry.fromMultiPolylineXY([[QgsPointXY(0, 0), tip], [head1, tip, head2]])
        self.dir_arrow = QgsRubberBand(self.canvas, _line_type())
        # translucide une fois le calcul terminé
        alpha = 70 if getattr(self, "_arrow_faded", False) else 220
        self.dir_arrow.setStrokeColor(QColor(26, 150, 65, alpha))
        self.dir_arrow.setWidth(2)
        self.dir_arrow.setToGeometry(geom, _local_crs(self.points["start"]))

    # --------------------------------------------------------- Coordonnées
    def _fmt(self, lonlat):
        if lonlat is None:
            return ""
        authid = self.cb_crs.currentData()
        if authid == "EPSG:4326":
            return "%.6f, %.6f" % lonlat
        xf = QgsCoordinateTransform(WGS84, QgsCoordinateReferenceSystem(authid),
                                    QgsProject.instance())
        p = xf.transform(QgsPointXY(*lonlat))
        return "%.2f, %.2f" % (p.x(), p.y())

    def _refresh_coords(self, *_):
        authid = self.cb_crs.currentData()
        QgsSettings().setValue("osm_tracer/display_crs", authid)
        ph = "lon, lat" if authid == "EPSG:4326" else "X, Y"
        for k, le in self.le.items():
            le.setPlaceholderText(ph)
            le.setText(self._fmt(self.points[k]))
            le.setToolTip("WGS84 : %s" % ("%.6f, %.6f" % self.points[k]
                                          if self.points[k] else "-"))

    def _toggle_speed_col(self, show):
        QgsSettings().setValue("osm_tracer/show_speed", show)
        self.table.setColumnHidden(1, not show)

    def _toggle_pref_col(self, show):
        QgsSettings().setValue("osm_tracer/show_pref", show)
        self.table.setColumnHidden(2, not show)

    @staticmethod
    def _set_copyright(layer):
        """Attribution OSM obligatoire (ODbL) : métadonnées + propriétés serveur."""
        md = layer.metadata()
        md.setRights(["%s – %s" % (OSM_ATTRIBUTION, OSM_COPYRIGHT_URL)])
        md.setLicenses([OSM_LICENSE + " – https://opendatacommons.org/licenses/odbl/1-0/"])
        md.setAbstract("Itinéraire calculé par OSM Tracer à partir des données "
                       "OpenStreetMap (API Overpass). Base de données dérivée soumise "
                       "à la licence ODbL : citer « %s »." % OSM_ATTRIBUTION)
        layer.setMetadata(md)
        try:
            sp = layer.serverProperties()
            sp.setAttribution(OSM_ATTRIBUTION)
            sp.setAttributionUrl(OSM_COPYRIGHT_URL)
        except AttributeError:   # anciennes versions de QGIS
            layer.setAttribution(OSM_ATTRIBUTION)
            layer.setAttributionUrl(OSM_COPYRIGHT_URL)

    def _coord_attr(self, key):
        return "%s (%s)" % (self.le[key].text(), self.cb_crs.currentData())

    def _update_types_title(self, *_):
        n = sum(self.table.item(i, 0).checkState() == Qt.CheckState.Checked
                for i in range(self.table.rowCount()))
        self.grp_types.setTitle("Types de voies (%d/%d)" % (n, self.table.rowCount()))

    # ------------------------------------------------------------ Profils
    def _apply_profile(self, name):
        p = osm_router.PROFILES[name]
        self.chk_oneway.setChecked(p["oneway"])
        self.chk_motor.setChecked(p["motor"])
        defaults = {r[0]: r[3] for r in osm_router.ROAD_TYPES}
        for i in range(self.table.rowCount()):
            it = self.table.item(i, 0)
            key = it.data(Qt.ItemDataRole.UserRole)
            it.setCheckState(Qt.CheckState.Checked if key in p["enabled"]
                             else Qt.CheckState.Unchecked)
            self.spin_speed[key].setValue(p.get("speeds", {}).get(key, defaults[key]))
            self.spin_factor[key].setValue(p.get("factors", {}).get(key, 1.0))

    def _weight(self):
        """Poids rapide (0) / court (1) défini par le profil."""
        return osm_router.PROFILES[self.cb_profile.currentText()]["weight"]

    def settings(self):
        enabled = []
        for i in range(self.table.rowCount()):
            it = self.table.item(i, 0)
            if it.checkState() == Qt.CheckState.Checked:
                enabled.append(it.data(Qt.ItemDataRole.UserRole))
        return dict(enabled=enabled,
                    speeds={k: s.value() for k, s in self.spin_speed.items()},
                    factors={k: s.value() for k, s in self.spin_factor.items()},
                    weight=self._weight(),
                    oneway=self.chk_oneway.isChecked(),
                    motor=self.chk_motor.isChecked(),
                    start_bearing=self.spin_dir.value() if self.chk_dir.isChecked() else None,
                    start_toward=self._dir_point if self.chk_dir.isChecked() else None)

    # -------------------------------------------------------- Sélection
    def _start_pick(self, key):
        self._picking = key
        if key in ("start", "end"):
            self._set_point(key, None)    # nouveau clic : l'ancien point est retiré
        cur = self.canvas.mapTool()
        if cur is not self.tool:
            self._prev_tool = cur
        self.canvas.setMapTool(self.tool)
        self.iface.messageBar().pushMessage(
            "OSM Tracer",
            "Cliquez sur la carte dans la direction de la voie" if key == "dir" else
            "Cliquez sur la carte pour le point de %s"
            % ("départ" if key == "start" else "arrivée"), Qgis.MessageLevel.Info, 3)

    def _on_picked(self, pt):
        key = self._picking
        if not key:
            return
        xf = QgsCoordinateTransform(self.canvas.mapSettings().destinationCrs(),
                                    WGS84, QgsProject.instance())
        p = xf.transform(pt)
        if key == "dir":
            if self.points["start"]:
                self.spin_dir.setValue(round(osm_router.bearing_deg(
                    self.points["start"][0], self.points["start"][1], p.x(), p.y())))
                self._dir_point = (p.x(), p.y())   # voie visée par le clic
            else:
                self.iface.messageBar().pushMessage(
                    "OSM Tracer", "Placez d'abord le point de départ.",
                    Qgis.MessageLevel.Warning, 3)
        else:
            self._set_point(key, (p.x(), p.y()), pt)
        self._picking = None
        # Clics enchaînés : départ -> (direction) -> arrivée (mode deux points)
        nxt = None
        if key == "start":
            # l'arrivée n'est redemandée que si elle n'est pas déjà placée
            self._chain_end = not self.chk_search.isChecked() and not self.points["end"]
            if self.chk_dir.isChecked():
                nxt = "dir"
            elif self._chain_end:
                nxt = "end"
        elif key == "dir" and getattr(self, "_chain_end", False):
            nxt = "end"
        if key in ("end", "dir") and nxt is None:
            self._chain_end = False
        if nxt:
            if nxt == "end":
                self._chain_end = False
            self._start_pick(nxt)
            return
        if self._prev_tool:
            self.canvas.setMapTool(self._prev_tool)

    def _set_point(self, key, lonlat, map_pt=None):
        self.points[key] = lonlat
        self._mark_dirty()
        self._refresh_coords()
        if self.markers[key]:
            self.canvas.scene().removeItem(self.markers[key])
            self.markers[key] = None
        if lonlat is None:
            return
        if map_pt is None:
            xf = QgsCoordinateTransform(WGS84, self.canvas.mapSettings().destinationCrs(),
                                        QgsProject.instance())
            map_pt = xf.transform(QgsPointXY(*lonlat))
        m = PinMarker(self.canvas, START_COLOR if key == "start" else END_COLOR)
        m.setCenter(map_pt)
        self.markers[key] = m
        if key == "start":
            self._arrow_faded = False
            self._update_circle()
        elif self.chk_search.isChecked():
            m.setVisible(False)

    def _set_found(self, lonlat, color="#d7191c"):
        """Point sur un élément atteint (mode recherche) ; None : tout retirer."""
        if lonlat is None:
            for m in self.found_markers:
                self.canvas.scene().removeItem(m)
            self.found_markers = []
            return
        xf = QgsCoordinateTransform(WGS84, self.canvas.mapSettings().destinationCrs(),
                                    QgsProject.instance())
        m = QgsVertexMarker(self.canvas)
        m.setCenter(xf.transform(QgsPointXY(*lonlat)))
        _style_point(m, color)
        self.found_markers.append(m)

    def _swap(self):
        s, e = self.points["start"], self.points["end"]
        self._set_point("start", e)
        self._set_point("end", s)

    def _clear(self, keep_trace=False):
        self._set_point("start", None)
        self._set_point("end", None)
        self._set_found(None)
        self._remove_circle()
        if not keep_trace:
            self._clear_trace()
        self._dir_point = None
        self._status("")
        self._set_result_html(None)
        self._update_clear_button()
        self._last = None

    def _clear_trace(self):
        """Supprime le trajet de la couche « Itinéraires OSM »."""
        lyr = self.layer
        try:
            if lyr is None or QgsProject.instance().mapLayer(lyr.id()) is None:
                return
            lyr.dataProvider().deleteFeatures([ft.id() for ft in lyr.getFeatures()])
            lyr.triggerRepaint()
        except RuntimeError:   # couche déjà détruite
            pass

    def _route_layer_in_project(self):
        try:
            return self.layer is not None and \
                QgsProject.instance().mapLayer(self.layer.id()) is not None
        except RuntimeError:
            return False

    def _ask_close(self):
        """Choix à la fermeture : 'save', 'delete' ou 'keep'."""
        box = QMessageBox(self)
        box.setWindowTitle("OSM Tracer")
        box.setIcon(QMessageBox.Icon.Question)
        box.setText("Que faire de la couche temporaire « %s » ?" % self.layer.name())
        box.setInformativeText(
            "Enregistrer : copie des traces dans un GeoPackage (dossier du projet par "
            "défaut), ajoutée au projet.\nSupprimer : la couche temporaire est retirée.\n"
            "Conserver : la couche temporaire reste dans le projet.")
        b_save = box.addButton("Enregistrer…", QMessageBox.ButtonRole.AcceptRole)
        b_del = box.addButton("Supprimer", QMessageBox.ButtonRole.DestructiveRole)
        box.addButton("Conserver", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(b_save)
        box.exec()
        clicked = box.clickedButton()
        return "save" if clicked is b_save else "delete" if clicked is b_del else "keep"

    def _has_traces(self):
        try:
            return self._route_layer_in_project() and self.layer.featureCount() > 0
        except RuntimeError:
            return False

    def _update_clear_button(self, *_):
        if hasattr(self, "btn_clear"):
            self.btn_clear.setEnabled(self._has_traces())

    def _ask_clear(self, before_run=False):
        """Choix pour les tracés existants : 'save', 'keep', 'delete' ou 'cancel'.
        before_run : posé avant un nouveau calcul (qui remplacerait les tracés)."""
        box = QMessageBox(self)
        box.setWindowTitle("OSM Tracer")
        box.setIcon(QMessageBox.Icon.Question)
        n = self.layer.featureCount()
        box.setText(("Un nouveau calcul va remplacer les %d tracé%s affiché%s. Qu'en faire ?"
                     if before_run else "Que faire des %d tracé%s affiché%s ?")
                    % (n, "s" * (n > 1), "s" * (n > 1)))
        box.setInformativeText(
            "Enregistrer : copie dans un GeoPackage (dossier du projet par défaut), "
            "ajoutée au projet.\nConserver : copie dans une couche temporaire séparée, "
            "que les prochains calculs ne remplaceront pas.\nSupprimer : les tracés sont effacés."
            + ("\nAnnuler : le calcul n'est pas lancé." if before_run else ""))
        b_save = box.addButton("Enregistrer…", QMessageBox.ButtonRole.AcceptRole)
        b_keep = box.addButton("Conserver", QMessageBox.ButtonRole.ActionRole)
        b_del = box.addButton("Supprimer", QMessageBox.ButtonRole.DestructiveRole)
        box.addButton("Annuler", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(b_save)
        box.exec()
        c = box.clickedButton()
        return ("save" if c is b_save else "keep" if c is b_keep
                else "delete" if c is b_del else "cancel")

    def _keep_routes(self):
        """Copie les tracés dans une couche mémoire séparée (non remplacée ensuite)."""
        import datetime
        copy = self.layer.materialize(QgsFeatureRequest())
        copy.setName("Itinéraires OSM – conservés %s"
                     % datetime.datetime.now().strftime("%H:%M:%S"))
        copy.setRenderer(self.layer.renderer().clone())
        self._set_copyright(copy)
        QgsProject.instance().addMapLayer(copy)
        return True

    def _on_clear_clicked(self, *_):
        """Effacer : s'il y a des tracés, proposer de les enregistrer / conserver."""
        if self._has_traces():
            choice = self._ask_clear()
            if choice == "cancel":
                return
            if choice == "save" and not self._save_routes():
                return                      # enregistrement annulé : on ne touche à rien
            if choice == "keep":
                self._keep_routes()
        self._clear()

    def _save_routes(self):
        """Enregistre les traces dans un GeoPackage (dossier du projet par défaut) et
        ajoute la couche enregistrée au projet. Retourne True si c'est fait."""
        import datetime
        prj = QgsProject.instance()
        folder = prj.homePath() or os.path.expanduser("~")
        path, _f = QFileDialog.getSaveFileName(
            self, "Enregistrer les itinéraires",
            os.path.join(folder, "itineraires_osm.gpkg"), "GeoPackage (*.gpkg)")
        if not path:
            return False
        if not path.lower().endswith(".gpkg"):
            path += ".gpkg"
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        lname = "itineraires_%s" % stamp
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = lname
        opts.fileEncoding = "UTF-8"
        if os.path.exists(path):
            opts.actionOnExistingFile = QgsVectorFileWriter.ActionOnExistingFile.CreateOrOverwriteLayer
        res = QgsVectorFileWriter.writeAsVectorFormatV3(self.layer, path,
                                                        prj.transformContext(), opts)
        if res[0] != QgsVectorFileWriter.WriterError.NoError:
            QMessageBox.warning(self, "OSM Tracer", "Enregistrement impossible :\n%s" % res[1])
            return False
        saved = QgsVectorLayer("%s|layername=%s" % (path, lname),
                               "Itinéraires OSM %s" % stamp.replace("_", " "), "ogr")
        if not saved.isValid():
            QMessageBox.warning(self, "OSM Tracer", "Couche enregistrée illisible : %s" % path)
            return False
        saved.setRenderer(self.layer.renderer().clone())
        self._set_copyright(saved)
        prj.addMapLayer(saved)
        self.iface.messageBar().pushMessage(
            "OSM Tracer", "Itinéraires enregistrés dans %s (couche %s)" % (path, lname),
            Qgis.MessageLevel.Success, 5)
        return True

    def close_and_clear(self, ask=True):
        """Fermeture du panneau : arrêt du calcul, points, cercle et résultat effacés.
        Choix pour la couche temporaire : enregistrer (GeoPackage, ajouté au projet)
        puis la retirer, la supprimer, ou la conserver."""
        self.stop()
        remove = False
        if ask and self._route_layer_in_project():
            choice = self._ask_close()
            if choice == "save":
                remove = self._save_routes()   # annulé : on garde la couche temporaire
            else:
                remove = choice == "delete"
        self._clear(keep_trace=ask and not remove)
        self._reset_request()
        if remove:
            lid, self.layer = self.layer.id(), None
            QgsProject.instance().removeMapLayer(lid)
        self._update_clear_button()

    def _reset_request(self):
        """Requête vidée : sélection en cours abandonnée, direction remise à zéro,
        retour au premier onglet."""
        self._picking = None
        self._chain_end = False
        if self.canvas.mapTool() is self.tool:
            try:
                if self._prev_tool is not None:
                    self.canvas.setMapTool(self._prev_tool)
                else:
                    self.canvas.unsetMapTool(self.tool)
            except RuntimeError:          # outil précédent détruit
                self.canvas.unsetMapTool(self.tool)
        self._prev_tool = None
        self.chk_dir.setChecked(False)
        self.spin_dir.setValue(0)
        self._dir_point = None
        self._remove_circle()
        self.tabs.setCurrentIndex(0)
        self._dirty = True
        self._update_run_button()

    def closeEvent(self, e):
        self._opt_dlg.close()
        self.close_and_clear()
        super().closeEvent(e)

    # --------------------------------------------------------- Calcul
    def _collect_targets(self):
        """Éléments des couches cochées dans le rayon autour du départ.
        Retourne (couches, [(dist_m, (lon, lat), couche, fid)]) triés par distance."""
        layers = [l for l in self._search_layers() if l.isValid()]
        if not layers:
            raise ValueError("Cochez au moins une couche de recherche.")
        radius = self.spin_radius.value()
        start = self.points["start"]
        loc = _local_crs(start)
        prj = QgsProject.instance()
        to_wgs = QgsCoordinateTransform(loc, WGS84, prj)
        expr = self.le_filter.expression().strip()
        e = QgsExpression(expr) if expr else None
        if e is not None and e.hasParserError():
            raise ValueError("Filtre invalide : %s" % e.parserErrorString())
        origin = QgsGeometry.fromPointXY(QgsPointXY(0, 0))
        cands = []
        for lyr in layers:
            to_lyr = QgsCoordinateTransform(loc, lyr.crs(), prj)
            to_loc = QgsCoordinateTransform(lyr.crs(), loc, prj)
            req = QgsFeatureRequest()
            req.setFilterRect(to_lyr.transformBoundingBox(
                QgsRectangle(-radius, -radius, radius, radius)))
            names = set(lyr.fields().names())
            if e is not None and set(e.referencedColumns()) <= names | {QgsFeatureRequest.ALL_ATTRIBUTES}:
                req.setFilterExpression(expr)
                req.setExpressionContext(QgsExpressionContext(
                    QgsExpressionContextUtils.globalProjectLayerScopes(lyr)))
            feats = lyr.getSelectedFeatures(req) if self.chk_selected.isChecked() \
                else lyr.getFeatures(req)
            for f in feats:
                g = QgsGeometry(f.geometry())
                if g.isNull() or g.isEmpty():
                    continue
                g.transform(to_loc)
                np = g.nearestPoint(origin)
                if np.isNull():
                    continue
                p = np.asPoint()
                d = (p.x() ** 2 + p.y() ** 2) ** 0.5
                if d <= radius:
                    w = to_wgs.transform(p)
                    cands.append((d, (w.x(), w.y()), lyr, f.id()))
        cands.sort(key=lambda c: c[0])
        if len(cands) > MAX_TARGETS:
            QgsMessageLog.logMessage(
                "%d éléments dans le rayon : seuls les %d plus proches sont évalués."
                % (len(cands), MAX_TARGETS), "OSM Tracer", Qgis.MessageLevel.Info)
        return layers, cands

    def run(self):
        search = self.chk_search.isChecked()
        if not self.points["start"] or (not search and not self.points["end"]):
            self._status("⚠ Sélectionnez un départ%s."
                                    % ("" if search else " et une arrivée"))
            return
        s = self.settings()
        if not s["enabled"]:
            self._status("⚠ Cochez au moins un type de voie.")
            return
        targets = None
        self._job = dict(search=search)
        if search:
            try:
                layers, cands = self._collect_targets()
            except ValueError as e:
                self._status("⚠ %s" % e)
                return
            qs = QgsSettings()
            qs.setValue("osm_tracer/search_radius", self.spin_radius.value())
            qs.setValue("osm_tracer/search_filter", self.le_filter.expression())
            qs.setValue("osm_tracer/search_selected", self.chk_selected.isChecked())
            qs.setValue("osm_tracer/search_routes", self.spin_routes.value())
            if not cands:
                self._set_found(None)
                self._status(
                    "⚠ Aucun élément des couches cochées dans un rayon de %d m "
                    "autour du départ." % self.spin_radius.value())
                return
            self._job.update(layers=layers, n=len(cands), cands=cands[:MAX_TARGETS])
            targets = [c[1] for c in self._job["cands"]]
        qs = QgsSettings()
        qs.setValue("osm_tracer/overpass", self.cb_server.currentText())
        qs.setValue("osm_tracer/color", self.btn_color.color().name())
        qs.setValue("osm_tracer/width", self.spin_width.value())
        # Tracés existants : proposer de les enregistrer / conserver avant de les remplacer
        if self._has_traces():
            choice = self._ask_clear(before_run=True)
            if choice == "cancel":
                return
            if choice == "save" and not self._save_routes():
                return
            if choice == "keep":
                self._keep_routes()
        # Les anciens tracés (copiés si Enregistrer / Conserver) sont effacés avant le calcul
        self._clear_trace()
        self._set_found(None)
        self._last = None
        self._set_result_html(None)
        self._update_clear_button()
        self._set_running(True)
        self._arrow_faded = False
        self._status(
            "⏳ %sTéléchargement OSM et calcul…"
            % ("%d élément(s) dans le rayon. " % self._job["n"] if search else ""))
        self.task = RouteTask(self.points["start"], self.points["end"], s,
                              self.cb_server.currentText().strip() or DEFAULT_OVERPASS,
                              self._on_done, targets=targets,
                              max_routes=self.spin_routes.value())
        QgsApplication.taskManager().addTask(self.task)

    def _on_done(self, res, error):
        self._set_running(False)
        self.task = None
        if res is None:
            if error is None or "arrêté" in error:
                self._status("⏹ Calcul arrêté.")
            else:
                self._status("❌ " + error)
            return
        labels = {r[0]: r[1] for r in osm_router.ROAD_TYPES}
        self._set_found(None)
        self._clear_trace()     # un nouveau calcul remplace le précédent
        self._last = []
        self._sel = None
        self._assign_widths(res["routes"])
        for r in res["routes"]:
            detail = ", ".join("%s %.1f km" % (labels[k], v / 1000)
                               for k, v in sorted(r["per_type_m"].items(),
                                                  key=lambda kv: -kv[1]))
            target = self._target_info(r)
            self._add_feature(r, detail, target)
            if target:
                self._set_found(target["lonlat"], r["color"])
            self._last.append((r, detail, target))
        n = len(self._last)
        self._status("✓ %d tracé%s calculé%s – voir l'onglet Résultat"
                     % (n, "s" if n > 1 else "", "s" if n > 1 else ""))
        self._show_result()
        self.tabs.setCurrentIndex(1)
        self._update_clear_button()
        self._dirty = False
        self._update_run_button()
        self._arrow_faded = True
        self._update_circle()
        self._update_result_map()

    def _assign_widths(self, routes):
        """Tous les tracés gardent un trait fin. Ceux qui empruntent les mêmes
        tronçons sont décalés côte à côte (lignes parallèles) pour rester visibles."""
        base = self.spin_width.value()
        gap = base + 0.15                       # écart entre lignes parallèles (mm)
        segs = []
        for r in routes:
            c = [(round(x, 6), round(y, 6)) for x, y in r["coords"]]
            segs.append({frozenset(p) for p in zip(c, c[1:]) if p[0] != p[1]})
        shared = [i for i in range(len(routes))
                  if any(segs[i] & segs[j] for j in range(len(routes)) if j != i)]
        for r in routes:
            r["width"], r["offset"] = base, 0.0
        n = len(shared)
        for k, i in enumerate(shared):
            routes[i]["offset"] = round((k - (n - 1) / 2.0) * gap, 2)

    def _target_info(self, res):
        """Infos sur l'élément atteint (mode recherche), sinon None."""
        job = self._job or {}
        if not job.get("search") or "target_index" not in res:
            return None
        d, lonlat, lyr, fid = job["cands"][res["target_index"]]
        info = dict(layer_name="?", fid=fid, dist=d, lonlat=lonlat, n=job["n"],
                    label="", feature=None, address=res.get("address"))
        try:
            info["layer_name"] = lyr.name()
            feat = lyr.getFeature(fid)
            if feat.isValid():
                info["feature"] = feat
                ctx = QgsExpressionContext(
                    QgsExpressionContextUtils.globalProjectLayerScopes(lyr))
                ctx.setFeature(feat)
                val = QgsExpression(lyr.displayExpression()).evaluate(ctx)
                info["label"] = "" if val is None else str(val)
        except RuntimeError:   # couche supprimée entre-temps
            pass
        return info

    @staticmethod
    def _linkify(block, idx):
        """Rend chaque ligne du bloc cliquable (lien route:idx) en gardant sa couleur."""
        def wrap(m):
            col = re.search(r"color:\s*(#[0-9a-fA-F]{6})", m.group(1))
            return ("%s<a href='route:%d'><span style='color:%s'>%s</span></a>%s"
                    % (m.group(1), idx, col.group(1) if col else "#202020",
                       m.group(2), m.group(3)))
        return re.sub(r"(<div[^>]*>)((?:(?!<div|</div>).)*)(</div>)", wrap, block)

    def _on_result_clicked(self, url):
        """Clic sur un tracé de la liste : sélection + clignotement sur les deux cartes."""
        s = url.toString()
        if s.startswith("route:"):
            self._select_route(int(s.split(":")[1]))

    def _on_result_map_clicked(self, pt):
        """Clic sur la carte du résultat : sélection du tracé visé ; si plusieurs
        tracés se superposent à cet endroit, un menu permet de choisir."""
        hits = self._hit_routes(pt)
        if len(hits) == 1:
            self._select_route(hits[0])
        elif hits:
            menu = QMenu(self)
            for i in hits:
                r, _d, t = self._last[i]
                pix = QPixmap(14, 14)
                pix.fill(QColor(r.get("color", "#888888")))
                name = (t["label"] or "#%s" % t["fid"]) if t else "Arrivée"
                act = menu.addAction(QIcon(pix), "%d.  %.2f km  –  %s" % (
                    i + 1, r["length_m"] / 1000, name))
                act.triggered.connect(lambda _=False, k=i: self._select_route(k))
            menu.exec(QCursor.pos())

    def _hit_route(self, pt):
        hits = self._hit_routes(pt)
        return hits[0] if hits else None

    def _hit_routes(self, pt):
        """Indices des tracés (ou points d'arrivée) à moins de 10 px de pt,
        du plus proche au plus éloigné."""
        if not self._last:
            return []
        xf = QgsCoordinateTransform(WGS84, self.res_canvas.mapSettings().destinationCrs(),
                                    QgsProject.instance())
        click = QgsGeometry.fromPointXY(pt)
        tol = self.res_canvas.mapUnitsPerPixel() * 10
        found = []
        for i, (r, _d, t) in enumerate(self._last):
            geoms = [QgsGeometry.fromPolylineXY([QgsPointXY(x, y) for x, y in r["coords"]])]
            if t:
                geoms.append(QgsGeometry.fromPointXY(QgsPointXY(*t["lonlat"])))
            best = None
            for g in geoms:
                g.transform(xf)
                dist = g.distance(click)
                if dist <= tol and (best is None or dist < best):
                    best = dist
            if best is not None:
                found.append((best, i))
        return [i for _d, i in sorted(found)]

    def _select_route(self, i):
        """Met le tracé i en évidence dans la liste et le fait clignoter sur les cartes."""
        if not self._last or not 0 <= i < len(self._last):
            return
        self._sel = i
        self._show_result()
        self.txt_result.scrollToAnchor("r%d" % i)
        r, _d, t = self._last[i]
        for cv in (self.canvas, self.res_canvas):
            self._blink(cv, r["coords"], t["lonlat"] if t else None,
                        r.get("color", "#ff0000"))

    def _blink(self, canvas, coords, point, color, times=4, period=350):
        """Clignotement fin (trait de 2 px + point) d'un tracé sur une carte."""
        col = QColor(color)
        line = QgsRubberBand(canvas, _line_type())
        line.setToGeometry(QgsGeometry.fromPolylineXY(
            [QgsPointXY(x, y) for x, y in coords]), WGS84)
        line.setStrokeColor(col)
        line.setWidth(1)
        items = [line]
        if point is not None:
            m = QgsVertexMarker(canvas)
            xf = QgsCoordinateTransform(WGS84, canvas.mapSettings().destinationCrs(),
                                        QgsProject.instance())
            m.setCenter(xf.transform(QgsPointXY(*point)))
            m.setIconType(QgsVertexMarker.IconType.ICON_CIRCLE)
            m.setIconSize(16)
            m.setPenWidth(2)
            m.setColor(col)
            items.append(m)
        state = {"n": 0}
        timer = QTimer(self)

        def tick():
            state["n"] += 1
            if state["n"] >= times * 2:
                timer.stop()
                for it in items:
                    canvas.scene().removeItem(it)
                timer.deleteLater()
                return
            for it in items:
                it.setVisible(state["n"] % 2 == 0)

        timer.timeout.connect(tick)
        timer.start(period // 2 if period > 1 else 1)

    def _route_html(self, res, target, rank):
        grey, soft = "#8a8a8a", "#5a5a5a"
        total = res["length_m"] + res["snap_start_m"] + res["snap_end_m"]
        head = ("<span style='font-size:12pt; color:%s'>━━</span>&nbsp;&nbsp;"
                "<span style='font-size:12pt; font-weight:300'>%.2f km</span>"
                % (res.get("color", "#888888"), res["length_m"] / 1000))
        if self.chk_time.isChecked():
            head += ("<span style='color:%s'>&nbsp;&nbsp;%d min</span>"
                     % (grey, round(res["time_s"] / 60)))
        head += ("<span style='color:%s'>&nbsp;&nbsp;·&nbsp;&nbsp;total "
                 "<span style='color:%s'>%.2f km</span> avec accroches</span>"
                 % (grey, soft, total / 1000))
        if rank is not None:
            head = "<span style='color:%s'>%d.</span>&nbsp;&nbsp;" % (grey, rank) + head
        labels = {r[0]: r[1] for r in osm_router.ROAD_TYPES}
        types = " · ".join("%s <span style='color:%s'>%.2f km</span>" % (labels[k], grey, v / 1000)
                           for k, v in sorted(res["per_type_m"].items(),
                                              key=lambda kv: -kv[1]))
        found = ""
        if target:
            name = target["label"] or "#%s" % target["fid"]
            adr = target["address"]
            adr_txt = ("<div style='color:%s'>%s&nbsp;&nbsp;<span style='color:%s'>"
                       "à %d m</span></div>"
                       % (soft, html.escape(adr["address"]), grey, adr["dist_m"]) if adr
                       else "<div style='color:%s'>Adresse indisponible</div>" % grey)
            found = ("<div style='margin-top:3px'>%s&nbsp;&nbsp;<span style='color:%s'>"
                     "%s</span></div>%s"
                     % (html.escape(name), grey, html.escape(target["layer_name"]), adr_txt))
        return ("<div style='margin-bottom:12px'><div>%s</div>%s"
                "<div style='font-size:9pt; margin-top:3px'>%s</div>"
                "<div style='color:%s; font-size:8.5pt'>Accroche à la voie : "
                "départ %d m%s · %s %d m</div></div>"
                % (head, found, types, grey, res["snap_start_m"],
                   (" (%s)" % html.escape(res["snap_start_name"]))
                   if res.get("snap_start_name") else "",
                   "cible" if target else "arrivée", res["snap_end_m"]))

    def _show_result(self):
        if not getattr(self, "_last", None):
            return
        parts = []
        target0 = self._last[0][2]
        multi = len(self._last) > 1
        if target0:
            n = len(self._last)
            parts.append("<div style='color:#8a8a8a; font-size:9pt; margin-bottom:8px'>"
                         "%d élément(s) dans le rayon · %d tracé%s</div>"
                         % (target0["n"], n, "s" if n > 1 else ""))
        for i, (r, _detail, target) in enumerate(self._last):
            if i:
                parts.append("<hr style='border:0; height:1px; background:#dddddd'>")
            block = self._linkify(self._route_html(r, target, i + 1 if multi else None), i)
            if i == getattr(self, "_sel", None):   # tracé sélectionné : fond teinté
                tint = QColor(r.get("color", "#888888"))
                tint.setAlpha(28)
                a = tint.alphaF()
                mix = QColor(int(tint.red() * a + 255 * (1 - a)), int(tint.green() * a + 255 * (1 - a)),
                             int(tint.blue() * a + 255 * (1 - a)))
                block = block.replace("<div>", "<div style=''>").replace(
                    "<div style='", "<div style='background-color:%s; " % mix.name())
            parts.append("<a name='r%d'></a>" % i + block)
        self._set_result_html("".join(parts))

    def _status(self, text):
        """Ligne d'état sous les onglets (masquée si vide)."""
        self.lbl_result.setText(text)
        self.lbl_result.setVisible(bool(text))

    def _set_result_html(self, body):
        """Onglet Résultat visible uniquement s'il y a un résultat."""
        self.txt_result.setHtml(body or "")
        self.tabs.setTabVisible(1, bool(body))
        if not body:
            self._clear_result_map()

    def _clear_result_map(self):
        for m in self._res_markers:
            self.res_canvas.scene().removeItem(m)
        self._res_markers = []
        self.res_canvas.setLayers([])

    def _res_marker(self, lonlat, icon, color, size=12):
        xf = QgsCoordinateTransform(WGS84, self.res_canvas.mapSettings().destinationCrs(),
                                    QgsProject.instance())
        m = QgsVertexMarker(self.res_canvas)
        m.setCenter(xf.transform(QgsPointXY(*lonlat)))
        m.setIconType(icon)
        m.setIconSize(size)
        m.setPenWidth(3)
        m.setColor(QColor(color))
        self._res_markers.append(m)

    def _res_pin(self, lonlat, color):
        xf = QgsCoordinateTransform(WGS84, self.res_canvas.mapSettings().destinationCrs(),
                                    QgsProject.instance())
        m = PinMarker(self.res_canvas, color, 22)
        m.setCenter(xf.transform(QgsPointXY(*lonlat)))
        self._res_markers.append(m)

    def _res_point(self, lonlat, color):
        xf = QgsCoordinateTransform(WGS84, self.res_canvas.mapSettings().destinationCrs(),
                                    QgsProject.instance())
        m = QgsVertexMarker(self.res_canvas)
        m.setCenter(xf.transform(QgsPointXY(*lonlat)))
        _style_point(m, color)
        self._res_markers.append(m)

    def _update_result_map(self):
        """Carte du résultat : tracés sur fond OSM, cadrée sur 2× l'emprise des tracés."""
        self._clear_result_map()
        if not self._last:
            return
        crs = QgsCoordinateReferenceSystem("EPSG:3857")
        self.res_canvas.setDestinationCrs(crs)
        self.res_canvas.setCanvasColor(QColor("#f2efe9"))
        if self.osm_bg is None or not self.osm_bg.isValid():
            self.osm_bg = QgsRasterLayer(OSM_XYZ, "OpenStreetMap", "wms")
        route = self.layer if self._route_layer_in_project() else None
        layers = [l for l in (route, self.osm_bg) if l is not None and l.isValid()]
        self.res_canvas.setLayers(layers)
        xf = QgsCoordinateTransform(WGS84, crs, QgsProject.instance())
        box = None
        for r, _d, _t in self._last:
            g = QgsGeometry.fromPolylineXY([QgsPointXY(x, y) for x, y in r["coords"]])
            g.transform(xf)
            bb = g.boundingBox()
            if box is None:
                box = bb
            else:
                box.combineExtentWith(bb)
        if self.points["start"]:
            self._res_pin(self.points["start"], START_COLOR)
        for r, _d, t in self._last:
            if t:
                self._res_point(t["lonlat"], r.get("color", "#d7191c"))
            elif r["coords"]:
                self._res_pin(r["coords"][-1], END_COLOR)
        self._res_box = box
        QTimer.singleShot(0, self._frame_result_map)
        QTimer.singleShot(0, self._half_split)

    def _half_split(self):
        """Carte du résultat = moitié de la hauteur de l'onglet."""
        h = self.res_split.height()
        if h > 0:
            self.res_split.setSizes([h // 2, h - h // 2])

    def _frame_result_map(self):
        box = getattr(self, "_res_box", None)
        if box is None:
            return
        # Cadrage = 2 × l'emprise des tracés (au moins 300 m de côté)
        ext = QgsRectangle(box)
        ext.scale(2.0)
        c = ext.center()
        ext = QgsRectangle(c.x() - max(ext.width() / 2, 150), c.y() - max(ext.height() / 2, 150),
                           c.x() + max(ext.width() / 2, 150), c.y() + max(ext.height() / 2, 150))
        self.res_canvas.setExtent(ext)
        self.res_canvas.refresh()
        self.res_overlay.update()

    def _set_running(self, running):
        self.btn_run.setEnabled(not running)
        self.btn_stop.setEnabled(running)
        self._update_run_button()

    def stop(self):
        self._remove_circle()
        if self.task is not None:
            self._status("⏳ Arrêt en cours…")
            self.task.cancel()

    def _route_layer(self):
        if not self._route_layer_in_project():
            self.layer = QgsVectorLayer(
                "LineString?crs=EPSG:4326&field=profil:string(50)"
                "&field=poids_dist:double&field=distance_km:double"
                "&field=duree_min:double&field=detail:string(254)"
                "&field=depart:string(60)&field=arrivee:string(60)"
                "&field=couleur:string(9)&field=epaisseur:double&field=version:string(10)"
                "&field=source:string(80)&field=cible_couche:string(100)"
                "&field=cible_fid:string(20)&field=cible_vol_m:double"
                "&field=cible_adresse:string(254)&field=distance_tot_km:double"
                "&field=decalage:double",
                "Itinéraires OSM", "memory")
            # Couleur / épaisseur pilotées par les champs : chaque trace garde son style
            sl = self.layer.renderer().symbol().symbolLayer(0)
            prop = getattr(QgsSymbolLayer, "Property", QgsSymbolLayer)
            color_p = getattr(prop, "StrokeColor", None)
            if color_p is None:
                color_p = QgsSymbolLayer.PropertyStrokeColor
            width_p = getattr(prop, "StrokeWidth", None)
            if width_p is None:
                width_p = QgsSymbolLayer.PropertyStrokeWidth
            sl.setDataDefinedProperty(color_p, QgsProperty.fromField("couleur"))
            sl.setDataDefinedProperty(width_p, QgsProperty.fromField("epaisseur"))
            # Tracés superposés : décalage latéral (mm) piloté par le champ « decalage »
            off_p = getattr(prop, "Offset", None)
            if off_p is None:
                off_p = QgsSymbolLayer.PropertyOffset
            sl.setDataDefinedProperty(off_p, QgsProperty.fromExpression('coalesce("decalage", 0)'))
            self._set_copyright(self.layer)
            QgsProject.instance().addMapLayer(self.layer)
            self._refresh_layer_list()
        return self.layer

    def _next_color(self, lyr):
        """Couleur de la nouvelle trace : celle du bouton pour la première, puis
        la première couleur de la palette pas encore utilisée dans la couche."""
        used = {str(f["couleur"]).lower() for f in lyr.getFeatures()}
        palette = [self.btn_color.color().name()] + [
            c for c in TRACE_PALETTE if c != self.btn_color.color().name()]
        for c in palette:
            if c.lower() not in used:
                return c
        return palette[len(used) % len(palette)]

    def _add_feature(self, res, detail, target=None):
        lyr = self._route_layer()
        # Chaque tracé d'un même calcul a sa couleur (un nouveau calcul remplace tout)
        dp = lyr.dataProvider()
        color = self._next_color(lyr)
        res["color"] = color
        copied = []
        if target and target["feature"] is not None:
            # Attributs de l'élément atteint, préfixés « cible_ »
            new = []
            for fld in target["feature"].fields():
                name = "cible_" + fld.name()
                copied.append((name, fld.name()))
                if lyr.fields().indexOf(name) < 0:
                    nf = type(fld)(fld)
                    nf.setName(name)
                    new.append(nf)
            if new:
                dp.addAttributes(new)
                lyr.updateFields()
        f = QgsFeature(lyr.fields())
        f.setGeometry(QgsGeometry.fromPolylineXY([QgsPointXY(x, y) for x, y in res["coords"]]))
        f.setAttributes([self.cb_profile.currentText(), self._weight(),
                         round(res["length_m"] / 1000, 3), round(res["time_s"] / 60, 1),
                         detail[:254], self._coord_attr("start"), self._coord_attr("end"),
                         color, res.get("width", self.spin_width.value()), __version__,
                         "%s, %s" % (OSM_ATTRIBUTION, OSM_LICENSE)]
                        + [None] * (lyr.fields().count() - 11))
        f.setAttribute("distance_tot_km", round(
            (res["length_m"] + res["snap_start_m"] + res["snap_end_m"]) / 1000, 3))
        if target:
            f.setAttribute("arrivee", "%s (%s)" % (self._fmt(target["lonlat"]),
                                                   self.cb_crs.currentData()))
            f.setAttribute("cible_couche", target["layer_name"][:100])
            f.setAttribute("cible_fid", str(target["fid"]))
            f.setAttribute("cible_vol_m", round(target["dist"], 1))
            if target["address"]:
                f.setAttribute("cible_adresse", target["address"]["address"][:254])
            for dst, src in copied:
                f.setAttribute(dst, target["feature"][src])
        if lyr.fields().indexOf("decalage") >= 0:
            f.setAttribute("decalage", res.get("offset", 0.0))
        lyr.dataProvider().addFeatures([f])
        lyr.updateExtents()
        lyr.triggerRepaint()

    def show_options(self):
        """Ouvre la fenêtre Options sous l'engrenage (non modale)."""
        dlg = self._opt_dlg
        dlg.adjustSize()
        pos = self.btn_options.mapToGlobal(self.btn_options.rect().bottomRight())
        dlg.move(pos.x() - dlg.frameGeometry().width(), pos.y())
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

    def show_help(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("OSM Tracer – Aide")
        dlg.resize(560, 620)
        v = QVBoxLayout(dlg)
        tb = QTextBrowser()
        tb.setOpenExternalLinks(True)
        tb.setHtml(HELP_HTML.replace("{version}", __version__))
        v.addWidget(tb)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        dlg.exec()

    def cleanup(self):
        self._opt_dlg.close()
        # Déchargement (fermeture de QGIS, rechargement) : pas de question
        self.close_and_clear(ask=False)
        self._set_found(None)
        for k in ("start", "end"):
            if self.markers[k]:
                self.canvas.scene().removeItem(self.markers[k])
        self._remove_circle()
        try:
            self.canvas.destinationCrsChanged.disconnect(self._update_circle)
            self.canvas.scaleChanged.disconnect(self._update_circle)
            QgsProject.instance().layersAdded.disconnect(self._refresh_layer_list)
            QgsProject.instance().layersRemoved.disconnect(self._refresh_layer_list)
            self.iface.actionDraw().triggered.disconnect(self._remove_circle)
        except (TypeError, RuntimeError):
            pass
        if self.canvas.mapTool() is self.tool:
            self.canvas.unsetMapTool(self.tool)
