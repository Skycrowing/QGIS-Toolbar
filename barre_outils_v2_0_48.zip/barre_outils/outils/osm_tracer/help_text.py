# -*- coding: utf-8 -*-
# OSM Tracer – plugin QGIS
# Copyright (C) 2026 skycrow2 <skycrow2@gmail.com>
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version. See the LICENSE file.
#
# SPDX-License-Identifier: GPL-2.0-or-later
# Données routières : © contributeurs OpenStreetMap, licence ODbL 1.0
HELP_HTML = """
<h2>OSM Tracer – Aide <small>(v{version})</small></h2>
<p>Calcule un itinéraire entre deux points de la carte à partir du réseau
<b>OpenStreetMap</b> (téléchargé via l'API Overpass).</p>

<h3>1. Choisir les points</h3>
<ul>
<li>Cliquez sur <b>Départ</b> puis sur la carte : en mode deux points, le <b>clic suivant</b> place
directement l'arrivée (après la direction si l'option Direction de la voie est cochée).</li>
<li>Vous pouvez cliquer <b>à côté d'une route</b> : le point est accroché
automatiquement sur la voie autorisée la plus proche (distance affichée dans le résultat).</li>
<li><b>⇅</b> échange départ et arrivée.</li>
<li><b>Direction de la voie</b> (option) : au lieu de la voie la plus proche, le départ
s'accroche à la <b>voie visée</b> : si le clic de direction tombe sur une voie (à moins de 60 m),
c'est cette voie qui est prise ; sinon la <b>première voie rencontrée dans cette direction</b>, en ignorant celle sur laquelle se trouve le départ (moins de 15 m) (azimut en degrés, 0° = nord,
sens horaire ; à défaut, la plus proche dans un cône de ±45°). Case cochée : après le clic du
départ, le <b>clic suivant</b> sur la carte donne la direction (ou saisissez l'angle / bouton <b>Pointer</b>). Une flèche verte l'indique sur la carte.</li>
<li><b>Coord.</b> : affichage des coordonnées en WGS84, Lambert 72 ou Lambert 2008
(survol du champ = valeur WGS84). Les champs <i>depart</i>/<i>arrivee</i> de la trace
sont enregistrés dans ce système.</li>
</ul>

<h3>1 bis. Destination = élément d'une couche</h3>
<ul>
<li>Cochez <b>Recherche d'élément(s) dans un rayon</b> : le point d'arrivée disparaît et le groupe
<b>Recherche de la destination</b> apparaît en bas du panneau.</li>
<li><b>Couches</b> : cochez une ou plusieurs couches de points, lignes ou polygones où chercher.
<b>Rayon</b> : distance à vol d'oiseau autour du <b>Départ</b> (cercle bleu sur la carte).
<b>Filtre</b> (optionnel) : expression QGIS, ex. <i>"type" = 'hôpital'</i>.
Option : uniquement les entités sélectionnées.</li>
<li>Un tracé est calculé vers chaque élément du rayon, du plus proche au plus éloigné
<b>par la route</b> (profil, types de voies et préférences du panneau), dans la limite de
<b>Tracés max</b>. Chaque tracé a sa couleur ; l'élément atteint est marqué d'un point de la même couleur.
Pour une ligne ou un polygone, on vise son point le plus proche du départ.</li>
<li>L'onglet <b>Résultat</b> n'apparaît qu'après un calcul : détail de chaque tracé puis, en dessous,
une carte sur fond <b>OpenStreetMap</b> cadrée sur <b>2 fois l'emprise</b> des tracés (molette = zoom,
glisser = déplacer), avec échelle et flèche du nord, sur la moitié de l'onglet.
<b>Cliquer sur un tracé</b> de la liste, ou sur un tracé / point de la carte du résultat, le
sélectionne dans la liste (fond teinté) et le fait clignoter sur les deux cartes. Sur la carte
du résultat, le curseur devient une main ☝ au survol d'un tracé cliquable.
La ligne « Accroche à la voie » indique le nom de la voie utilisée au départ. Chaque trace reçoit les champs
<i>cible_couche</i>, <i>cible_fid</i>, <i>cible_vol_m</i> et les attributs de l'élément (préfixe <i>cible_</i>).</li>
<li><b>📫 Adresse</b> : l'adresse la plus proche de l'élément trouvé est recherchée
(géocodage inverse Nominatim, données OSM) et affichée dans le résultat avec sa distance
à l'élément (champ <i>cible_adresse</i>). Une seule requête par calcul.</li>
<li>Au-delà de 300 éléments dans le rayon, seuls les 300 plus proches sont évalués.</li>
</ul>

<h3>2. Profil et pondération</h3>
<ul>
<li><b>Profil</b> : préréglage (rapide, court, équilibré, sans autoroute,
vélo/RAVeL, piéton). Il fixe le compromis temps / distance et remplit les réglages ci-dessous, que vous pouvez ensuite modifier.</li>
<li><b>Sens uniques</b> : à décocher pour le vélo / piéton.</li>
<li><b>Véhicule motorisé</b> : tient compte des limitations (<i>maxspeed</i>)
et des interdictions d'accès aux véhicules.</li>
</ul>

<p>Profil par défaut : <b>Le plus court</b>, sens uniques et véhicule motorisé décochés, autoroute exclue, RAVeL inclus.</p>

<h3>3. Types de voies <small>(groupe repliable)</small></h3>
<ul>
<li>Cochez les voies utilisables (autoroute, nationale, RAVeL, pistes cyclables…).</li>
<li>La liste se <b>redimensionne</b> en glissant la poignée sous le tableau (double-clic : taille d'origine). La taille est mémorisée.</li>
<li><b>km/h</b> : vitesse utilisée pour le calcul du temps. Colonne masquée par défaut, à afficher via <i>Options › Afficher la colonne km/h</i> (les vitesses restent utilisées même masquées).</li>
<li><b>Préférence</b> : multiplicateur de coût. <b>&lt; 1</b> favorise la voie
(ex. 0,5 = deux fois plus attractive), <b>&gt; 1</b> la pénalise. Colonne masquée par défaut, à afficher via <i>Options › Afficher la colonne Préférence</i> (les préférences du profil restent appliquées même masquées).</li>
<li><b>RAVeL</b> : tronçons appartenant à une relation vélo ou portant un nom
contenant « RAVeL ». Ils sont prioritaires sur leur type de voie d'origine.</li>
</ul>

<h3>4. Lancer / arrêter</h3>
<ul>
<li><b>▶ Calculer</b> lance le téléchargement OSM puis le calcul (en arrière-plan, QGIS reste utilisable).</li>
<li><b>■ Arrêter</b> interrompt immédiatement le traitement en cours
(également possible depuis la barre de tâches QGIS en bas à droite).</li>
</ul>

<h3>5. Style et résultat</h3>
<ul>
<li>Dans <b>Options</b> (icône engrenage en haut à droite) : choisissez la <b>couleur</b> et l'<b>épaisseur</b> avant de calculer :
chaque trace conserve son propre style (champs <i>couleur</i> et <i>epaisseur</i>).</li>
<li><b>Afficher la durée</b> (Options, désactivé par défaut) : ajoute les minutes estimées
au résultat. La durée reste toujours enregistrée dans le champ <i>duree_min</i>.</li>
<li>Les traces sont ajoutées à la couche mémoire <b>« Itinéraires OSM »</b> avec
distance, durée, profil et détail des km par type de voie.
Chaque nouveau calcul <b>remplace</b> les traces précédentes. Les tracés d'un même calcul ont chacun une <b>couleur différente</b> (le premier prend la couleur choisie dans Options ; le trait coloré du résultat l'indique).
Quand plusieurs tracés empruntent les mêmes rues, ils sont <b>décalés côte à côte</b> (lignes
parallèles fines) pour que tous restent visibles. le bouton <b>⟳ Effacer</b> (icône de rafraîchissement, grisé tant qu'aucun tracé n'a été calculé) propose d'abord : <b>Enregistrer…</b> (GeoPackage dans le dossier du projet),
<b>Conserver</b> (copie dans une couche temporaire séparée, que les calculs suivants ne remplacent pas),
<b>Supprimer</b> ou <b>Annuler</b>. La même question est posée au lancement d'un nouveau calcul
s'il reste des tracés (Annuler : le calcul n'est pas lancé). À la <b>fermeture du panneau</b>, trois choix pour la couche
temporaire « Itinéraires OSM » : <b>Enregistrer…</b> (GeoPackage, dans le dossier du projet par défaut ;
la couche enregistrée est ajoutée au projet avec le même style), <b>Supprimer</b> ou <b>Conserver</b>. Pour les conserver : clic droit › Rendre permanente (ou exporter) avant de recalculer.</li>
</ul>

<h3>Limites et conseils</h3>
<ul>
<li>Distance maximale ≈ 100 km entre les points (charge du serveur Overpass).</li>
<li>La dernière zone téléchargée est gardée en mémoire : modifier les poids
ou vitesses ne retélécharge rien.</li>
<li>« Aucun itinéraire trouvé » : le réseau sélectionné n'est pas connecté,
cochez davantage de types de voies.</li>
<li><b>Serveur Overpass</b> : en mode <i>Auto</i>, si un serveur répond
« Gateway Timeout » / « Too Many Requests », l'outil réessaie puis bascule sur le
suivant. Détail des tentatives : panneau Journal des messages › onglet « OSM Tracer ».</li>
</ul>
<h3>Droits d'auteur et licences</h3>
<ul>
<li><b>Données</b> : © contributeurs OpenStreetMap, disponibles sous licence
<a href="https://opendatacommons.org/licenses/odbl/1-0/">ODbL 1.0</a> –
<a href="https://www.openstreetmap.org/copyright">openstreetmap.org/copyright</a>.</li>
<li>Toute carte ou document utilisant une trace doit mentionner
<b>« © contributeurs OpenStreetMap »</b>. L'attribution est déjà renseignée dans
les métadonnées de la couche (onglet Métadonnées) et dans le champ <i>source</i>.</li>
<li>Une trace partagée publiquement est une base de données dérivée : elle doit rester
sous ODbL (partage à l'identique).</li>
<li><b>Adresses</b> : service Nominatim d'OpenStreetMap
(<a href="https://operations.osmfoundation.org/policies/nominatim/">politique d'usage</a>), données © contributeurs OpenStreetMap.</li>
<li><b>Service</b> : API Overpass, serveurs publics soumis à leur politique d'usage
raisonnable (pas d'appels massifs automatisés).</li>
<li><b>Plugin</b> : OSM Tracer © 2026 skycrow2 – licence GNU GPL v2 ou ultérieure
(fichier LICENSE). Fourni sans aucune garantie.</li>
</ul>
"""
