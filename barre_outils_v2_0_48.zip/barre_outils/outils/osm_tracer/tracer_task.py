# -*- coding: utf-8 -*-
# OSM Tracer – plugin QGIS
# Copyright (C) 2026 skycrow2 <skycrow2@gmail.com>
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version. See the LICENSE file.
#
# SPDX-License-Identifier: GPL-2.0-or-later
# Données routières : © contributeurs OpenStreetMap, licence ODbL 1.0
"""Tâche de fond : téléchargement Overpass + calcul d'itinéraire."""
import json
import time
from urllib.parse import quote, urlencode

from qgis.core import QgsTask, QgsFeedback, QgsNetworkAccessManager, QgsBlockingNetworkRequest, QgsMessageLog, Qgis
from qgis.PyQt.QtCore import QUrl, QByteArray
from qgis.PyQt.QtNetwork import QNetworkRequest

from . import osm_router
from .version import __version__

LOG_TAG = "OSM Tracer"

# Cache simple : requête Overpass -> JSON (évite de re-télécharger quand on
# ne change que les poids / vitesses).
_CACHE = {}


# Serveurs Overpass publics, essayés dans l'ordre en mode « Auto ».
OVERPASS_SERVERS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
]
AUTO = "Auto (bascule entre serveurs)"
OVERPASS_TIMEOUT_S = 150                      # délai côté serveur
NETWORK_TIMEOUT_MS = (OVERPASS_TIMEOUT_S + 30) * 1000  # délai côté QGIS


def _post(url, query, feedback=None):
    req = QNetworkRequest(QUrl(url))
    req.setHeader(QNetworkRequest.KnownHeaders.ContentTypeHeader,
                  "application/x-www-form-urlencoded")
    req.setRawHeader(b"User-Agent", ("QGIS-OSM-Tracer/%s" % __version__).encode())
    data = QByteArray(("data=" + quote(query, safe="")).encode("ascii"))
    blocking = QgsBlockingNetworkRequest()
    # Le délai réseau global de QGIS (60 s par défaut) est souvent trop court
    # pour Overpass : on l'allonge le temps de la requête puis on le restaure.
    old_timeout = QgsNetworkAccessManager.timeout()
    try:
        if old_timeout < NETWORK_TIMEOUT_MS:
            QgsNetworkAccessManager.setTimeout(NETWORK_TIMEOUT_MS)
        err = blocking.post(req, data, False, feedback)
    finally:
        QgsNetworkAccessManager.setTimeout(old_timeout)
    if err != QgsBlockingNetworkRequest.ErrorCode.NoError:
        raise IOError(blocking.errorMessage())
    raw = bytes(blocking.reply().content())
    try:
        result = json.loads(raw.decode("utf-8"))
    except ValueError:
        raise IOError("réponse non JSON (serveur surchargé ?)")
    remark = result.get("remark", "")
    if remark and ("runtime error" in remark or "timed out" in remark) \
            and not result.get("elements"):
        raise IOError(remark)
    return result


def fetch_overpass(server, query, feedback=None, log=None, is_canceled=None):
    """server : URL ou AUTO. En cas d'échec (504, 429, timeout…) on réessaie
    puis on bascule sur le serveur suivant."""
    if query in _CACHE:
        return _CACHE[query]
    urls = OVERPASS_SERVERS if server == AUTO else [server]
    errors = []
    for url in urls:
        for attempt in range(2):
            if is_canceled and is_canceled():
                raise osm_router.Canceled()
            try:
                if log:
                    log("Overpass : %s (essai %d)" % (url, attempt + 1))
                result = _post(url, query, feedback)
                _CACHE.clear()  # on ne garde que la dernière zone
                _CACHE[query] = result
                return result
            except IOError as e:
                if is_canceled and is_canceled():
                    raise osm_router.Canceled()
                msg = str(e)
                errors.append("%s → %s" % (url.split("/")[2], msg))
                if log:
                    log(errors[-1])
                # surcharge temporaire : petite pause avant de réessayer
                if any(c in msg.lower() for c in ("gateway", "too many", "429", "504",
                                                  "timed out", "timeout", "interrompu",
                                                  "canceled", "annul")):
                    for _ in range(int((3 + 4 * attempt) * 10)):  # pause interruptible
                        if is_canceled and is_canceled():
                            raise osm_router.Canceled()
                        time.sleep(0.1)
                else:
                    break
    raise osm_router.RoutingError(
        "Tous les serveurs Overpass ont échoué (surcharge probable, réessayez "
        "dans quelques minutes ou réduisez la zone / les types de voies) :\n- "
        + "\n- ".join(errors[-len(urls):]))


NOMINATIM_URL = "https://nominatim.openstreetmap.org/reverse"


def reverse_geocode(lon, lat, feedback=None):
    """Adresse la plus proche via Nominatim (1 requête, politique d'usage
    respectée). Retourne dict(address, lon, lat, dist_m) ou None."""
    params = urlencode({"format": "jsonv2", "lat": "%.7f" % lat, "lon": "%.7f" % lon,
                        "zoom": 18, "addressdetails": 1, "accept-language": "fr"})
    req = QNetworkRequest(QUrl(NOMINATIM_URL + "?" + params))
    req.setRawHeader(b"User-Agent", ("QGIS-OSM-Tracer/%s" % __version__).encode())
    blocking = QgsBlockingNetworkRequest()
    if blocking.get(req, False, feedback) != QgsBlockingNetworkRequest.ErrorCode.NoError:
        raise IOError(blocking.errorMessage())
    data = json.loads(bytes(blocking.reply().content()).decode("utf-8"))
    address = osm_router.format_address(data)
    if not address:
        return None
    alon, alat = float(data.get("lon", lon)), float(data.get("lat", lat))
    return dict(address=address, lon=alon, lat=alat,
                dist_m=osm_router.haversine(lon, lat, alon, alat))


class RouteTask(QgsTask):
    def __init__(self, start, end, settings, overpass_url, on_done, targets=None,
                 max_routes=1):
        """targets : liste de (lon, lat) -> itinéraire vers la plus proche
        par la route (end est alors ignoré)."""
        super().__init__("OSM Tracer – calcul d'itinéraire", QgsTask.Flag.CanCancel)
        self.start, self.end = start, end
        self.targets = targets
        self.max_routes = max_routes
        self.settings = settings
        self.url = overpass_url
        self.on_done = on_done
        self.result = None
        self.feedback = QgsFeedback()
        self.error = None

    def cancel(self):
        self.feedback.cancel()   # interrompt le téléchargement en cours
        super().cancel()

    def run(self):
        try:
            if self.targets:
                bbox = osm_router.compute_bbox_pts([self.start] + list(self.targets))
            else:
                bbox = osm_router.compute_bbox(self.start, self.end)
            if osm_router.bbox_too_large(bbox):
                raise osm_router.RoutingError(
                    "Zone trop étendue pour Overpass (> ~100 km). "
                    "Rapprochez les points, réduisez le rayon ou les types de voies.")
            query = osm_router.build_overpass_query(bbox, self.settings["enabled"], timeout=OVERPASS_TIMEOUT_S)
            self.setProgress(5)
            data = fetch_overpass(
                self.url, query, feedback=self.feedback,
                log=lambda m: QgsMessageLog.logMessage(m, LOG_TAG, Qgis.MessageLevel.Info),
                is_canceled=self.isCanceled)
            if self.isCanceled():
                return False
            self.setProgress(60)
            if self.targets:
                routes = osm_router.route_to_all(
                    data, self.start, self.targets, self.settings, self.max_routes,
                    is_canceled=self.isCanceled)
                self.setProgress(80)
                for n, r in enumerate(routes):
                    if n:   # Nominatim : 1 requête / seconde maximum
                        for _ in range(11):
                            if self.isCanceled():
                                raise osm_router.Canceled()
                            time.sleep(0.1)
                    tlon, tlat = self.targets[r["target_index"]]
                    try:   # adresse : facultative, un échec ne bloque pas le résultat
                        r["address"] = reverse_geocode(tlon, tlat, self.feedback)
                    except Exception as e:  # noqa
                        r["address"] = None
                        QgsMessageLog.logMessage("Adresse (Nominatim) indisponible : %s" % e,
                                                 LOG_TAG, Qgis.MessageLevel.Warning)
                    self.setProgress(80 + 20 * (n + 1) / len(routes))
                self.result = dict(routes=routes)
            else:
                self.result = dict(routes=[osm_router.route(
                    data, self.start, self.end, self.settings,
                    is_canceled=self.isCanceled)])
            self.setProgress(100)
            return True
        except Exception as e:  # noqa
            self.error = str(e)
            QgsMessageLog.logMessage(self.error, LOG_TAG, Qgis.MessageLevel.Warning)
            return False

    def finished(self, ok):
        self.on_done(self.result if ok else None, self.error)
