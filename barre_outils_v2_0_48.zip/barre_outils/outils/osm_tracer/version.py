# -*- coding: utf-8 -*-
# OSM Tracer – plugin QGIS
# Copyright (C) 2026 skycrow2 <skycrow2@gmail.com>
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version. See the LICENSE file.
#
# SPDX-License-Identifier: GPL-2.0-or-later
# Données routières : © contributeurs OpenStreetMap, licence ODbL 1.0
"""Version unique lue depuis metadata.txt (source de vérité)."""
import configparser
import os

_cfg = configparser.ConfigParser()
_cfg.read(os.path.join(os.path.dirname(__file__), "metadata.txt"), encoding="utf-8")
__version__ = _cfg.get("general", "version", fallback="0.0.0")
