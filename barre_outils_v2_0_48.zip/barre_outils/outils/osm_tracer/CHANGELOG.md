# Changelog

Format : [Keep a Changelog](https://keepachangelog.com/fr/1.1.0/), versions [SemVer](https://semver.org/lang/fr/).
La version de référence est `version=` dans `metadata.txt`.

## [1.32.0] - 2026-10-23
### Modifié
- La section **Options** (trace, serveur Overpass, affichage) est déplacée dans une fenêtre ouverte par l'**icône engrenage** en haut à droite du panneau.

## [1.31.0] - 2026-10-23
### Modifié
- Fermeture du panneau : la requête est vidée (points, direction, sélection sur la carte en cours, retour à l'onglet Itinéraire).
- Nouveau clic sur **Départ** ou **Arrivée** : le point déjà placé est retiré ; après un nouveau départ, l'arrivée n'est redemandée que si elle est absente.
- Bouton **Effacer** remplacé par une icône moderne de rafraîchissement.

## [1.30.0] - 2026-10-17
### Modifié
- Mode deux points : après le clic du départ, le **clic suivant place directement l'arrivée** (après le clic de direction si l'option est cochée).
- Lancement d'un nouveau calcul : une fois le choix fait (Enregistrer / Conserver / Supprimer), les anciens tracés, points d'arrivée et le résultat sont **effacés avant le calcul** au lieu de rester affichés jusqu'à la fin.

## [1.29.0] - 2026-10-17
### Modifié
- **Effacer** est grisé tant qu'aucun tracé n'existe (s'active après un calcul, se grise après effacement, suppression ou enregistrement de la couche).
- Lancer un **nouveau calcul** (entre deux points ou par rayon) alors que des tracés existent ouvre le même choix : **Enregistrer… / Conserver / Supprimer / Annuler** (Annuler : le calcul n'est pas lancé).

## [1.28.0] - 2026-10-17
### Ajouté
- **Effacer** (s'il y a des tracés) : choix **Enregistrer…** (GeoPackage, dossier du projet par défaut, ajouté au projet), **Conserver** (copie dans une couche temporaire séparée « Itinéraires OSM – conservés HH:MM:SS », que les calculs suivants ne remplacent pas), **Supprimer** ou **Annuler**. Points, cercle et résultat sont effacés sauf en cas d'annulation.

## [1.27.0] - 2026-10-17
### Modifié
- Traits **beaucoup plus fins** : largeur par défaut 0,4 mm (les anciens défauts 1,2 et 0,6 mm sont ramenés à 0,4).
- Tracés qui empruntent les mêmes rues : plus d'élargissement ; ils sont **décalés côte à côte** en lignes parallèles fines (champ `decalage`, en mm), tous à la même largeur.

## [1.26.0] - 2026-10-17
### Modifié
- Mise en évidence du bouton **▶ Calculer** (tout est prêt) en **bleu pastel** au lieu du vert.

## [1.25.0] - 2026-10-17
### Ajouté
- Fermeture du panneau : la question propose **Enregistrer…** (bouton par défaut), **Supprimer** ou **Conserver**. Enregistrer copie les traces dans un GeoPackage (`itineraires_osm.gpkg` dans le dossier du projet par défaut ; chaque enregistrement ajoute une couche `itineraires_AAAAMMJJ_HHMMSS`), l'ajoute au projet avec le même style et l'attribution OSM, puis retire la couche temporaire. Annuler la boîte d'enregistrement conserve la couche temporaire.

## [1.24.0] - 2026-10-17
### Modifié
- Icônes **Départ** (vert) et **Arrivée** (rouge) modernisées : épingle pleine à cœur blanc sur les boutons (SVG, au lieu de l'emoji 📍) et sur la carte principale comme sur la carte du résultat (au lieu des cercles).

## [1.23.0] - 2026-10-17
### Modifié
- **Aide** déplacée dans la barre de titre du panneau (icône « ? » cerclée), à côté des boutons détacher / fermer.
- Traits **affinés** : largeur par défaut 0,6 mm (au lieu de 1,2), écart entre tracés superposés réduit, clignotement en trait de 1 px.
- Case « Arrivée = élément d'une couche » renommée **« Recherche d'élément(s) dans un rayon »**, avec une icône de rayon.
### Corrigé
- Titres des groupes repliables (ex. « Options ») : jambage du « p » plus coupé (groupes repliables réécrits : flèche + titre, état mémorisé).

## [1.22.0] - 2026-10-17
### Modifié
- Mise en évidence d'un tracé : clignotement en **trait fin** (2 px) avec un cercle sur l'arrivée, au lieu de la large bande de QGIS.
### Ajouté
- Carte du résultat : un clic là où **plusieurs tracés se superposent** ouvre un menu (pastille de couleur, n°, distance, élément) pour choisir celui à sélectionner.

## [1.21.0] - 2026-10-17
### Ajouté
- Bouton **▶ Calculer** mis en évidence (vert, gras — bleu pastel depuis la 1.26.0) quand tout est prêt : départ placé, arrivée ou au moins une couche de recherche cochée, au moins un type de voie. Il redevient normal après le calcul, et se rallume dès qu'un réglage ou un point change.

## [1.20.0] - 2026-10-17
### Ajouté
- Tracés qui empruntent les **mêmes tronçons** : largeurs étagées (le plus proche, le plus fin, est dessiné au-dessus ; les suivants, plus larges, dessous), de sorte que chaque couleur reste visible en bordure. Les tracés sans tronçon commun gardent la largeur d'Options.

## [1.19.1] - 2026-10-17
### Modifié
- Flèche de direction plus petite et plus fine ; elle devient translucide une fois le calcul terminé (opaque à nouveau si le départ ou la direction change).

## [1.19.0] - 2026-10-17
### Modifié
- Fermeture du panneau (croix, icône ou menu) : une confirmation propose de **supprimer la couche temporaire « Itinéraires OSM »** du projet. Oui : couche supprimée. Non : la couche est conservée avec ses traces (points, cercle et résultat sont effacés dans les deux cas). Au déchargement de l'extension (fermeture de QGIS, rechargement), pas de question.
### Corrigé
- Plus d'erreur si la couche « Itinéraires OSM » a été supprimée à la main avant un nouveau calcul.

## [1.18.0] - 2026-10-17
### Modifié
- Un nouveau calcul **remplace** les traces précédentes (retour au comportement d'avant la 1.12.0). Les tracés d'un même calcul gardent chacun leur couleur.
### Ajouté
- Carte du résultat : le curseur devient une **main** au survol d'un tracé ou d'un point cliquable (main ouverte de déplacement ailleurs).

## [1.17.1] - 2026-10-17
### Corrigé
- Direction de la voie : quand le départ est cliqué sur (ou tout près d') une voie, la demi-droite la coupait immédiatement et cette voie restait choisie. Les voies à moins de 15 m du départ sont désormais ignorées : on prend la voie suivante dans la direction (ex. départ sur la route principale, flèche vers la rue Basse Méhagne → rue Basse Méhagne).

## [1.17.0] - 2026-10-17
### Corrigé
- Direction de la voie : si le clic de direction tombe sur une voie (≤ 60 m), le départ s'accroche à **cette voie** (au point le plus proche du départ), même si une autre voie coupe la direction avant. Sinon, première voie dans la direction, comme avant. Un angle saisi à la main utilise la direction seule.
### Ajouté
- Nom de la voie d'accroche du départ dans le résultat (« Accroche à la voie : départ 10 m (Rue …) »).
- Clic sur un tracé ou un point de la **carte du résultat** : le tracé est sélectionné dans la liste (fond teinté, défilement) et clignote sur les deux cartes. Même sélection au clic dans la liste.
### Modifié
- Icône de l'option Direction : flèche de navigation dans un cercle (SVG) au lieu de l'emoji boussole.

## [1.16.0] - 2026-10-17
### Ajouté
- Clic sur un tracé dans l'onglet Résultat : il **clignote** (avec son point d'arrivée) sur la carte principale et la carte du résultat.
### Modifié
- Direction de la voie cochée : après le clic du départ, le **clic suivant** donne directement la direction (plus besoin du bouton Pointer). Cocher la case avec un départ déjà placé lance aussi ce clic.
- Carte du résultat : la moitié de la hauteur de l'onglet.

## [1.15.0] - 2026-10-17
### Modifié
- **Direction** (renommée « Direction de la voie ») : le départ s'accroche à la première voie coupée par la demi-droite dans cette direction (repli : la plus proche dans un cône de ±45°, puis la plus proche). Remplace la contrainte de sens de départ de la 1.14.0, qui ne donnait pas l'effet attendu.
- Éléments atteints marqués d'un **point** de la couleur du tracé (contour blanc) au lieu d'une croix, sur la carte principale et la carte du résultat.
- Onglet Résultat : carte **sous** la liste, fond **OpenStreetMap** (EPSG:3857, attribution affichée), cadrage = **2× l'emprise** des tracés.

## [1.14.0] - 2026-10-17
### Ajouté
- **Direction de départ** (option, groupe Points) : azimut saisi ou pointé sur la carte ; le tracé quitte le départ dans cette direction (±90°). Flèche verte sur la carte.
- **Recherche multi-couches** : liste de couches à cocher (mémorisée). Le filtre s'applique aux couches qui possèdent les champs utilisés.
- Onglet Résultat : **carte au 1:10 000** centrée sur les tracés (élargie s'ils ne tiennent pas), zoom molette / déplacement, échelle graphique et flèche du nord translucides, départ et croix des éléments.
### Modifié
- L'onglet Résultat n'apparaît que lorsqu'il y a un résultat.
- Groupe Options placé sous « Recherche de la destination ».

## [1.13.0] - 2026-10-14
### Ajouté
- Mode recherche : un tracé vers **chaque** élément du rayon (les plus proches par la route d'abord), chacun dans sa couleur avec sa croix sur la carte. Nombre max réglable (« Tracés max », 5 par défaut).
- Onglet **Résultat** : liste numérotée des tracés (distance, total avec accroches, élément, adresse, types de voies, accroches). Il s'ouvre automatiquement après un calcul ; une ligne d'état reste sous les onglets.
### Modifié
- Adresses : une requête Nominatim par tracé, espacées d'1 s (politique d'usage).

## [1.12.0] - 2026-10-14
### Modifié
- Les calculs successifs **s'ajoutent** à la couche « Itinéraires OSM », chacun dans une couleur différente (couleur d'Options pour la première, puis palette). Un trait de la couleur de la trace précède la distance dans le résultat. « Effacer » ou la fermeture du panneau suppriment toutes les traces.
- Groupe « Recherche de la destination » repliable (état mémorisé) ; texte explicatif déplacé en info-bulle.
- Résultat : mention « … m à vol d'oiseau » retirée.

## [1.11.2] - 2026-10-14
### Ajouté
- Second total : longueur de la trace + accroches départ et arrivée/cible, affiché à côté de la distance et enregistré dans le champ `distance_tot_km`.
### Modifié
- Distance de la trace en police plus petite.

## [1.11.1] - 2026-10-14
### Modifié
- Résultat plus sobre : distance en graisse légère, plus d'emoji ni de gras, informations secondaires en gris et plus petites.

## [1.11.0] - 2026-10-14
### Ajouté
- Mode recherche : adresse la plus proche de l'élément trouvé (géocodage inverse Nominatim / OSM), affichée dans le résultat avec sa distance à l'élément, et enregistrée dans le champ `cible_adresse`. En cas d'échec, « adresse indisponible » sans bloquer le calcul.

## [1.10.3] - 2026-10-14
### Modifié
- « Effacer » retire aussi le cercle de recherche et supprime le trajet de la couche « Itinéraires OSM ».
- Fermer le panneau (croix, icône, menu ou déchargement de l'extension) arrête le calcul en cours et efface trajet, points et cercle. La couche (vide) est conservée.

## [1.10.2] - 2026-10-14
### Corrigé
- Le cercle du rayon de recherche est retiré de la carte à la fermeture du panneau / de l'extension, sur « ■ Arrêter » et au rafraîchissement de la carte (F5). Il réapparaît à la réouverture du panneau ou en modifiant le départ ou le rayon.

## [1.10.1] - 2026-10-14
### Modifié
- Plus d'onglet : le groupe « Recherche de la destination » est en bas du panneau, affiché seulement quand « 🔎 Arrivée = élément d'une couche » est cochée.

## [1.10.0] - 2026-10-14
### Ajouté
- Case « 🔎 Arrivée = élément d'une couche » (onglet Itinéraire) : masque l'arrivée et affiche l'onglet **Recherche**.
- Onglet Recherche : couche (points, lignes, polygones), rayon en mètres autour du départ (cercle affiché sur la carte), filtre d'expression optionnel, option « entités sélectionnées uniquement ».
- L'itinéraire est calculé vers l'élément du rayon le plus proche **par la route** (profil, voies, vitesses et préférences de l'onglet Itinéraire) ; lignes / polygones : point le plus proche du départ. Maximum 300 candidats (les plus proches).
- Trace : champs `cible_couche`, `cible_fid`, `cible_vol_m` et attributs de l'élément atteint préfixés `cible_` ; marqueur ✕ sur l'élément trouvé.
### Modifié
- Recherche du tronçon le plus proche accélérée (index spatial).

## [1.9.1] - 2026-10-13
### Ajouté
- Attribution « © contributeurs OpenStreetMap » (ODbL 1.0) : bas du panneau (lien), aide, métadonnées et attribution de la couche, champ `source`.
- Licence du plugin GPL v2 ou ultérieure (fichier LICENSE, en-têtes SPDX).

## [1.9.0] - 2026-10-13
### Modifié
- Chaque nouveau calcul supprime les traces précédentes de la couche « Itinéraires OSM ».
- Résultat : distance / durée en graisse normale.

## [1.8.2] - 2026-10-13
### Modifié
- Résultat : distance / durée en graisse moyenne au lieu de gras.

## [1.8.1] - 2026-10-13
### Corrigé
- « Requête réseau interrompue » : le délai réseau QGIS (60 s par défaut) est porté à 180 s le temps de la requête Overpass, puis restauré.
- Requête Overpass beaucoup plus légère avec RAVeL : seuls les tronçons des relations RAVeL (ou nommés RAVeL) sont téléchargés, plus tous les chemins/sentiers de la zone.

## [1.8.0] - 2026-10-13
### Ajouté
- Option « Afficher la colonne Préférence » (masquée par défaut, mémorisée). Les préférences restent appliquées.

## [1.7.0] - 2026-10-13
### Ajouté
- Liste « Types de voies » redimensionnable verticalement via une poignée (double-clic = taille d'origine, taille mémorisée).

## [1.6.0] - 2026-10-13
### Ajouté
- Option « Afficher la colonne km/h » (masquée par défaut, mémorisée). Les vitesses restent appliquées.

## [1.5.1] - 2026-10-13
### Modifié
- Résultat : types de voies utilisés affichés en liste à puces, une ligne par type.

## [1.5.0] - 2026-10-13
### Ajouté
- Option « Afficher la durée (minutes) » dans Options (désactivée par défaut, mémorisée). Le champ `duree_min` reste toujours rempli.

## [1.4.1] - 2026-10-13
### Modifié
- Résultat agrandi (distance / durée en gros caractères) et épinglé en bas du panneau.

## [1.4.0] - 2026-10-13
### Ajouté
- Choix du système d'affichage des coordonnées : WGS84, Lambert 72 (EPSG:31370), Lambert 2008 (EPSG:3812).
### Modifié
- Panneau compacté : boutons et résultat juste sous le profil, « Types de voies » et « Options » (style, serveur) repliables, barre de défilement si nécessaire.

## [1.3.0] - 2026-10-13
### Supprimé
- Curseur Rapide ↔ Court : le poids temps/distance est fixé par le profil.
### Modifié
- Profil par défaut « Le plus court » : autoroute décochée, RAVeL coché.

## [1.2.1] - 2026-10-13
### Modifié
- Profil par défaut « Le plus court » : « Respecter les sens uniques » et « Véhicule motorisé » décochés.

## [1.2.0] - 2026-10-13
### Ajouté
- Bouton « ■ Arrêter » : interrompt téléchargement Overpass, pauses de nouvel essai et calcul Dijkstra.
### Modifié
- Profil par défaut : « Le plus court ».

## [1.1.1] - 2026-10-13
### Corrigé
- « Gateway Timeout » Overpass : nouvel essai puis bascule automatique vers d'autres serveurs (mode *Auto*, choix du serveur dans une liste).
- Encodage de la requête Overpass fiabilisé.

## [1.1.0] - 2026-10-13
### Ajouté
- Accroche du clic sur la voie la plus proche (projection sur le tronçon, pas seulement le nœud).
- Bouton d'aide « ? ».
- Choix de la couleur et de l'épaisseur de chaque trace (champs `couleur`, `epaisseur`).
- Versioning : version affichée dans le panneau, l'aide et le champ `version` des traces.

## [1.0.0] - 2026-10-13
### Ajouté
- Routage OSM via Overpass + Dijkstra, profils, curseur rapide ↔ court, sélection des types de voies (dont RAVeL).
