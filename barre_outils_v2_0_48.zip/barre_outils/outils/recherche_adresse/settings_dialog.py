from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QFormLayout,
    QComboBox,
    QDialogButtonBox,
    QLabel,
)
from .help import show_help
from qgis.core import Qgis, QgsProject, QgsMapLayer, QgsSettings

SETTINGS_GROUP = "RechercheAdresse"


def _is_vector(lyr):
    try:
        return lyr.type() == Qgis.LayerType.Vector
    except AttributeError:  # QGIS < 3.30
        return lyr.type() == QgsMapLayer.VectorLayer


COUNTRIES = [
    ("Allemagne", "de"), ("Autriche", "at"), ("Belgique", "be"),
    ("Bulgarie", "bg"), ("Canada", "ca"), ("Chypre", "cy"), ("Croatie", "hr"),
    ("Danemark", "dk"), ("Espagne", "es"), ("Estonie", "ee"),
    ("États-Unis", "us"), ("Finlande", "fi"), ("France", "fr"),
    ("Grèce", "gr"), ("Hongrie", "hu"), ("Irlande", "ie"), ("Islande", "is"),
    ("Italie", "it"), ("Lettonie", "lv"), ("Lituanie", "lt"),
    ("Luxembourg", "lu"), ("Malte", "mt"), ("Maroc", "ma"), ("Monaco", "mc"),
    ("Norvège", "no"), ("Pays-Bas", "nl"), ("Pologne", "pl"),
    ("Portugal", "pt"), ("République tchèque", "cz"), ("Roumanie", "ro"),
    ("Royaume-Uni", "gb"), ("Slovaquie", "sk"), ("Slovénie", "si"),
    ("Suède", "se"), ("Suisse", "ch"), ("Tunisie", "tn"), ("Algérie", "dz"),
]
COUNTRIES.sort(key=lambda c: c[0].replace("É", "E"))


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configuration - Recherche Adresse")
        self.setMinimumWidth(420)

        layout = QVBoxLayout(self)

        info = QLabel(
            "Choisissez la source. Pour une couche du projet, selectionnez la couche contenant les adresses, puis le champ "
            "a utiliser pour la recherche (ex : un champ 'adresse' complet, "
            "ou un champ qui concatene numero + rue + commune)."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        self.source_combo = QComboBox()
        self.source_combo.addItem("Nominatim (OpenStreetMap)", "nominatim")
        self.source_combo.addItem("Couche du projet", "layer")

        self.country_combo = QComboBox()
        self.country_combo.addItem("Tous les pays", "")
        for name, code in COUNTRIES:
            self.country_combo.addItem(name, code)
        saved_country = (QgsSettings().value(f"{SETTINGS_GROUP}/countrycodes", "be") or "").lower()
        idx = self.country_combo.findData(saved_country)
        self.country_combo.setCurrentIndex(idx if idx >= 0 else 0)

        self.layer_combo = QComboBox()
        self.field_combo = QComboBox()

        form = QFormLayout()
        form.addRow("Source :", self.source_combo)
        form.addRow("Pays :", self.country_combo)
        form.addRow("Couche :", self.layer_combo)
        form.addRow("Champ adresse :", self.field_combo)
        layout.addLayout(form)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
            | QDialogButtonBox.StandardButton.Help)
        buttons.accepted.connect(self.on_accept)
        buttons.rejected.connect(self.reject)
        buttons.helpRequested.connect(lambda: show_help(self, "config"))
        layout.addWidget(buttons)

        self.layer_combo.currentIndexChanged.connect(self.update_fields)

        self.source_combo.currentIndexChanged.connect(self.update_enabled)
        saved_source = QgsSettings().value(f"{SETTINGS_GROUP}/source", "nominatim")
        self.source_combo.setCurrentIndex(max(0, self.source_combo.findData(saved_source)))

        self.populate_layers()
        self.update_enabled()

    def update_enabled(self):
        use_layer = self.source_combo.currentData() == "layer"
        self.country_combo.setEnabled(not use_layer)
        self.layer_combo.setEnabled(use_layer)
        self.field_combo.setEnabled(use_layer)

    def populate_layers(self):
        settings = QgsSettings()
        saved_layer_id = settings.value(f"{SETTINGS_GROUP}/layer_id", "")

        self.layer_combo.clear()
        vector_layers = [
            lyr
            for lyr in QgsProject.instance().mapLayers().values()
            if _is_vector(lyr)
        ]
        for lyr in vector_layers:
            self.layer_combo.addItem(lyr.name(), lyr.id())

        index = self.layer_combo.findData(saved_layer_id)
        if index >= 0:
            self.layer_combo.setCurrentIndex(index)
        elif self.layer_combo.count() > 0:
            self.layer_combo.setCurrentIndex(0)

        self.update_fields()

    def update_fields(self):
        settings = QgsSettings()
        saved_field = settings.value(f"{SETTINGS_GROUP}/field_name", "")

        self.field_combo.clear()
        layer_id = self.layer_combo.currentData()
        if not layer_id:
            return
        layer = QgsProject.instance().mapLayer(layer_id)
        if layer is None:
            return
        for field in layer.fields():
            self.field_combo.addItem(field.name())

        index = self.field_combo.findText(saved_field)
        if index >= 0:
            self.field_combo.setCurrentIndex(index)

    def on_accept(self):
        settings = QgsSettings()
        settings.setValue(f"{SETTINGS_GROUP}/source", self.source_combo.currentData())
        settings.setValue(f"{SETTINGS_GROUP}/countrycodes", self.country_combo.currentData())
        settings.setValue(f"{SETTINGS_GROUP}/layer_id", self.layer_combo.currentData())
        settings.setValue(f"{SETTINGS_GROUP}/field_name", self.field_combo.currentText())
        self.accept()
