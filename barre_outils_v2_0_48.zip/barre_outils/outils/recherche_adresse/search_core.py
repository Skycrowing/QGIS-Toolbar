import json

from qgis.core import (
    Qgis,
    QgsFeatureRequest,
    QgsSettings,
    QgsProject,
    QgsBlockingNetworkRequest,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsRectangle,
    QgsGeometry,
    QgsPointXY,
)
from qgis.PyQt.QtCore import QUrl, QUrlQuery
from qgis.PyQt.QtNetwork import QNetworkRequest

try:
    _NO_GEOMETRY = Qgis.FeatureRequestFlag.NoGeometry
except AttributeError:  # QGIS < 3.36
    _NO_GEOMETRY = QgsFeatureRequest.NoGeometry
_NO_ERROR = getattr(QgsBlockingNetworkRequest, "ErrorCode", QgsBlockingNetworkRequest).NoError

SETTINGS_GROUP = "RechercheAdresse"

SOURCE_NOMINATIM = "nominatim"
SOURCE_LAYER = "layer"
NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"


# --- Configuration -----------------------------------------------------

def get_source():
    """Source de recherche : Nominatim par defaut."""
    return QgsSettings().value(f"{SETTINGS_GROUP}/source", SOURCE_NOMINATIM)


def get_countrycodes():
    """Codes pays ISO (ex : 'be,fr') pour filtrer Nominatim, ou chaine vide."""
    raw = QgsSettings().value(f"{SETTINGS_GROUP}/countrycodes", "be") or ""
    codes = [c.strip().lower() for c in raw.replace(";", ",").split(",")]
    return ",".join(c for c in codes if len(c) == 2 and c.isalpha())


def get_settings():
    """Retourne (layer_id, field_name) configures via le menu Configurer."""
    settings = QgsSettings()
    layer_id = settings.value(f"{SETTINGS_GROUP}/layer_id", "")
    field_name = settings.value(f"{SETTINGS_GROUP}/field_name", "")
    return layer_id, field_name


def get_configured_layer():
    """Retourne la couche configuree (ou None si pas configuree / absente)."""
    layer_id, field_name = get_settings()
    if not layer_id or not field_name:
        return None, None
    layer = QgsProject.instance().mapLayer(layer_id)
    if layer is None:
        return None, None
    if layer.fields().indexFromName(field_name) < 0:
        return None, None
    return layer, field_name


def is_ready():
    """(pret, message) selon la source configuree."""
    if get_source() == SOURCE_NOMINATIM:
        return True, "Recherche via Nominatim (OpenStreetMap)."
    layer, field_name = get_configured_layer()
    if layer is None:
        return False, ("Aucune couche/champ configure. Utilisez le bouton "
                       "Configurer...")
    return True, f"Pret a rechercher dans « {layer.name()} » ({field_name})."


# --- Recherche ---------------------------------------------------------

def format_label(count, display_value):
    """Libelle affiche : ajoute le nombre d'elements si plusieurs."""
    return f"{display_value} ({count})" if count > 1 else display_value


def search(text, feedback=None):
    """
    Recherche selon la source configuree.
    Retourne une liste de tuples (label, description, payload), ou payload
    est un dict passe ensuite a zoom_to_result().
    """
    if get_source() == SOURCE_NOMINATIM:
        return search_nominatim(text, feedback)
    return search_layer(text)


def search_layer(text, limit=30, max_features=5000):
    """
    Recherche dans la couche configuree (tous les mots, insensible a la
    casse). Les entites de meme valeur sont regroupees.
    """
    text = (text or "").strip()
    if not text:
        return []

    layer, field_name = get_configured_layer()
    if layer is None:
        return []

    conditions = []
    for word in text.split():
        escaped = word.replace("'", "''")
        conditions.append('"{}" ILIKE \'%{}%\''.format(field_name, escaped))

    request = QgsFeatureRequest()
    request.setFilterExpression(" AND ".join(conditions))
    request.setLimit(max_features)
    request.setSubsetOfAttributes([field_name], layer.fields())
    request.setFlags(_NO_GEOMETRY)

    groups = {}
    try:
        for feature in layer.getFeatures(request):
            value = feature[field_name]
            if value is None:
                continue
            key = str(value)
            if key in groups:
                groups[key].append(feature.id())
            elif len(groups) < limit:
                groups[key] = [feature.id()]
    except Exception:
        return []

    return [
        (format_label(len(ids), value), layer.name(),
         {"type": SOURCE_LAYER, "layer_id": layer.id(), "ids": ids})
        for value, ids in groups.items()
    ]


def search_nominatim(text, feedback=None, limit=15):
    """
    Geocodage via Nominatim. Les resultats de meme libelle sont regroupes
    et l'emprise du groupe est l'union de leurs emprises.
    """
    text = (text or "").strip()
    if len(text) < 3:
        return []

    url = QUrl(NOMINATIM_URL)
    query = QUrlQuery()
    query.addQueryItem("q", text)
    query.addQueryItem("format", "jsonv2")
    query.addQueryItem("limit", str(limit))
    countries = get_countrycodes()
    if countries:
        query.addQueryItem("countrycodes", countries)
    url.setQuery(query)

    request = QNetworkRequest(url)
    lang = QgsSettings().value("locale/userLocale", "fr")[:2]
    request.setRawHeader(b"Accept-Language", lang.encode())

    blocking = QgsBlockingNetworkRequest()
    if blocking.get(request, False, feedback) != _NO_ERROR:
        return []
    try:
        data = json.loads(bytes(blocking.reply().content()).decode("utf-8"))
    except Exception:
        return []

    groups = {}
    for item in data:
        name = item.get("display_name")
        bbox = item.get("boundingbox")  # [lat_min, lat_max, lon_min, lon_max]
        if not name or not bbox:
            continue
        rect = [float(bbox[2]), float(bbox[0]), float(bbox[3]), float(bbox[1])]
        point = [float(item["lon"]), float(item["lat"])]
        if name in groups:
            g = groups[name]
            b = g["bbox"]
            g["bbox"] = [min(b[0], rect[0]), min(b[1], rect[1]),
                         max(b[2], rect[2]), max(b[3], rect[3])]
            g["points"].append(point)
        else:
            groups[name] = {"type": SOURCE_NOMINATIM, "bbox": rect,
                            "points": [point]}

    return [
        (format_label(len(p["points"]), name), "Nominatim", p)
        for name, p in groups.items()
    ]


# --- Zoom --------------------------------------------------------------

# --- Centre d'un resultat ---------------------------------------------

def result_center(payload):
    """Centre du resultat en WGS84 (QgsPointXY) ou None."""
    if not payload:
        return None
    if payload.get("type") == SOURCE_NOMINATIM:
        pts = payload.get("points") or []
        if not pts:
            return None
        return QgsPointXY(sum(p[0] for p in pts) / len(pts),
                          sum(p[1] for p in pts) / len(pts))

    layer = QgsProject.instance().mapLayer(payload.get("layer_id"))
    ids = payload.get("ids") or []
    if layer is None or not ids:
        return None
    rect = None
    for f in layer.getFeatures(QgsFeatureRequest().setFilterFids(ids)):
        if not f.hasGeometry():
            continue
        bbox = f.geometry().boundingBox()
        if rect is None:
            rect = QgsRectangle(bbox)
        else:
            rect.combineExtentWith(bbox)
    if rect is None:
        return None
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    transform = QgsCoordinateTransform(layer.crs(), wgs84, QgsProject.instance())
    try:
        return transform.transform(rect.center())
    except Exception:
        return None


# --- Zoom --------------------------------------------------------------

def zoom_to_result(iface, payload):
    if not payload:
        return
    if payload.get("type") == SOURCE_NOMINATIM:
        _zoom_nominatim(iface, payload)
    else:
        layer = QgsProject.instance().mapLayer(payload.get("layer_id"))
        if layer is not None:
            zoom_to_features(iface, layer, payload.get("ids", []))


def zoom_to_features(iface, layer, feat_ids):
    """Selectionne, zoome sur l'emprise de toutes les entites et les fait clignoter."""
    feat_ids = list(feat_ids)
    layer.removeSelection()
    layer.selectByIds(feat_ids)

    canvas = iface.mapCanvas()
    canvas.zoomToSelected(layer)
    canvas.flashFeatureIds(layer, feat_ids)
    iface.setActiveLayer(layer)


def _zoom_nominatim(iface, payload):
    canvas = iface.mapCanvas()
    wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
    dest = canvas.mapSettings().destinationCrs()
    transform = QgsCoordinateTransform(wgs84, dest, QgsProject.instance())

    b = payload["bbox"]
    rect = transform.transformBoundingBox(QgsRectangle(b[0], b[1], b[2], b[3]))
    rect.scale(1.1)
    canvas.setExtent(rect)
    canvas.refresh()

    geoms = [QgsGeometry.fromPointXY(QgsPointXY(x, y)) for x, y in payload["points"]]
    canvas.flashGeometries(geoms, wgs84)
