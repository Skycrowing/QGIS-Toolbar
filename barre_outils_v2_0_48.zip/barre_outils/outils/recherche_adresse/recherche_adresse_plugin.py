import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QApplication
try:
    from qgis.PyQt.QtWidgets import QAction
except ImportError:  # Qt6
    from qgis.PyQt.QtGui import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsSettings
from .locator_filter import AdresseLocatorFilter
from .settings_dialog import SettingsDialog
from .search_dock import AdresseSearchDock
from .help import show_help


class RechercheAdressePlugin:
    def __init__(self, iface):
        self.iface = iface
        self.locator_filter = None
        self.action_config = None
        self.action_help = None
        self.action_show_dock = None
        self.dock = None

    def initGui(self):
        # Enregistrement du filtre dans la barre de recherche (locator bar)
        self.locator_filter = AdresseLocatorFilter(self.iface)
        self.iface.registerLocatorFilter(self.locator_filter)

        # Panneau de recherche (dock) integre a l'interface QGIS
        self.dock = AdresseSearchDock(self.iface, self.iface.mainWindow())
        self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dock)
        self.dock.refresh()

        # Entree de menu / bouton pour afficher-masquer le panneau
        self.action_show_dock = QAction(
            QIcon(os.path.join(os.path.dirname(__file__), "icon.png")),
            "Recherche d'adresse (panneau)", self.iface.mainWindow()
        )
        self.action_show_dock.setCheckable(True)
        self.action_show_dock.triggered.connect(self._toggle_dock)
        self.dock.visibilityChanged.connect(self._on_dock_visibility)
        self.iface.addPluginToMenu("&Recherche Adresse", self.action_show_dock)
        self.iface.addToolBarIcon(self.action_show_dock)

        # Panneau affiche par defaut (Nominatim ne demande aucune config) ;
        # on memorise ensuite le choix de l'utilisateur.
        visible = QgsSettings().value(
            "RechercheAdresse/dock_visible", True, type=bool
        )
        if self.action_show_dock is not None:
            self.action_show_dock.setChecked(visible)
        if visible:
            self.show_dock()
        else:
            self.dock.setVisible(False)

        # Entree de menu pour configurer la couche / le champ a utiliser
        self.action_config = QAction(
            "Configurer la recherche d'adresse...", self.iface.mainWindow()
        )
        self.action_config.triggered.connect(self.open_settings)
        self.iface.addPluginToMenu("&Recherche Adresse", self.action_config)

        # Entree de menu Aide
        self.action_help = QAction(
            QIcon(":/images/themes/default/mActionHelpContents.svg"),
            "Aide", self.iface.mainWindow()
        )
        self.action_help.triggered.connect(
            lambda: show_help(self.iface.mainWindow()))
        self.iface.addPluginToMenu("&Recherche Adresse", self.action_help)

    def unload(self):
        if self.locator_filter is not None:
            self.iface.deregisterLocatorFilter(self.locator_filter)
            self.locator_filter = None
        if self.action_config is not None:
            self.iface.removePluginMenu("&Recherche Adresse", self.action_config)
            self.action_config = None
        if self.action_help is not None:
            self.iface.removePluginMenu("&Recherche Adresse", self.action_help)
            self.action_help = None
        if self.action_show_dock is not None:
            self.iface.removePluginMenu("&Recherche Adresse", self.action_show_dock)
            self.iface.removeToolBarIcon(self.action_show_dock)
            self.action_show_dock = None
        if self.dock is not None:
            try:
                self.dock.visibilityChanged.disconnect(self._on_dock_visibility)
            except (TypeError, RuntimeError):
                pass
            self.dock.cleanup()
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None

    def open_settings(self):
        dlg = SettingsDialog(self.iface.mainWindow())
        if dlg.exec() and self.dock is not None:
            self.dock.refresh()
            self.show_dock()

    def _on_dock_visibility(self, visible):
        if self.action_show_dock is not None:
            self.action_show_dock.setChecked(visible)

    def _toggle_dock(self, checked):
        QgsSettings().setValue("RechercheAdresse/dock_visible", checked)
        if checked:
            self.show_dock()
        else:
            self.dock.setVisible(False)

    def show_dock(self):
        """Affiche le panneau, le remet a l'ecran s'il est flottant hors
        ecran, et le passe au premier plan s'il est dans un onglet."""
        dock = self.dock
        if dock.isFloating():
            win = self.iface.mainWindow()
            try:
                screen_rect = win.screen().availableGeometry()
            except AttributeError:  # Qt < 5.14
                screen_rect = QApplication.desktop().availableGeometry(win)
            if not screen_rect.intersects(dock.geometry()):
                dock.setFloating(False)
                self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, dock)
        dock.setVisible(True)
        dock.show()
        dock.raise_()
        dock.search_edit.setFocus()
