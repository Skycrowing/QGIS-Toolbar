from qgis.PyQt.QtCore import Qt, QTimer
from qgis.PyQt.QtWidgets import (
    QDockWidget,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QListWidget,
    QListWidgetItem,
    QLabel,
    QSplitter,
)
from qgis.PyQt.QtGui import QColor
from qgis.core import (
    QgsRasterLayer,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsProject,
    QgsRectangle,
)
from qgis.gui import QgsMapCanvas, QgsVertexMarker, QgsMapToolPan

from . import search_core
from .help import show_help
from .settings_dialog import SettingsDialog
from .map_overlay import MapOverlay


class _ClickPanTool(QgsMapToolPan):
    """Glisser = deplacer la carte OSM ; simple clic = appel de on_click(point)."""

    def __init__(self, canvas, on_click):
        super().__init__(canvas)
        self._on_click = on_click
        self._press_pos = None

    def canvasPressEvent(self, e):
        self._press_pos = e.pos()
        super().canvasPressEvent(e)

    def canvasReleaseEvent(self, e):
        is_click = (
            e.button() == Qt.MouseButton.LeftButton
            and self._press_pos is not None
            and (e.pos() - self._press_pos).manhattanLength() <= 4
        )
        self._press_pos = None
        super().canvasReleaseEvent(e)
        if is_click:
            self._on_click(self.toMapCoordinates(e.pos()))


class AdresseSearchDock(QDockWidget):
    """
    Panneau permettant de rechercher une adresse directement depuis
    l'extension, sans passer par la barre de recherche (Ctrl+K).
    """

    def __init__(self, iface, parent=None):
        super().__init__("Recherche d'adresse", parent)
        self.iface = iface
        self.setObjectName("RechercheAdresseDock")
        self.setAllowedAreas(Qt.DockWidgetArea.AllDockWidgetAreas)

        container = QWidget()
        layout = QVBoxLayout(container)

        search_row = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Tapez une adresse...")
        self.search_button = QPushButton("Rechercher")
        self.config_button = QPushButton("Configurer...")
        search_row.addWidget(self.search_edit)
        search_row.addWidget(self.search_button)
        search_row.addWidget(self.config_button)
        self.help_button = QPushButton("?")
        self.help_button.setToolTip("Aide")
        self.help_button.setFixedWidth(28)
        search_row.addWidget(self.help_button)
        layout.addLayout(search_row)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        self.results_list = QListWidget()

        # Carte OpenStreetMap (partie inferieure), centree sur l'adresse
        # selectionnee au 1:10 000.
        self.osm_layer = QgsRasterLayer(
            "type=xyz&url=https://tile.openstreetmap.org/{z}/{x}/{y}.png"
            "&zmin=0&zmax=19",
            "OpenStreetMap", "wms")
        self.map_canvas = QgsMapCanvas()
        self.map_canvas.setCanvasColor(QColor("white"))
        self.map_canvas.setLayers([self.osm_layer])
        self.map_canvas.setMinimumHeight(200)
        self.map_overlay = MapOverlay(self.map_canvas)
        self.map_tool = _ClickPanTool(self.map_canvas, self._recenter_main_map)
        self.map_canvas.setMapTool(self.map_tool)
        self.marker = None
        self._last_center = None  # dernier centre affiche (WGS84)
        self._update_map_crs()
        QgsProject.instance().crsChanged.connect(self._on_project_crs_changed)
        # Au demarrage (et a l'ouverture d'un projet) : zone courante
        # de la carte principale.
        self.iface.projectRead.connect(self._on_project_read)

        splitter = QSplitter(Qt.Orientation.Vertical)
        splitter.addWidget(self.results_list)
        splitter.addWidget(self.map_canvas)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        layout.addWidget(splitter)

        container.setLayout(layout)
        self.setWidget(container)

        # Recherche declenchee par le bouton, la touche Entree, ou
        # automatiquement pendant la frappe (des 3 caracteres).
        # Temporisation : la recherche part apres une courte pause de frappe
        # (1 s pour Nominatim, limite a 1 requete/seconde).
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.run_search)
        self._busy = False

        self.search_button.clicked.connect(self.run_search)
        self.search_edit.returnPressed.connect(self.run_search)
        self.search_edit.textChanged.connect(self._on_text_changed)
        self.config_button.clicked.connect(self.open_settings)
        self.help_button.clicked.connect(lambda: show_help(self.iface.mainWindow()))

        self.results_list.itemDoubleClicked.connect(self._on_item_activated)
        self.results_list.itemActivated.connect(self._on_item_activated)
        self.results_list.currentItemChanged.connect(self._on_current_changed)

    # --- Recherche ---------------------------------------------------

    def _on_text_changed(self, text):
        text = text.strip()
        if not text:
            self._timer.stop()
            self.results_list.clear()
            self.status_label.setText("")
            return
        if len(text) < 3:
            return
        nominatim = search_core.get_source() == search_core.SOURCE_NOMINATIM
        self._timer.start(1000 if nominatim else 300)

    def run_search(self):
        self._timer.stop()
        if self._busy:
            # Requete en cours : on relance apres.
            self._timer.start(500)
            return
        self._busy = True
        try:
            self._do_search()
        finally:
            self._busy = False

    def _do_search(self):
        text = self.search_edit.text()
        self.results_list.clear()

        ready, message = search_core.is_ready()
        if not ready:
            self.status_label.setText(message)
            return
        if not text.strip():
            self.status_label.setText("")
            return

        self.status_label.setText("Recherche...")
        results = search_core.search(text)
        if not results:
            self.status_label.setText("Aucun resultat.")
            return

        self.status_label.setText(f"{len(results)} resultat(s)")
        for label, _description, payload in results:
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, payload)
            self.results_list.addItem(item)

    def open_settings(self):
        dlg = SettingsDialog(self)
        if dlg.exec():
            # Configuration validee : on rafraichit entierement la zone
            # de recherche (champ, resultats, message de statut) pour
            # repartir sur une base propre avec la nouvelle couche/champ.
            self.refresh()

    def refresh(self):
        self.search_edit.blockSignals(True)
        self.search_edit.clear()
        self.search_edit.blockSignals(False)

        self.results_list.clear()

        self.status_label.setText(search_core.is_ready()[1])
        self.search_edit.setFocus()

    # --- Selection d'un resultat --------------------------------------

    def _on_current_changed(self, current, _previous):
        if current is not None:
            self.show_on_map(current.data(Qt.ItemDataRole.UserRole))

    def _on_item_activated(self, item):
        payload = item.data(Qt.ItemDataRole.UserRole)
        self.show_on_map(payload)
        search_core.zoom_to_result(self.iface, payload)

    # --- Carte OSM ----------------------------------------------------

    def cleanup(self):
        """A appeler avant suppression du dock."""
        try:
            QgsProject.instance().crsChanged.disconnect(self._on_project_crs_changed)
        except (TypeError, RuntimeError):
            pass
        try:
            self.iface.projectRead.disconnect(self._on_project_read)
        except (TypeError, RuntimeError):
            pass
        self.map_canvas.unsetMapTool(self.map_tool)

    def _update_map_crs(self):
        """La carte utilise le SCR du projet (EPSG:3857 si non defini)."""
        crs = QgsProject.instance().crs()
        if not crs.isValid():
            crs = QgsCoordinateReferenceSystem("EPSG:3857")
        if self.map_canvas.mapSettings().destinationCrs() != crs:
            self.map_canvas.setDestinationCrs(crs)

    def _on_project_crs_changed(self):
        self._update_map_crs()
        if self._last_center is not None:
            self._center_map(self._last_center)
        else:
            self._show_current_area()

    def showEvent(self, event):
        super().showEvent(event)
        if self._last_center is None:
            QTimer.singleShot(0, self._show_current_area)

    def _on_project_read(self):
        if self._last_center is None:
            QTimer.singleShot(0, self._show_current_area)

    def _show_current_area(self):
        """Cale la carte OSM sur la zone affichee dans la carte principale."""
        if self._last_center is not None:
            return
        main = self.iface.mapCanvas()
        ext = main.extent()
        if not ext.isFinite() or ext.isEmpty():
            return
        self._update_map_crs()
        xform = QgsCoordinateTransform(
            main.mapSettings().destinationCrs(),
            self.map_canvas.mapSettings().destinationCrs(),
            QgsProject.instance())
        try:
            rect = xform.transformBoundingBox(ext)
        except Exception:
            return
        if not rect.isFinite() or rect.isEmpty():
            return
        self.map_canvas.setExtent(rect)
        self.map_canvas.refresh()

    def _recenter_main_map(self, pt):
        """Centre la carte principale sur le point clique (echelle conservee)."""
        main = self.iface.mapCanvas()
        transform = QgsCoordinateTransform(
            self.map_canvas.mapSettings().destinationCrs(),
            main.mapSettings().destinationCrs(),
            QgsProject.instance())
        try:
            main.setCenter(transform.transform(pt))
        except Exception:
            return
        main.refresh()

    def show_on_map(self, payload):
        center = search_core.result_center(payload)
        if center is None:
            return
        self._last_center = center
        self._update_map_crs()
        self._center_map(center)

    def _center_map(self, center):
        transform = QgsCoordinateTransform(
            QgsCoordinateReferenceSystem("EPSG:4326"),
            self.map_canvas.mapSettings().destinationCrs(),
            QgsProject.instance())
        try:
            pt = transform.transform(center)
            # Emprise initiale autour du point (la carte n'a pas encore
            # d'emprise valide au premier affichage), puis echelle 1:10 000.
            d = 0.005
            rect = transform.transformBoundingBox(QgsRectangle(
                center.x() - d, center.y() - d, center.x() + d, center.y() + d))
        except Exception:
            return

        self.map_canvas.setExtent(rect)
        self.map_canvas.setCenter(pt)
        self.map_canvas.zoomScale(10000)
        self.map_canvas.refresh()

        if self.marker is None:
            self.marker = QgsVertexMarker(self.map_canvas)
            self.marker.setIconType(getattr(QgsVertexMarker, "IconType", QgsVertexMarker).ICON_CIRCLE)
            self.marker.setColor(QColor(220, 0, 0))
            self.marker.setFillColor(QColor(220, 0, 0, 120))
            self.marker.setIconSize(14)
            self.marker.setPenWidth(2)
        self.marker.setCenter(pt)
