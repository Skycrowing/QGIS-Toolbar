# Recherche Adresse — plugin QGIS

Ajoute un filtre a la barre de recherche (locator bar) de QGIS pour
rechercher une adresse dans n'importe quelle couche vecteur deja
chargee dans le projet (PostGIS, GeoPackage, Shapefile, CSV, etc.).

## Installation

1. Fermez QGIS.
2. Copiez le dossier `recherche_adresse` entier dans le dossier des
   plugins QGIS :
   - Windows : `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
   - Linux : `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - macOS : `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
3. Ouvrez QGIS puis allez dans **Extensions > Installer/Gerer les
   extensions > Installees**, cochez **Recherche Adresse**.

   Alternative : dans QGIS, **Extensions > Installer/Gerer les
   extensions > Installer depuis un ZIP**, en pointant vers le fichier
   `recherche_adresse.zip`.

## Configuration

1. Chargez dans votre projet la couche contenant vos adresses
   (table PostGIS, GeoPackage, shapefile...).
2. Menu **Extensions > Recherche Adresse > Configurer la recherche
   d'adresse...**
3. Choisissez la couche, puis le champ contenant l'adresse (un champ
   texte complet, ou un champ calcule/virtuel qui concatene numero +
   rue + commune si votre couche est decoupee en plusieurs colonnes).
4. Validez.

## Utilisation

### Via la barre de recherche QGIS

Dans la barre de recherche QGIS (en haut a gauche de la fenetre,
ou Ctrl+K), tapez directement le prefixe suivi d'un espace :

```
Adresse rue de la paix
```

(le `>` n'est pas necessaire : il est reserve au geocodeur Nominatim
integre a QGIS, pas aux filtres personnalises comme celui-ci)

Les resultats correspondants (contenant tous les mots saisis, dans
n'importe quel ordre, insensible a la casse) s'affichent. Cliquez sur
un resultat pour zoomer et selectionner l'entite correspondante sur
la carte.

### Via le panneau dedie

Un panneau "Recherche d'adresse" est aussi disponible, sans passer
par Ctrl+K :

- Menu **Extensions > Recherche Adresse > Recherche d'adresse
  (panneau)**, ou l'icone correspondante dans la barre d'outils.
- Tapez votre recherche dans le champ de texte (la recherche se
  lance automatiquement a partir de 4 caracteres, ou en appuyant sur
  Entree / le bouton "Rechercher").
- Double-cliquez (ou selectionnez puis Entree) sur un resultat dans
  la liste pour zoomer et selectionner l'entite sur la carte.
- Le bouton **Configurer...** du panneau ouvre directement la boite
  de dialogue de configuration (couche/champ), sans passer par le
  menu Extensions. Apres validation, la zone de recherche est
  reinitialisee (champ vide, liste de resultats videe, message de
  statut indiquant la couche/le champ actif) pour repartir sur une
  base propre.

Le panneau est ancrable/deplacable comme n'importe quel panneau QGIS
et utilise la meme configuration (couche/champ) que la barre de
recherche.

## Limitations / notes

- La recherche utilise une expression `ILIKE '%mot%'` sur le champ
  choisi : elle fonctionne sur tout fournisseur de donnees supporte
  par QGIS, mais sur une tres grosse table PostGIS sans index texte
  adapte, pensez a un index trigram (`pg_trgm`) sur le champ pour de
  meilleures performances.
- Un seul champ de recherche a la fois. Si votre couche a plusieurs
  colonnes (numero, rue, code postal, commune...), le plus simple est
  de creer un champ virtuel qui les concatene (clic droit sur la
  couche > Proprietes > Champs > Nouveau champ virtuel, avec une
  expression du type `"numero" || ' ' || "rue" || ' ' || "commune"`),
  puis de selectionner ce champ virtuel dans la configuration.
