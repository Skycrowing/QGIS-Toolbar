import os

from qgis.PyQt.QtCore import QUrl
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QTextBrowser, QDialogButtonBox

PLUGIN_DIR = os.path.dirname(__file__)
HELP_FILE = os.path.join(PLUGIN_DIR, "help", "index.html")

_dialog = None


def show_help(parent=None, anchor=""):
    """Ouvre la documentation dans une fenetre non modale."""
    global _dialog
    if _dialog is None:
        _dialog = QDialog(parent)
        _dialog.setWindowTitle("Aide - Recherche Adresse")
        _dialog.setWindowIcon(QIcon(os.path.join(PLUGIN_DIR, "icon.png")))
        _dialog.resize(640, 600)
        layout = QVBoxLayout(_dialog)
        _dialog.browser = QTextBrowser()
        _dialog.browser.setOpenExternalLinks(True)
        layout.addWidget(_dialog.browser)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(_dialog.close)
        layout.addWidget(buttons)
        _dialog.destroyed.connect(_reset)

    url = QUrl.fromLocalFile(HELP_FILE)
    if anchor:
        url.setFragment(anchor)
    _dialog.browser.setSource(url)
    _dialog.show()
    _dialog.raise_()
    _dialog.activateWindow()


def _reset(*_):
    global _dialog
    _dialog = None
