def classFactory(iface):
    from .recherche_adresse_plugin import RechercheAdressePlugin
    return RechercheAdressePlugin(iface)
