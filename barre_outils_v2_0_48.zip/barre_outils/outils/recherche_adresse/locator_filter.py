import os
from qgis.core import QgsLocatorFilter, QgsLocatorResult
from qgis.PyQt.QtGui import QIcon

from . import search_core


class AdresseLocatorFilter(QgsLocatorFilter):
    """
    Filtre de recherche personnalise pour la barre de recherche QGIS.
    S'active en tapant : Adresse <texte recherche>
    """

    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        # Nominatim : 1 requete/s max, on attend la fin de la frappe.
        if hasattr(self, "setFetchResultsDelay"):
            self.setFetchResultsDelay(1000)

    # --- Identification du filtre ---------------------------------

    def name(self):
        # Identifiant unique interne (pas affiche a l'utilisateur)
        return "recherche_adresse_filter"

    def displayName(self):
        # Nom affiche dans les parametres de la barre de recherche
        return "Recherche d'adresse"

    def prefix(self):
        # Prefixe utilise : taper "Adresse " dans la barre de recherche
        return "Adresse"

    def priority(self):
        return getattr(QgsLocatorFilter, "Priority", QgsLocatorFilter).Highest

    def flags(self):
        # Execution synchrone dans le thread principal : plus simple et
        # plus sur pour manipuler directement la couche QGIS et le canvas.
        # Couche : thread principal (acces direct a la couche).
        # Nominatim : thread de fond pour ne pas figer l'interface.
        if search_core.get_source() == search_core.SOURCE_LAYER:
            return getattr(QgsLocatorFilter, "Flag", QgsLocatorFilter).FlagFast
        try:
            return QgsLocatorFilter.Flags()
        except AttributeError:  # Qt6
            return QgsLocatorFilter.Flag(0)

    def clone(self):
        return AdresseLocatorFilter(self.iface)

    # --- Recherche ---------------------------------------------------

    def fetchResults(self, string, context, feedback):
        for label, description, payload in search_core.search(string, feedback):
            if feedback.isCanceled():
                return
            result = QgsLocatorResult()
            result.filter = self
            result.displayString = label
            result.description = description
            result.userData = payload
            result.icon = QIcon(os.path.join(os.path.dirname(__file__), "icon.png"))
            self.resultFetched.emit(result)

    # --- Action lors du clic sur un resultat -------------------------

    def triggerResult(self, result):
        search_core.zoom_to_result(self.iface, result.userData)
