# -*- coding: utf-8 -*-
"""
Spatial Index Manager
----------------------
Extension QGIS permettant de lister les couches vectorielles sans index
spatial et de les indexer à la volée.
"""


def classFactory(iface):
    """Point d'entrée exigé par QGIS pour charger le plugin."""
    from .spatial_index_manager import SpatialIndexManager
    return SpatialIndexManager(iface)
