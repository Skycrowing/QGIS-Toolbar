# -*- coding: utf-8 -*-
import os

from qgis.PyQt.QtCore import Qt, QThread, QObject, pyqtSignal
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QProgressBar,
    QMessageBox,
    QAbstractItemView,
    QFrame,
    QApplication,
)

from qgis.core import (
    QgsProject,
    QgsWkbTypes,
    QgsVectorLayer,
    QgsVectorDataProvider,
    QgsFeatureSource,
    Qgis,
)

_CAP = getattr(Qgis, "VectorProviderCapability", QgsVectorDataProvider)
try:
    _NULL_GEOM = Qgis.GeometryType.Null
except AttributeError:  # QGIS < 3.30
    _NULL_GEOM = QgsWkbTypes.NullGeometry
_MSG = getattr(Qgis, "MessageLevel", Qgis)


def _spatial_index_absent(layer):
    """Renvoie True si la couche vectorielle ne possède pas d'index spatial.

    Gère les différences d'API entre versions de QGIS (valeur renvoyée par
    hasSpatialIndex() sous forme d'énumération ou d'entier).
    """
    try:
        state = layer.hasSpatialIndex()
    except Exception:
        return False

    not_present_values = {0}  # valeur historique / repli
    val = getattr(QgsFeatureSource, "SpatialIndexNotPresent", None)
    if val is not None:
        not_present_values.add(val)

    return state in not_present_values


def _provider_supports_index(layer):
    """Renvoie True si le fournisseur de données de la couche gère la
    création d'un index spatial (les couches mémoire en ont déjà un,
    certains formats ne le permettent pas)."""
    provider = layer.dataProvider()
    if provider is None:
        return False
    try:
        return bool(provider.capabilities() & _CAP.CreateSpatialIndex)
    except Exception:
        return False


class _IndexWorker(QObject):
    """Exécute la création des index spatiaux dans un thread séparé afin de
    garder l'interface réactive et d'afficher une véritable animation de
    progression (l'API QGIS ne fournit pas de progression fine par
    entité pour createSpatialIndex())."""

    layer_started = pyqtSignal(str, int, int)         # nom, index courant, total
    layer_finished = pyqtSignal(str, str, bool)        # id_couche, nom, succès
    all_finished = pyqtSignal()

    def __init__(self, layer_infos):
        """layer_infos : liste de tuples (id_couche, nom, source, clé_fournisseur)."""
        super().__init__()
        self.layer_infos = layer_infos
        self._abort = False

    def abort(self):
        self._abort = True

    def run(self):
        total = len(self.layer_infos)
        for i, (layer_id, name, source, provider_key) in enumerate(self.layer_infos, start=1):
            if self._abort:
                break
            self.layer_started.emit(name, i, total)
            ok = False
            try:
                # Nouvelle instance créée entièrement dans ce thread : aucun
                # objet QGIS n'est partagé avec le thread principal.
                temp_layer = QgsVectorLayer(source, name, provider_key)
                if temp_layer.isValid():
                    ok = bool(temp_layer.dataProvider().createSpatialIndex())
            except Exception:
                ok = False
            self.layer_finished.emit(layer_id, name, ok)
        self.all_finished.emit()


class SpatialIndexDialog(QDialog):
    """Fenêtre listant les couches sans index spatial et permettant de les
    indexer à la volée."""

    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("Gestion des index spatiaux")
        self.setMinimumSize(560, 480)

        plugin_dir = os.path.dirname(__file__)
        icon_path = os.path.join(plugin_dir, "icon.svg")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))

        self._build_ui()
        self._connect_signals()

        self._index_thread = None
        self._index_worker = None
        self._index_success = []
        self._index_failed = []

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("<b>Couches vectorielles sans index spatial</b>")
        layout.addWidget(title)

        subtitle = QLabel(
            "Cochez les couches à indexer puis cliquez sur "
            "« Indexer la sélection ». L'index spatial est créé à la volée, "
            "sans quitter QGIS, ce qui accélère les sélections, jointures et "
            "affichages sur les grandes couches."
        )
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("color: grey;")
        layout.addWidget(subtitle)

        self.list_widget = QListWidget()
        self.list_widget.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.list_widget.setAlternatingRowColors(True)
        layout.addWidget(self.list_widget, stretch=1)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: grey; font-style: italic;")
        layout.addWidget(self.status_label)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFrameShadow(QFrame.Shadow.Sunken)
        layout.addWidget(sep)

        btn_row1 = QHBoxLayout()
        self.select_all_btn = QPushButton("Tout sélectionner")
        self.select_none_btn = QPushButton("Tout désélectionner")
        self.refresh_btn = QPushButton("Actualiser")
        btn_row1.addWidget(self.select_all_btn)
        btn_row1.addWidget(self.select_none_btn)
        btn_row1.addStretch()
        btn_row1.addWidget(self.refresh_btn)
        layout.addLayout(btn_row1)

        btn_row2 = QHBoxLayout()
        self.index_btn = QPushButton("⚡ Indexer la sélection")
        self.index_btn.setDefault(True)
        self.close_btn = QPushButton("Fermer")
        btn_row2.addStretch()
        btn_row2.addWidget(self.index_btn)
        btn_row2.addWidget(self.close_btn)
        layout.addLayout(btn_row2)

    def _connect_signals(self):
        self.select_all_btn.clicked.connect(lambda: self._set_all_checked(True))
        self.select_none_btn.clicked.connect(lambda: self._set_all_checked(False))
        self.refresh_btn.clicked.connect(self.refresh_layers)
        self.index_btn.clicked.connect(self.index_selected_layers)
        self.close_btn.clicked.connect(self.close)
        self.list_widget.itemChanged.connect(self._update_status_from_selection)

    def closeEvent(self, event):
        thread = getattr(self, "_index_thread", None)
        try:
            is_running = thread is not None and thread.isRunning()
        except RuntimeError:
            # L'objet C/C++ du QThread a déjà été détruit (deleteLater) :
            # le traitement est bien terminé, on peut fermer sans risque.
            is_running = False
        if is_running:
            event.ignore()
            return
        super().closeEvent(event)

    # ------------------------------------------------------------- Logique
    def refresh_layers(self):
        """Recharge la liste des couches vectorielles sans index spatial."""
        self.list_widget.clear()
        self.refresh_btn.setEnabled(False)
        self.index_btn.setEnabled(False)

        all_layers = list(QgsProject.instance().mapLayers().values())

        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, max(len(all_layers), 1))
        self.progress_bar.setValue(0)
        self.status_label.setText("Analyse des couches en cours…")
        QApplication.processEvents()

        candidates = []
        for i, layer in enumerate(all_layers, start=1):
            self.progress_bar.setValue(i)
            if i % 5 == 0:
                QApplication.processEvents()

            if not isinstance(layer, QgsVectorLayer):
                continue
            if layer.geometryType() == _NULL_GEOM:
                continue
            if not _provider_supports_index(layer):
                continue
            if _spatial_index_absent(layer):
                candidates.append(layer)

        candidates.sort(key=lambda lyr: lyr.name().lower())

        for layer in candidates:
            item = QListWidgetItem(self._layer_label(layer))
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Unchecked)
            item.setData(Qt.ItemDataRole.UserRole, layer.id())
            self.list_widget.addItem(item)

        self.progress_bar.setVisible(False)
        self.refresh_btn.setEnabled(True)

        count = len(candidates)
        if count == 0:
            self.status_label.setText(
                "✓ Toutes les couches indexables du projet possèdent déjà "
                "un index spatial."
            )
        else:
            plural = "s" if count > 1 else ""
            self.status_label.setText(
                f"{count} couche{plural} sans index spatial détectée{plural} "
                f"— 0/{count} sélectionnée(s)."
            )
        self.index_btn.setEnabled(False)  # rien n'est coché tant que l'utilisateur ne l'a pas fait
        self.select_all_btn.setEnabled(count > 0)
        self.select_none_btn.setEnabled(count > 0)

    @staticmethod
    def _layer_label(layer):
        provider_name = layer.providerType()
        feature_count = layer.featureCount()
        try:
            geom = QgsWkbTypes.displayString(layer.wkbType())
        except Exception:
            geom = ""
        count_txt = f"{feature_count} entité(s)" if feature_count >= 0 else "?"
        return f"{layer.name()}   —   {provider_name} · {geom} · {count_txt}"

    def _set_all_checked(self, checked):
        state = Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked
        self.list_widget.blockSignals(True)
        for i in range(self.list_widget.count()):
            self.list_widget.item(i).setCheckState(state)
        self.list_widget.blockSignals(False)
        self._update_status_from_selection()

    def _update_status_from_selection(self, *_args):
        total = self.list_widget.count()
        if total == 0:
            return
        checked = sum(
            1
            for i in range(total)
            if self.list_widget.item(i).checkState() == Qt.CheckState.Checked
        )
        plural = "s" if total > 1 else ""
        self.status_label.setText(
            f"{checked}/{total} couche{plural} sélectionnée(s) pour l'indexation."
        )
        self.index_btn.setEnabled(checked > 0)

    def index_selected_layers(self):
        project = QgsProject.instance()
        layer_infos = []  # (id_couche, nom, source, clé_fournisseur)
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.checkState() == Qt.CheckState.Checked:
                layer_id = item.data(Qt.ItemDataRole.UserRole)
                layer = project.mapLayer(layer_id)
                if layer is not None:
                    layer_infos.append(
                        (layer_id, layer.name(), layer.source(), layer.providerType())
                    )

        if not layer_infos:
            QMessageBox.information(
                self,
                "Aucune sélection",
                "Veuillez cocher au moins une couche à indexer.",
            )
            return

        # Mode "activité" : l'API QGIS ne fournit pas de progression fine par
        # entité pour createSpatialIndex(), on affiche donc une barre en
        # va-et-vient tant que le thread travaille réellement.
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)
        self.status_label.setText("Préparation de l'indexation…")

        self.select_all_btn.setEnabled(False)
        self.select_none_btn.setEnabled(False)
        self.index_btn.setEnabled(False)
        self.refresh_btn.setEnabled(False)
        self.close_btn.setEnabled(False)

        self._index_success = []
        self._index_failed = []

        self._index_thread = QThread(self)
        self._index_worker = _IndexWorker(layer_infos)
        self._index_worker.moveToThread(self._index_thread)

        self._index_thread.started.connect(self._index_worker.run)
        self._index_worker.layer_started.connect(self._on_layer_index_started)
        self._index_worker.layer_finished.connect(self._on_layer_index_finished)
        self._index_worker.all_finished.connect(self._on_indexing_finished)
        self._index_worker.all_finished.connect(self._index_thread.quit)
        self._index_worker.all_finished.connect(self._index_worker.deleteLater)
        self._index_thread.finished.connect(self._index_thread.deleteLater)
        self._index_thread.finished.connect(self._clear_thread_refs)

        self._index_thread.start()

    def _clear_thread_refs(self):
        self._index_thread = None
        self._index_worker = None

    def _on_layer_index_started(self, name, current, total):
        self.status_label.setText(f"Indexation de « {name} »… ({current}/{total})")

    def _on_layer_index_finished(self, layer_id, name, ok):
        if ok:
            self._index_success.append(name)
            # La couche d'origine (encore ouverte dans le projet) garde en
            # cache son ancien état "pas d'index" : on force son fournisseur
            # à se reconnecter pour qu'il détecte l'index fraîchement créé
            # lors de la prochaine analyse (refresh_layers).
            layer = QgsProject.instance().mapLayer(layer_id)
            if layer is not None:
                try:
                    layer.dataProvider().reloadData()
                except Exception:
                    pass
        else:
            self._index_failed.append(name)

    def _on_indexing_finished(self):
        self.progress_bar.setRange(0, 1)
        self.progress_bar.setValue(1)
        self.progress_bar.setVisible(False)

        self.select_all_btn.setEnabled(True)
        self.select_none_btn.setEnabled(True)
        self.refresh_btn.setEnabled(True)
        self.close_btn.setEnabled(True)

        message_bar = self.iface.messageBar()
        if self._index_success:
            message_bar.pushMessage(
                "Index spatial",
                "Index créé pour : " + ", ".join(self._index_success),
                level=_MSG.Success,
                duration=6,
            )
        if self._index_failed:
            message_bar.pushMessage(
                "Index spatial",
                "Échec de l'indexation pour : " + ", ".join(self._index_failed),
                level=_MSG.Warning,
                duration=6,
            )

        self.refresh_layers()

