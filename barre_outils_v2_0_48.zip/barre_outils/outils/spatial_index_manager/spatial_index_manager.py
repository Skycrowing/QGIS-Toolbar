# -*- coding: utf-8 -*-
import os

from qgis.PyQt.QtCore import QCoreApplication, QTranslator, QSettings, QLocale
from qgis.PyQt.QtGui import QIcon
try:
    from qgis.PyQt.QtWidgets import QAction
except ImportError:  # Qt6
    from qgis.PyQt.QtGui import QAction

from .spatial_index_dialog import SpatialIndexDialog

PLUGIN_MENU_NAME = "Index spatial"


class SpatialIndexManager:
    """Classe principale enregistrant l'extension dans l'interface QGIS."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None
        self.translator = None
        self._init_locale()

    # ------------------------------------------------------------ i18n
    def _init_locale(self):
        locale = QSettings().value("locale/userLocale", QLocale().name())
        locale_path = os.path.join(
            self.plugin_dir, "i18n", f"spatial_index_manager_{locale[:2]}.qm"
        )
        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

    # --------------------------------------------------------- QGIS API
    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.svg")
        self.action = QAction(
            QIcon(icon_path),
            "Gérer les index spatiaux…",
            self.iface.mainWindow(),
        )
        self.action.setStatusTip(
            "Lister les couches sans index spatial et les indexer à la volée"
        )
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu(f"&{PLUGIN_MENU_NAME}", self.action)

    def unload(self):
        self.iface.removePluginVectorMenu(f"&{PLUGIN_MENU_NAME}", self.action)
        self.iface.removeToolBarIcon(self.action)
        if self.dialog is not None:
            self.dialog.close()
            self.dialog = None

    def run(self):
        if self.dialog is None:
            self.dialog = SpatialIndexDialog(self.iface, self.iface.mainWindow())
        self.dialog.refresh_layers()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()
