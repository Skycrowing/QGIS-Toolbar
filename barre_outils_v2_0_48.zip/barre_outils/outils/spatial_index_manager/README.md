# Spatial Index Manager — extension QGIS

Liste les couches vectorielles du projet qui n'ont **pas** d'index spatial
et permet d'en créer un à la volée, en un clic, pour une ou plusieurs
couches sélectionnées.

## Installation

**Option A — via un fichier ZIP (recommandé)**
1. Dans QGIS : `Extensions` → `Installer/Gérer les extensions` → `Installer depuis un ZIP`.
2. Sélectionnez `spatial_index_manager.zip`.
3. Cliquez sur `Installer le plugin`, puis activez-le si nécessaire.

**Option B — installation manuelle**
1. Repérez votre dossier de profil QGIS : `Paramètres` → `Profils` → `Ouvrir le dossier de profil actif`.
2. Copiez le dossier `spatial_index_manager` dans `python/plugins/`.
3. Redémarrez QGIS puis activez le plugin dans le gestionnaire d'extensions.

## Utilisation

1. Cliquez sur l'icône ⚡ (quadtree bleu) dans la barre d'outils, ou allez
   dans le menu **Vecteur → Index spatial → Gérer les index spatiaux…**
2. La fenêtre liste automatiquement toutes les couches vectorielles du
   projet **sans** index spatial (formats concernés : Shapefile, GeoPackage,
   Spatialite, etc. — les couches mémoire en possèdent déjà un et
   n'apparaissent pas).
3. Cochez les couches à indexer (toutes cochées par défaut), ou utilisez
   « Tout sélectionner » / « Tout désélectionner ».
4. Cliquez sur **⚡ Indexer la sélection**. L'index est créé immédiatement
   (à la volée, sans traitement externe), avec une barre de progression et
   un message de confirmation.
5. Utilisez **Actualiser** pour revérifier l'état des couches après
   modification du projet.

## Détails techniques

- Détection : `QgsVectorLayer.hasSpatialIndex()` combinée à la capacité du
  fournisseur `QgsVectorDataProvider.CreateSpatialIndex`.
- Création d'index : `layer.dataProvider().createSpatialIndex()`.
- Compatible QGIS ≥ 3.16 (API PyQGIS standard, aucune dépendance externe).

## Structure du plugin

```
spatial_index_manager/
├── __init__.py                 # point d'entrée (classFactory)
├── metadata.txt                # métadonnées QGIS
├── spatial_index_manager.py    # intégration interface (action, menu)
├── spatial_index_dialog.py     # fenêtre de gestion des index
├── icon.svg                    # icône moderne (quadtree + éclair)
└── README.md
```
