# Floating Info Tool — User Guide

*Version 1.6.0 · QGIS 3.22+ and QGIS 4.x · by Ian Hay*

Floating Info Tool shows feature attributes in a clean floating popup as you
hover over the map — no clicking, no attribute table, no Identify panel. It
works alongside your current map tool (pan, zoom, select) without replacing
it. The popup is **read-only** — a quick way to glance at attributes, not to
edit them.

---

## Quick start

1. Click the **Floating Info Tool** button on the toolbar (teal « i » with an
   orange « ? » bubble) to switch it on. The button stays depressed while the
   tool is active.
2. Make a vector layer the **active layer** in the Layers panel.
3. Move the cursor over a feature — a popup appears beside the cursor with
   that feature's attributes.
4. Click the toolbar button again to switch the tool off.

## Keyboard and mouse reference

| Input | When | What it does |
|---|---|---|
| **Hover** | always | Show attributes of the feature under the cursor on the **active layer** |
| **Ctrl + hover** | always | Show attributes from **every visible vector layer** under the cursor, regardless of the active layer — with a tab per layer when more than one has a hit |
| **Shift** | popup visible | **Toggle pinning** — pin the popup in place, press again to release |
| **Esc** | popup pinned | Releases the pin |
| **Mouse wheel** | popup overflows | Scrolls the popup content (instead of zooming the map) |
| **Mouse wheel** | no popup / content fits | Zooms the map as normal |

The footer at the bottom of the popup always shows the shortcuts that apply
right now — it sits outside the scrolling area, so it stays visible however
long the attribute list is.

## The two hover modes

**Active layer mode** (plain hover) queries only the layer selected in the
Layers panel. This is the precise mode: pick the layer you care about and
hover freely, even where other layers overlap it.

**Topmost layer mode** (hold Ctrl) ignores the active layer and reads
whatever is under the cursor across **all visible vector layers** (up to 5),
in layer-tree drawing order. This is the exploratory mode: cruise around a
busy map and see whatever you're pointing at. When only one layer has a hit
the popup looks the same as active layer mode; when several layers overlap
at that point, a **tab strip** appears at the top of the popup — one tab per
layer, topmost first — so you can switch between them without moving the
cursor. The popup footer reads "All layers here" so you always know which
mode produced the result.

Up to 3 overlapping features are shown per layer, separated by rules within
that layer's tab.

## Pinning and hyperlinks

A hover popup follows the cursor and disappears when you move away — so you
can't click anything inside it. **Pinning** solves that:

1. Hover until the popup shows the feature you want.
2. Press **Shift**. The footer changes to "📌 Pinned — Shift to release" and
   the popup stays put.
3. Move the cursor onto the popup and interact with it: click hyperlinks,
   select and copy values, scroll long content.
4. Press **Shift** again (or Esc) to release. If the cursor is over the
   canvas, live hover resumes immediately.

Values that look like links are automatically rendered as clickable:

- `https://…`, `http://…` and `www.…` — open in your default browser
- `file://…` URLs, `C:\…` drive paths and `\\server\share` UNC paths — open
  with the associated application (handy for linked reports, photos and
  documents)

Because Shift toggles the pin, pressing Shift for some other reason while a
popup is showing will pin it — just press Shift again and hover resumes.

## Layer tabs (Ctrl mode with several layers)

When Ctrl+hover finds a feature on more than one layer at the same point, a
row of small tabs appears above the attributes — one per layer, in the same
top-to-bottom order as the Layers panel, labelled with the layer name
(truncated with an ellipsis if it doesn't fit; hover the tab to see the full
name).

- Tabs are **click-through while hovering**, like the rest of the popup —
  pin the popup first (Shift) to switch between them.
- Clicking a tab just swaps which layer's attributes are shown; it doesn't
  re-query the map.
- Moving the cursor while unpinned always re-queries and re-opens on the
  topmost layer's tab.

The popup is confined to the QGIS window: switching to another application
puts it behind that application like any normal window content, and a pinned
popup travels with the QGIS window when you move or minimise it.

## Attribute display

The popup respects how you've configured the layer:

- **Field aliases** are used instead of raw field names
- Fields set to **Hidden** in the attribute form configuration are skipped
- Values are rendered through their **editor widget formatters**, so value
  maps show their descriptions, dates are formatted, and checkboxes show
  their state — not the raw stored codes
- Empty and NULL values display as a dimmed em dash (—)
- Very wide features are capped at 40 fields with a "more fields not shown"
  note

## Popup theme and language

Choose under **Plugins ▸ Floating Info Tool**:

- **Popup Theme** — **Auto (follow QGIS)** (the default; reads the
  application palette, so dark UI themes such as Night Mapping automatically
  get a dark popup), **Light** or **Dark**.
- **Language** — **Auto (follow QGIS)** (the default; reads the QGIS UI
  language), **English** or **Français**. This controls the popup's own
  text (footer hints, message-bar notices) — attribute field names, aliases
  and values always come from the layer itself and are shown as configured,
  regardless of this setting.

Both choices are remembered between sessions.

## Interaction with QGIS Map Tips

QGIS's native **Map Tips** are also a hover popup, so the two would fight
over the cursor. When you switch Floating Info Tool on, Map Tips are
automatically paused (a message bar notice confirms this) and restored to
their previous state when you switch the tool off.

## Troubleshooting

**No popup appears.** Check that the tool is toggled on, the active layer is
a vector layer, and the layer is visible. In active layer mode, the popup
only responds to the layer selected in the Layers panel — hold Ctrl to query
whatever is on top instead.

**Popup shows the wrong layer.** You're probably holding Ctrl (all-layers
mode) with several tabs open — check the popup footer and the tab strip at
the top of the popup; pin it (Shift) and click the tab you want.

**Links won't click.** The popup must be **pinned** first (press Shift while
it's showing). An unpinned popup vanishes as soon as the cursor leaves the
canvas.

**Wheel zooms instead of scrolling the popup.** The wheel only redirects to
the popup while the popup is visible *and* its content overflows. If
everything fits, there's nothing to scroll and the wheel zooms as usual.

**Something looks stuck.** Toggle the toolbar button off and on — this fully
resets the tool, including pinning and Map Tips state.

## Licence

GPL-2.0-or-later. Source, issues and releases:
https://github.com/ianhay/floating-info-tool

## Paramétrer le contenu de l'infobulle

Menu **Floating Info Tool ▸ Paramétrer le contenu de l'infobulle…** :

- **Par couche** : cochez les champs à afficher et glissez-déposez pour les
  réordonner. Le choix est enregistré dans la couche (donc dans le projet).
  « Par défaut » revient à tous les champs visibles.
- **Options générales** : en-tête couche/géométrie, masquage des champs vides,
  aide clavier, nombre maximal d'entités par couche et de champs par entité.
