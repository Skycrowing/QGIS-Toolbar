# -----------------------------------------------------------------------------
# Floating Info Tool - QGIS plugin
# Copyright (C) 2026 Ian Hay
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# -----------------------------------------------------------------------------

"""Floating Info Tool.

Hover over a feature on the active layer to see its attributes in a modern
floating popup. Hold Ctrl while hovering to query every visible vector layer
under the cursor, regardless of which layer is active; when more than one
layer has a hit, the popup shows a tab per layer.

Press Shift to pin the popup and Esc to unpin it. The mouse wheel scrolls the
popup when its content overflows instead of zooming the map.

Mouse movement is received through QgsMapCanvas.xyCoordinates rather than a
viewport MouseMove filter, so hover detection survives panning, zooming and
selecting.

Keyboard handling (Shift / Escape) is filtered at the QApplication level
rather than on a single widget. During pan/select/zoom interactions QGIS's
own map tools can briefly hold the keyboard focus or an internal mouse/
keyboard grab on a widget that is not the canvas viewport, the main window
or the popup; a filter installed only on those three objects would then
never see the key event. An application-wide filter always receives every
event regardless of which widget currently has focus or a grab, and the
per-event cost here is a single event-type comparison, so this does not
reintroduce the original performance problem (that came from doing GUI work
per event, not from receiving the event itself). Mouse events are still
filtered only on the canvas viewport, exactly as before.
"""

import html
import os
from functools import partial

from qgis.PyQt.QtCore import Qt, QEvent, QObject, QPoint, QTimer
from qgis.PyQt.QtGui import (
    QColor,
    QCursor,
    QIcon,
    QPainter,
    QPalette,
    QPen,
    QPixmap,
    QPolygon,
)
from qgis.PyQt.QtWidgets import QApplication

from qgis.core import (
    Qgis,
    QgsApplication,
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsMapLayer,
    QgsMessageLog,
    QgsProject,
    QgsRectangle,
    QgsSettings,
    QgsWkbTypes,
)


try:
    _MSG_WARNING = Qgis.MessageLevel.Warning
except AttributeError:  # pragma: no cover - older QGIS 3
    _MSG_WARNING = getattr(Qgis, "Warning")


_SPINDEX_NOT_PRESENT = None

try:
    _SPINDEX_NOT_PRESENT = Qgis.SpatialIndexPresence.NotPresent
except AttributeError:  # pragma: no cover - older QGIS 3
    try:
        from qgis.core import QgsFeatureSource

        _SPINDEX_NOT_PRESENT = getattr(
            QgsFeatureSource,
            "SpatialIndexNotPresent",
            None,
        )
    except ImportError:
        _SPINDEX_NOT_PRESENT = None


try:
    _NO_MOUSE_BUTTON = Qt.MouseButton.NoButton
except AttributeError:  # pragma: no cover - older Qt5 bindings
    _NO_MOUSE_BUTTON = getattr(Qt, "NoButton")


_pointer_plus_cursor_cache = None


def _pointer_plus_cursor():
    """Arrow cursor with a small green '+' badge, like a GIS 'add' tool."""
    global _pointer_plus_cursor_cache
    if _pointer_plus_cursor_cache is not None:
        return _pointer_plus_cursor_cache

    size = 24
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.transparent)

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing, True)

    # Standard arrow outline, tip at (0, 0).
    arrow = QPolygon([
        QPoint(0, 0),
        QPoint(0, 15),
        QPoint(4, 11),
        QPoint(7, 17),
        QPoint(9, 16),
        QPoint(6, 10),
        QPoint(11, 10),
    ])
    painter.setPen(QPen(QColor("#000000"), 1))
    painter.setBrush(QColor("#ffffff"))
    painter.drawPolygon(arrow)

    # Small "+" badge at the bottom-right of the arrow.
    painter.setPen(QPen(QColor("#1a7f37"), 2))
    painter.drawLine(14, 17, 14, 23)
    painter.drawLine(11, 20, 17, 20)

    painter.end()

    _pointer_plus_cursor_cache = QCursor(pixmap, 0, 0)
    return _pointer_plus_cursor_cache


def _log_debug(message):
    try:
        QgsMessageLog.logMessage(
            str(message),
            "Floating Info Tool",
            level=Qgis.MessageLevel.Info,
        )
    except (AttributeError, RuntimeError, TypeError):
        return


from .popup import FloatingInfoPopup, value_to_html
from .i18n import tr
from .config import FloatingInfoConfigDialog, layer_field_names, load_options


try:
    from qgis.PyQt.QtWidgets import QAction, QActionGroup
except ImportError:  # pragma: no cover - Qt6 fallback
    from qgis.PyQt.QtGui import QAction, QActionGroup


try:
    _VECTOR_LAYER = Qgis.LayerType.Vector
except AttributeError:  # pragma: no cover - QGIS < 3.30
    _VECTOR_LAYER = getattr(QgsMapLayer, "VectorLayer")


HOVER_DELAY_MS = 90
PIXEL_TOLERANCE = 6
MAX_FEATURES = 3
MAX_FIELDS_PER_FEATURE = 40
MAX_LAYERS = 5

SETTINGS_THEME_KEY = "floating_info_tool/theme"
SETTINGS_LANG_KEY = "floating_info_tool/language"


class FloatingInfoToolPlugin(QObject):
    """Toolbar-toggled hover identify tool with a floating attribute popup."""

    def __init__(self, iface):
        super().__init__()

        self.iface = iface
        self.canvas = iface.mapCanvas()

        self.action = None
        self.theme_actions = []
        self._theme_group = None
        self.lang_actions = []
        self._lang_group = None
        self.popup = None

        self.pinned = False
        self._active = False
        self._shift_down = False
        self._multi_mode = False
        self._maptips_were_on = False

        self._last_map_point = None

        # List of (layer, [features]) groups, one per layer with a hit,
        # in canvas (top-to-bottom) order - the source for the popup's
        # layer tabs. self._active_tab_index tracks which tab is open so
        # a pinned popup keeps showing the same layer across a language
        # switch (_retranslate rebuilds the tabs in place).
        self._last_groups = []
        self._active_tab_index = 0

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(HOVER_DELAY_MS)
        self._timer.timeout.connect(self._do_query)

        # Objects on which the event filter is installed. The QApplication
        # instance is included so Shift/Escape are received regardless of
        # which widget currently holds keyboard focus or an input grab.
        self._filter_targets = []

        self._last_signature = None

        self._visible_fields_cache = {}
        self._formatter_cache = {}
        self._xform_cache = {}
        self._index_warned = set()
        self._options = load_options()
        self.config_action = None

    # ------------------------------------------------------------------ setup

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        main_window = self.iface.mainWindow()
        lang = self._effective_lang()

        self.action = QAction(
            QIcon(icon_path),
            "Floating Info Tool",
            main_window,
        )
        self.action.setCheckable(True)
        self.action.setToolTip(tr(lang, "action_tooltip"))
        self.action.toggled.connect(self._on_toggled)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(
            "&Floating Info Tool",
            self.action,
        )

        self.config_action = QAction(
            tr(lang, "menu_config"), main_window
        )
        self.config_action.triggered.connect(self._open_config)
        self.iface.addPluginToMenu(
            "&Floating Info Tool",
            self.config_action,
        )

        self._theme_group = QActionGroup(main_window)
        self._theme_group.setExclusive(True)

        current_theme = self._theme_pref()

        for key in ("auto", "light", "dark"):
            theme_action = QAction(
                tr(lang, "menu_theme_" + key), main_window
            )
            theme_action.setCheckable(True)
            theme_action.setChecked(current_theme == key)
            theme_action.triggered.connect(
                partial(self._set_theme_pref, key)
            )

            self._theme_group.addAction(theme_action)
            self.iface.addPluginToMenu(
                "&Floating Info Tool",
                theme_action,
            )
            self.theme_actions.append(theme_action)

        self._lang_group = QActionGroup(main_window)
        self._lang_group.setExclusive(True)

        current_lang = self._lang_pref()

        for key in ("auto", "en", "fr"):
            lang_action = QAction(
                tr(lang, "menu_lang_" + key), main_window
            )
            lang_action.setCheckable(True)
            lang_action.setChecked(current_lang == key)
            lang_action.triggered.connect(
                partial(self._set_lang_pref, key)
            )

            self._lang_group.addAction(lang_action)
            self.iface.addPluginToMenu(
                "&Floating Info Tool",
                lang_action,
            )
            self.lang_actions.append(lang_action)

    def unload(self):
        self._deactivate()

        if self.action is not None:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu(
                "&Floating Info Tool",
                self.action,
            )
            self.action.deleteLater()
            self.action = None

        if self.config_action is not None:
            self.iface.removePluginMenu(
                "&Floating Info Tool",
                self.config_action,
            )
            self.config_action.deleteLater()
            self.config_action = None

        for theme_action in self.theme_actions:
            self.iface.removePluginMenu(
                "&Floating Info Tool",
                theme_action,
            )
            theme_action.deleteLater()

        self.theme_actions = []
        self._theme_group = None

        for lang_action in self.lang_actions:
            self.iface.removePluginMenu(
                "&Floating Info Tool",
                lang_action,
            )
            lang_action.deleteLater()

        self.lang_actions = []
        self._lang_group = None

        if self.popup is not None:
            self.popup.deleteLater()
            self.popup = None

    # ----------------------------------------------------------------- config

    def _open_config(self, checked=False):
        dlg = FloatingInfoConfigDialog(self.iface, self.iface.mainWindow())
        if dlg.exec():
            self._options = load_options()
            self._clear_caches()
            if self.popup is not None:
                self.popup.set_footer_visible(self._options["show_footer"])
                if self.pinned:
                    self._refresh_pinned_content()

    # ------------------------------------------------------------------ theme

    def _theme_pref(self):
        value = QgsSettings().value(
            SETTINGS_THEME_KEY,
            "auto",
        )

        if value in ("auto", "light", "dark"):
            return value

        return "auto"

    def _set_theme_pref(self, key, checked=True):
        QgsSettings().setValue(
            SETTINGS_THEME_KEY,
            key,
        )

        if self.popup is not None:
            self.popup.set_theme(self._is_dark())

    def _is_dark(self):
        preference = self._theme_pref()

        if preference == "dark":
            return True

        if preference == "light":
            return False

        try:
            app = QApplication.instance()
            window_color = app.palette().color(
                QPalette.ColorRole.Window
            )
            return window_color.lightness() < 128
        except (AttributeError, RuntimeError):
            return False

    # --------------------------------------------------------------- language

    def _lang_pref(self):
        value = QgsSettings().value(
            SETTINGS_LANG_KEY,
            "auto",
        )

        if value in ("auto", "en", "fr"):
            return value

        return "auto"

    def _set_lang_pref(self, key, checked=True):
        QgsSettings().setValue(
            SETTINGS_LANG_KEY,
            key,
        )
        self._retranslate()

    def _effective_lang(self):
        preference = self._lang_pref()

        if preference in ("en", "fr"):
            return preference

        locale = ""

        try:
            locale = QgsApplication.instance().locale() or ""
        except (AttributeError, RuntimeError):
            locale = ""

        if not locale:
            try:
                locale = QgsSettings().value(
                    "locale/userLocale", "en"
                )
            except (AttributeError, RuntimeError):
                locale = "en"

        return "fr" if str(locale).lower().startswith("fr") else "en"

    def _retranslate(self):
        lang = self._effective_lang()

        if self.action is not None:
            self.action.setToolTip(tr(lang, "action_tooltip"))

        if self.config_action is not None:
            self.config_action.setText(tr(lang, "menu_config"))

        for key, action in zip(
            ("auto", "light", "dark"), self.theme_actions
        ):
            action.setText(tr(lang, "menu_theme_" + key))

        for key, action in zip(
            ("auto", "en", "fr"), self.lang_actions
        ):
            action.setText(tr(lang, "menu_lang_" + key))

        if self.popup is not None:
            self.popup.set_language(lang)

            if self.pinned:
                self._refresh_pinned_content()
            elif self._popup_visible():
                self.popup.set_footer(
                    "multi" if self._multi_mode else "normal"
                )

    # --------------------------------------------------------------- toggling

    def _on_toggled(self, checked):
        if checked:
            self._activate()
        else:
            self._deactivate()

    def _activate(self):
        if self._active:
            return

        if self.popup is None:
            self.popup = FloatingInfoPopup(
                self.iface.mainWindow()
            )

            self.popup.tab_changed.connect(
                self._on_tab_changed
            )

        self.popup.set_theme(self._is_dark())
        self.popup.set_language(self._effective_lang())
        self._options = load_options()
        self.popup.set_footer_visible(self._options["show_footer"])
        self._suspend_map_tips()

        try:
            self.canvas.viewport().setCursor(_pointer_plus_cursor())
        except (AttributeError, RuntimeError) as exc:
            _log_debug("setCursor failed: {0}".format(exc))

        self._shift_down = False
        self._last_map_point = None
        self._clear_caches()

        self._active = True

        try:
            self.canvas.xyCoordinates.connect(
                self._on_canvas_xy
            )
        except (AttributeError, RuntimeError, TypeError) as exc:
            _log_debug(
                "xyCoordinates connect failed: {0}".format(exc)
            )

        # Keys (Shift/Escape) are filtered application-wide so they are
        # received no matter which widget currently has focus or an input
        # grab (e.g. right after a pan or a selection rectangle). Mouse
        # handling (Leave/Wheel/MouseButtonPress) stays scoped to the
        # canvas viewport only - the app-wide filter does one cheap
        # event-type comparison for those and otherwise ignores them.
        self._filter_targets = []

        for target in (
            QApplication.instance(),
            self.canvas.viewport(),
        ):
            if target is None:
                continue

            target.installEventFilter(self)
            self._filter_targets.append(target)

        try:
            self.canvas.destinationCrsChanged.connect(
                self._clear_caches
            )
        except (AttributeError, RuntimeError, TypeError) as exc:
            _log_debug(
                "destinationCrsChanged connect failed: {0}".format(exc)
            )

        try:
            QgsProject.instance().layersRemoved.connect(
                self._clear_caches
            )
        except (AttributeError, RuntimeError, TypeError) as exc:
            _log_debug(
                "layersRemoved connect failed: {0}".format(exc)
            )

    def _deactivate(self):
        if not self._active:
            return

        self._active = False

        try:
            self.canvas.viewport().unsetCursor()
        except (AttributeError, RuntimeError) as exc:
            _log_debug("unsetCursor failed: {0}".format(exc))

        try:
            self.canvas.xyCoordinates.disconnect(
                self._on_canvas_xy
            )
        except (AttributeError, RuntimeError, TypeError) as exc:
            _log_debug("xyCoordinates disconnect failed: {0}".format(exc))

        for target in self._filter_targets:
            try:
                target.removeEventFilter(self)
            except RuntimeError as exc:
                _log_debug(
                    "removeEventFilter failed: {0}".format(exc)
                )

        self._filter_targets = []

        try:
            self.canvas.destinationCrsChanged.disconnect(
                self._clear_caches
            )
        except (AttributeError, RuntimeError, TypeError) as exc:
            _log_debug("destinationCrsChanged disconnect failed: "
                       "{0}".format(exc))

        try:
            QgsProject.instance().layersRemoved.disconnect(
                self._clear_caches
            )
        except (AttributeError, RuntimeError, TypeError) as exc:
            _log_debug("layersRemoved disconnect failed: {0}".format(exc))

        self._timer.stop()
        self._last_map_point = None
        self.pinned = False
        self._shift_down = False

        if self.popup is not None:
            self.popup.set_interactive(False)
            self.popup.hide()

        self._restore_map_tips()

    # -------------------------------------------------------- canvas movement

    def _on_canvas_xy(self, map_point):
        if not self._active or self.pinned:
            return

        try:
            mouse_buttons = QApplication.mouseButtons()
        except (AttributeError, RuntimeError):
            mouse_buttons = _NO_MOUSE_BUTTON

        if mouse_buttons != _NO_MOUSE_BUTTON:
            self._timer.stop()
            self._hide_popup()
            return

        self._last_map_point = map_point
        self._timer.start()

    # ----------------------------------------------------------------- caches

    def _clear_caches(self, *args):
        self._visible_fields_cache = {}
        self._formatter_cache = {}
        self._xform_cache = {}
        self._last_signature = None

    # ---------------------------------------------------------------- maptips

    def _suspend_map_tips(self):
        self._maptips_were_on = False

        try:
            maptips_action = self.iface.actionMapTips()

            if (
                maptips_action is not None
                and maptips_action.isChecked()
            ):
                self._maptips_were_on = True
                maptips_action.trigger()

                self.iface.messageBar().pushMessage(
                    "Floating Info Tool",
                    tr(
                        self._effective_lang(),
                        "maptips_paused",
                    ),
                    duration=4,
                )
        except (AttributeError, RuntimeError):
            self._maptips_were_on = False

    def _restore_map_tips(self):
        if not self._maptips_were_on:
            return

        self._maptips_were_on = False

        try:
            maptips_action = self.iface.actionMapTips()

            if (
                maptips_action is not None
                and not maptips_action.isChecked()
            ):
                maptips_action.trigger()
        except (AttributeError, RuntimeError) as exc:
            _log_debug(
                "Could not restore Map Tips: {0}".format(exc)
            )

    # ----------------------------------------------------------- event filter

    def eventFilter(self, obj, event):
        if not self._active:
            return False

        # Cheapest possible check first: a plain integer comparison. This
        # runs for every application event when installed on QApplication,
        # but costs essentially nothing, so it does not reintroduce the
        # original app-wide-filter performance problem (which came from
        # doing widget/canvas work per event, not from receiving events).
        event_type = event.type()

        # NOTE (do not regress): an unaccepted key event is re-delivered up
        # the widget parent chain, and an app-level filter fires once per
        # delivery. Toggling must trigger only on the *physical* press edge,
        # tracked with self._shift_down, or one keystroke toggles many times.
        if event_type == QEvent.Type.KeyPress:
            key = event.key()

            if key == Qt.Key.Key_Shift:
                if (
                    not event.isAutoRepeat()
                    and not self._shift_down
                ):
                    self._shift_down = True

                    if self._popup_visible():
                        if not self.pinned:
                            self.pinned = True
                            self._timer.stop()
                            self.popup.set_interactive(True)
                            self._refresh_hint()
                        else:
                            self.pinned = False
                            self.popup.set_interactive(False)
                            self._resume_hover()

                return False

            if (
                key == Qt.Key.Key_Escape
                and self.pinned
            ):
                self.pinned = False
                self.popup.set_interactive(False)
                self._hide_popup()
                return True

            return False

        if event_type == QEvent.Type.KeyRelease:
            if (
                event.key() == Qt.Key.Key_Shift
                and not event.isAutoRepeat()
            ):
                self._shift_down = False

            return False

        if obj is self.canvas.viewport():
            if event_type == QEvent.Type.Leave:
                if not self.pinned:
                    self._timer.stop()
                    self._hide_popup()

            elif event_type == QEvent.Type.Wheel:
                if (
                    self._popup_visible()
                    and self.popup.can_scroll()
                ):
                    try:
                        delta = event.angleDelta().y()
                    except AttributeError:
                        delta = 0

                    if delta:
                        self.popup.scroll_by(delta)
                        return True

                if not self.pinned:
                    self._timer.stop()
                    self._hide_popup()

            elif event_type == QEvent.Type.MouseButtonPress:
                if not self.pinned:
                    self._timer.stop()
                    self._hide_popup()

        return False

    def _resume_hover(self):
        viewport = self.canvas.viewport()
        local_position = viewport.mapFromGlobal(
            QCursor.pos()
        )

        if not viewport.rect().contains(local_position):
            self._hide_popup()
            return

        try:
            map_point = (
                self.canvas
                .getCoordinateTransform()
                .toMapCoordinates(
                    local_position.x(),
                    local_position.y(),
                )
            )
        except (AttributeError, RuntimeError, TypeError):
            self._hide_popup()
            return

        self._last_map_point = map_point
        self._timer.start()

    def _popup_visible(self):
        return (
            self.popup is not None
            and self.popup.isVisible()
        )

    def _hide_popup(self):
        if self.popup is not None:
            self.popup.hide()

        self._last_signature = None
        self._active_tab_index = 0

    # ---------------------------------------------------------------- queries

    def _do_query(self):
        if (
            not self._active
            or self.pinned
            or self._last_map_point is None
        ):
            return

        try:
            if QApplication.mouseButtons() != _NO_MOUSE_BUTTON:
                return
        except (AttributeError, RuntimeError) as exc:
            _log_debug("mouseButtons check failed: {0}".format(exc))

        multi_mode = bool(
            QApplication.keyboardModifiers()
            & Qt.KeyboardModifier.ControlModifier
        )

        groups = self._features_at(
            self._last_map_point,
            multi_mode,
        )

        if not groups:
            self._hide_popup()
            return

        signature = (
            multi_mode,
            tuple(
                (
                    layer.id(),
                    tuple(feature.id() for feature in features),
                )
                for layer, features in groups
            ),
        )

        if (
            signature == self._last_signature
            and self._popup_visible()
        ):
            self.popup.show_at(QCursor.pos())
            return

        self._multi_mode = multi_mode
        self._last_groups = groups
        self._last_signature = signature
        # A fresh (unpinned) hover always lands back on the topmost layer's
        # tab; a preserved tab selection only matters once pinned.
        self._active_tab_index = 0

        self.popup.set_content(
            self._build_tabs(groups),
            "multi" if multi_mode else "normal",
            active_index=0,
        )
        self.popup.show_at(QCursor.pos())

    def _search_rect(self, map_point):
        tolerance = (
            self.canvas.mapUnitsPerPixel()
            * PIXEL_TOLERANCE
        )

        return QgsRectangle(
            map_point.x() - tolerance,
            map_point.y() - tolerance,
            map_point.x() + tolerance,
            map_point.y() + tolerance,
        )

    def _warn_missing_index(self, layer):
        if _SPINDEX_NOT_PRESENT is None:
            return

        layer_id = layer.id()

        if layer_id in self._index_warned:
            return

        self._index_warned.add(layer_id)

        try:
            index_state = layer.hasSpatialIndex()

            if index_state == _SPINDEX_NOT_PRESENT:
                self.iface.messageBar().pushMessage(
                    "Floating Info Tool",
                    tr(
                        self._effective_lang(),
                        "spatial_index_warning",
                        layer=layer.name(),
                    ),
                    level=_MSG_WARNING,
                    duration=6,
                )
        except (AttributeError, RuntimeError, TypeError) as exc:
            _log_debug(
                "Spatial-index check failed: {0}".format(exc)
            )

    def _layer_hits(
        self,
        layer,
        rect,
        canvas_crs,
        project,
        cap,
    ):
        layer_rect = rect

        if layer.crs() != canvas_crs:
            layer_id = layer.id()
            coordinate_transform = self._xform_cache.get(
                layer_id
            )

            if coordinate_transform is None:
                try:
                    coordinate_transform = QgsCoordinateTransform(
                        canvas_crs,
                        layer.crs(),
                        project,
                    )
                    self._xform_cache[layer_id] = (
                        coordinate_transform
                    )
                except Exception:
                    return []

            try:
                layer_rect = (
                    coordinate_transform.transformBoundingBox(
                        rect
                    )
                )
            except Exception:
                return []

        self._warn_missing_index(layer)

        request = (
            QgsFeatureRequest()
            .setFilterRect(layer_rect)
            .setLimit(cap * 4)
        )

        try:
            request.setSubsetOfAttributes(
                self._visible_fields(layer)
            )
        except (AttributeError, TypeError) as exc:
            _log_debug(
                "setSubsetOfAttributes failed: {0}".format(exc)
            )

        hits = []

        try:
            for feature in layer.getFeatures(request):
                geometry = feature.geometry()

                if (
                    geometry is None
                    or geometry.isEmpty()
                ):
                    continue

                if not geometry.intersects(layer_rect):
                    continue

                hits.append(feature)

                if len(hits) >= cap:
                    break
        except Exception:
            return []

        return hits

    def _features_at(self, map_point, multi_mode):
        """Return [(layer, [features]), ...] for the point under the
        cursor: one group per layer with a hit, in canvas (top-to-bottom)
        order. Plain hover yields at most one group (the active layer);
        Ctrl+hover yields one group per hit layer, up to MAX_LAYERS."""
        rect = self._search_rect(map_point)
        canvas_crs = (
            self.canvas
            .mapSettings()
            .destinationCrs()
        )
        project = QgsProject.instance()

        if multi_mode:
            groups = []

            for layer in self.canvas.layers():
                if (
                    layer is None
                    or layer.type() != _VECTOR_LAYER
                    or not layer.isSpatial()
                ):
                    continue

                hits = self._layer_hits(
                    layer,
                    rect,
                    canvas_crs,
                    project,
                    self._options["max_features"],
                )

                if hits:
                    groups.append((layer, hits))

                    if len(groups) >= MAX_LAYERS:
                        break

            return groups

        layer = self.iface.activeLayer()

        if (
            layer is None
            or layer.type() != _VECTOR_LAYER
            or not layer.isSpatial()
        ):
            return []

        hits = self._layer_hits(
            layer,
            rect,
            canvas_crs,
            project,
            self._options["max_features"],
        )

        if not hits:
            return []

        return [(layer, hits)]

    # --------------------------------------------------------------- rendering

    def _visible_fields(self, layer):
        layer_id = layer.id()
        cached_indices = self._visible_fields_cache.get(
            layer_id
        )

        if cached_indices is not None:
            return cached_indices

        chosen = layer_field_names(layer)
        if chosen is not None:
            fields = layer.fields()
            indices = [fields.indexOf(n) for n in chosen]
            indices = [i for i in indices if i != -1]
            self._visible_fields_cache[layer_id] = indices
            return indices

        indices = []

        for field_index in range(
            layer.fields().count()
        ):
            try:
                setup = layer.editorWidgetSetup(
                    field_index
                )

                if (
                    setup is not None
                    and setup.type() == "Hidden"
                ):
                    continue
            except Exception as exc:
                _log_debug(
                    "editorWidgetSetup failed: {0}".format(exc)
                )

            indices.append(field_index)

        self._visible_fields_cache[layer_id] = indices
        return indices

    def _format_value(
        self,
        layer,
        field_index,
        value,
    ):
        cache_key = (
            layer.id(),
            field_index,
        )

        formatter_entry = self._formatter_cache.get(
            cache_key
        )

        if formatter_entry is None:
            try:
                setup = layer.editorWidgetSetup(
                    field_index
                )
                registry = (
                    QgsApplication.fieldFormatterRegistry()
                )
                formatter = registry.fieldFormatter(
                    setup.type()
                )
                formatter_entry = (
                    formatter,
                    setup.config(),
                )
            except Exception:
                formatter_entry = (
                    None,
                    None,
                )

            self._formatter_cache[cache_key] = (
                formatter_entry
            )

        formatter, config = formatter_entry

        if formatter is not None:
            try:
                text = formatter.representValue(
                    layer,
                    field_index,
                    config,
                    None,
                    value,
                )
            except Exception:
                text = value
        else:
            text = value

        if text is None:
            return ""

        text = str(text)

        if text == "NULL":
            return ""

        return text

    def _feature_rows(self, layer, feature):
        rows = []
        shown_fields = 0

        for field_index in self._visible_fields(layer):
            if shown_fields >= self._options["max_fields"]:
                rows.append(
                    '<tr><td class="more" colspan="2">{0}</td></tr>'.format(
                        html.escape(
                            tr(self._effective_lang(), "more_fields")
                        )
                    )
                )
                break

            alias = layer.attributeDisplayName(
                field_index
            )
            raw_value = feature.attribute(
                field_index
            )
            formatted_value = self._format_value(
                layer,
                field_index,
                raw_value,
            )

            if self._options["hide_empty"] and not formatted_value.strip():
                continue

            rows.append(
                '<tr><td class="k">{0}</td>'
                '<td class="v">{1}</td></tr>'.format(
                    html.escape(alias),
                    value_to_html(formatted_value),
                )
            )
            shown_fields += 1

        return "".join(rows)

    def _build_tab_html(self, layer, features):
        """Body HTML for one layer's tab: a layer/geometry header followed
        by one attribute table per feature (separated by a rule when the
        layer contributed more than one overlapping feature)."""
        parts = []
        geometry_name = ""

        try:
            geometry_name = (
                QgsWkbTypes.geometryDisplayString(
                    layer.geometryType()
                )
            )
        except Exception as exc:
            _log_debug(
                "geometryDisplayString failed: {0}".format(
                    exc
                )
            )

        if self._options["show_header"]:
            parts.append(
                '<div class="layer">{0} '
                '<span class="geom">{1}</span></div>'.format(
                    html.escape(layer.name()),
                    html.escape(geometry_name),
                )
            )

        for feature_index, feature in enumerate(features):
            if feature_index > 0:
                parts.append("<hr/>")

            parts.append(
                "<table>{0}</table>".format(
                    self._feature_rows(
                        layer,
                        feature,
                    )
                )
            )

        return "".join(parts)

    def _build_tabs(self, groups):
        """[(layer, [features]), ...] -> [{"label", "html"}, ...] for the
        popup's tab strip, one entry per layer."""
        return [
            {
                "label": layer.name(),
                "html": self._build_tab_html(layer, features),
            }
            for layer, features in groups
        ]

    def _on_tab_changed(self, index):
        if 0 <= index < len(self._last_groups):
            self._active_tab_index = index

    def _refresh_hint(self):
        if self.popup is not None:
            self.popup.set_footer("pinned")

    def _refresh_pinned_content(self):
        if (
            not self._last_groups
            or self.popup is None
        ):
            return

        self._last_signature = None

        self.popup.set_content(
            self._build_tabs(self._last_groups),
            "pinned",
            active_index=self._active_tab_index,
        )

        if self.pinned:
            self.popup.set_footer("pinned")
