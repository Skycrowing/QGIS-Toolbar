# -----------------------------------------------------------------------------
# Floating Info Tool - QGIS plugin
# Copyright (C) 2026 Ian Hay
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# -----------------------------------------------------------------------------
"""Minimal English/French UI text table for Floating Info Tool.

Deliberately not Qt's .ts/.qm translation system: the plugin's own strings
are few and this keeps the language choice a plain, user-visible setting
(Plugins menu, "auto" follows the QGIS UI language) independent of whether
the user's QGIS install ships a translation for this plugin at all.
"""

STRINGS = {
    "en": {
        "action_tooltip": (
            "Floating Info Tool\n"
            "Hover: attributes of feature on the active layer\n"
            "Ctrl+hover: all visible layers under cursor\n"
            "Shift: pin/unpin popup\n"
            "Wheel: scroll popup when content overflows"
        ),
        "menu_config": "Popup Content Settings…",
        "menu_theme_auto": "Popup Theme: Auto (follow QGIS)",
        "menu_theme_light": "Popup Theme: Light",
        "menu_theme_dark": "Popup Theme: Dark",
        "menu_lang_auto": "Language: Auto (follow QGIS)",
        "menu_lang_en": "Language: English",
        "menu_lang_fr": "Language: Français",
        "footer_pin_hint": "to pin",
        "footer_ctrl_hint": "all layers",
        "footer_multi_hint": "All layers here",
        "footer_pin_label": "Pinned",
        "footer_release": "release",
        "more_fields": "\u2026 more fields not shown",
        "spatial_index_warning": (
            "Layer '{layer}' has no spatial index. Hover queries may "
            "therefore be slow. Consider creating a spatial index."
        ),
        "maptips_paused": (
            "Map Tips paused while the tool is active; restored when you "
            "toggle it off."
        ),
    },
    "fr": {
        "action_tooltip": (
            "Floating Info Tool\n"
            "Survol : attributs de l'entité sur la couche active\n"
            "Ctrl+survol : toutes les couches visibles sous le curseur\n"
            "Maj : épingler/détacher le popup\n"
            "Molette : fait défiler le popup si le contenu déborde"
        ),
        "menu_config": "Paramétrer le contenu de l'infobulle…",
        "menu_theme_auto": "Thème du popup : Auto (suivre QGIS)",
        "menu_theme_light": "Thème du popup : Clair",
        "menu_theme_dark": "Thème du popup : Sombre",
        "menu_lang_auto": "Langue : Auto (suivre QGIS)",
        "menu_lang_en": "Langue : Anglais",
        "menu_lang_fr": "Langue : Français",
        "footer_pin_hint": "pour épingler",
        "footer_ctrl_hint": "toutes les couches",
        "footer_multi_hint": "Toutes les couches ici",
        "footer_pin_label": "Épinglé",
        "footer_release": "détacher",
        "more_fields": "\u2026 autres champs non affichés",
        "spatial_index_warning": (
            "La couche « {layer} » n'a pas d'index spatial. Les requêtes "
            "au survol peuvent donc être lentes. Pensez à créer un index "
            "spatial."
        ),
        "maptips_paused": (
            "Les astuces cartographiques sont suspendues tant que l'outil "
            "est actif ; elles seront restaurées en le désactivant."
        ),
    },
}

DEFAULT_LANG = "en"


def tr(lang, key, **kwargs):
    """Translate `key` into `lang` ("en" or "fr"), formatting with kwargs.

    Falls back to English, then to the key itself, if a translation is
    missing - the popup and menus should never show a raw KeyError.
    """
    table = STRINGS.get(lang, STRINGS[DEFAULT_LANG])
    text = table.get(key, STRINGS[DEFAULT_LANG].get(key, key))

    if kwargs:
        try:
            return text.format(**kwargs)
        except (KeyError, IndexError, ValueError):
            return text

    return text
