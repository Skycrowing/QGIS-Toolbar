# Floating Info Tool

A QGIS plugin by Ian Hay. Hover over features to see their attributes in a
modern floating popup — no clicking, no attribute table, no identify panel.

Compatible with QGIS 3.22+ and QGIS 4.x (Qt5 and Qt6).

## Usage

1. Click the **Floating Info Tool** button on the toolbar to toggle it on.
2. Hover over a feature on the **active layer** — a popup appears next to the
   cursor with the feature's attributes.
3. Hold **Ctrl** while hovering to switch to **all-layers mode**: the popup
   shows every visible vector layer under the cursor, **regardless of which
   layer is active**. When more than one layer has a hit, a **tab strip**
   appears at the top of the popup — one tab per layer, topmost first — so
   you can switch between them. The popup footer indicates when this mode is
   on.
4. If the popup content overflows, the **mouse wheel scrolls the popup**
   (instead of zooming the map). When no popup is showing, the wheel zooms
   the map as normal.
5. Press **Shift** to **pin** the popup in place; press **Shift again** to
   release it (Esc also works). Once pinned, hyperlinks become clickable:
   - `http(s)://` and `www.` URLs open in your browser
   - `C:\...` drive paths and `\\server\share` UNC paths open with the
     associated application
6. With several layer tabs open, pin the popup first (Shift) to click
   between tabs — like links, the tab strip only responds once pinned.
7. When released with the cursor still over the canvas, live hover resumes
   immediately. Toggle the toolbar button off to disable the tool.

## Popup theme and language

Choose in *Plugins ▸ Floating Info Tool*:

- **Popup Theme** — **Auto** (default, follows the QGIS interface theme —
  dark UI themes like Night Mapping get a dark popup automatically),
  **Light** or **Dark**.
- **Language** — **Auto** (default, follows the QGIS UI language),
  **English** or **Français**. Controls the popup's own text (footer hints,
  message-bar notices); attribute field names and values always come from
  the layer itself and are unaffected.

## Behaviour notes

- Works alongside the current map tool (pan, zoom, select) — it does not
  replace it. It is implemented as an event filter, not a map tool.
- The popup lives **inside the QGIS window** — it never floats over other
  applications, and a pinned popup moves and minimises with QGIS.
- QGIS **Map Tips** are paused while the tool is active (both are hover
  popups and would fight over the cursor) and restored on toggle-off.
- Field **aliases** are shown, fields **hidden** in the attribute form are
  skipped, and values are rendered through their editor widget formatters
  (value maps, dates, checkboxes).
- Pinning is captured application-wide, so it works whichever panel has
  keyboard focus. Shift is not consumed, so Shift+click selection still
  behaves normally; note that pressing Shift for other reasons while a popup
  is showing will toggle pinning (press Shift again to restore).
- Overlapping features: up to 3 shown per query.

## Licence

GPL-2.0-or-later. See [LICENSE](LICENSE).
