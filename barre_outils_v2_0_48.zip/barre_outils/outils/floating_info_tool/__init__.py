# -----------------------------------------------------------------------------
# Floating Info Tool - QGIS plugin
# Copyright (C) 2026 Ian Hay
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# -----------------------------------------------------------------------------


def classFactory(iface):
    """Load the Floating Info Tool plugin.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .plugin import FloatingInfoToolPlugin
    return FloatingInfoToolPlugin(iface)
