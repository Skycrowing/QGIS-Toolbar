# -----------------------------------------------------------------------------
# Floating Info Tool - QGIS plugin
# Licence GNU GPL v2 ou ultérieure (voir LICENSE).
# -----------------------------------------------------------------------------
"""Paramétrage du contenu de l'infobulle.

- Par couche : champs affichés et leur ordre, enregistrés dans la couche
  (propriété personnalisée => sauvegardés avec le projet).
- Global : en-tête couche/géométrie, valeurs vides, aide clavier, nombre
  max d'entités et de champs (QgsSettings).
"""

import json

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
)
from qgis.core import QgsMapLayerProxyModel, QgsSettings
from qgis.gui import QgsMapLayerComboBox

LAYER_FIELDS_PROP = "floating_info_tool/fields"

OPT_PREFIX = "floating_info_tool/opt_"
DEFAULT_OPTIONS = {
    "show_header": True,
    "hide_empty": False,
    "show_footer": True,
    "max_features": 3,
    "max_fields": 40,
}

try:
    _VECTOR_FILTER = QgsMapLayerProxyModel.Filter.VectorLayer
except AttributeError:  # pragma: no cover - QGIS < 3.34
    _VECTOR_FILTER = QgsMapLayerProxyModel.VectorLayer

_CHECKED = Qt.CheckState.Checked
_UNCHECKED = Qt.CheckState.Unchecked


# ----------------------------------------------------------------- options

def load_options():
    s = QgsSettings()
    opts = {}
    for key, default in DEFAULT_OPTIONS.items():
        value = s.value(OPT_PREFIX + key, default)
        if isinstance(default, bool):
            value = value if isinstance(value, bool) else str(value).lower() in ("true", "1")
        else:
            try:
                value = int(value)
            except (TypeError, ValueError):
                value = default
        opts[key] = value
    return opts


def save_options(opts):
    s = QgsSettings()
    for key, value in opts.items():
        s.setValue(OPT_PREFIX + key, value)


# ---------------------------------------------------------- champs/couche

def layer_field_names(layer):
    """Liste ordonnée des champs choisis pour la couche, ou None si la
    couche n'est pas paramétrée (tous les champs visibles)."""
    raw = layer.customProperty(LAYER_FIELDS_PROP, None)
    if not raw:
        return None
    try:
        names = json.loads(raw)
    except (TypeError, ValueError):
        return None
    return [str(n) for n in names] if isinstance(names, list) else None


def set_layer_field_names(layer, names):
    if names is None:
        layer.removeCustomProperty(LAYER_FIELDS_PROP)
    else:
        layer.setCustomProperty(LAYER_FIELDS_PROP, json.dumps(list(names)))


# ------------------------------------------------------------------ dialog

class FloatingInfoConfigDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("Floating Info Tool – Contenu de l'infobulle")
        self.resize(420, 560)
        self._pending = {}  # layer id -> liste de noms ou None

        root = QVBoxLayout(self)

        # --- Champs par couche
        box = QGroupBox("Champs affichés (par couche)")
        v = QVBoxLayout(box)

        self.layer_cb = QgsMapLayerComboBox()
        self.layer_cb.setFilters(_VECTOR_FILTER)
        active = iface.activeLayer()
        if active is not None:
            self.layer_cb.setLayer(active)
        v.addWidget(self.layer_cb)

        hint = QLabel("Cochez les champs à afficher ; glissez-déposez pour changer l'ordre.")
        hint.setWordWrap(True)
        v.addWidget(hint)

        self.fields_list = QListWidget()
        self.fields_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.fields_list.setDefaultDropAction(Qt.DropAction.MoveAction)
        v.addWidget(self.fields_list, 1)

        row = QHBoxLayout()
        all_btn = QPushButton("Tout cocher")
        none_btn = QPushButton("Tout décocher")
        reset_btn = QPushButton("Par défaut")
        reset_btn.setToolTip("Revenir à tous les champs visibles, dans l'ordre de la couche")
        for b in (all_btn, none_btn, reset_btn):
            row.addWidget(b)
        v.addLayout(row)
        root.addWidget(box, 1)

        # --- Options générales
        opts = load_options()
        gbox = QGroupBox("Options générales")
        form = QFormLayout(gbox)
        self.header_chk = QCheckBox("Afficher le nom de la couche et le type de géométrie")
        self.header_chk.setChecked(opts["show_header"])
        self.empty_chk = QCheckBox("Masquer les champs sans valeur")
        self.empty_chk.setChecked(opts["hide_empty"])
        self.footer_chk = QCheckBox("Afficher l'aide clavier (Maj / Ctrl)")
        self.footer_chk.setChecked(opts["show_footer"])
        self.max_feat_sp = QSpinBox()
        self.max_feat_sp.setRange(1, 20)
        self.max_feat_sp.setValue(opts["max_features"])
        self.max_fields_sp = QSpinBox()
        self.max_fields_sp.setRange(1, 200)
        self.max_fields_sp.setValue(opts["max_fields"])
        form.addRow(self.header_chk)
        form.addRow(self.empty_chk)
        form.addRow(self.footer_chk)
        form.addRow("Entités max. par couche", self.max_feat_sp)
        form.addRow("Champs max. par entité", self.max_fields_sp)
        root.addWidget(gbox)

        bb = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        root.addWidget(bb)

        self._current_layer = None
        self.layer_cb.layerChanged.connect(self._on_layer_changed)
        all_btn.clicked.connect(lambda: self._check_all(True))
        none_btn.clicked.connect(lambda: self._check_all(False))
        reset_btn.clicked.connect(self._reset_layer)
        self._on_layer_changed(self.layer_cb.currentLayer())

    # ------------------------------------------------------------------
    def _stash_current(self):
        layer = self._current_layer
        if layer is None:
            return
        order, names = [], []
        for i in range(self.fields_list.count()):
            it = self.fields_list.item(i)
            name = it.data(Qt.ItemDataRole.UserRole)
            order.append(name)
            if it.checkState() == _CHECKED:
                names.append(name)
        # Identique au comportement par défaut => on ne stocke rien
        if order == [f.name() for f in layer.fields()] and self._is_default_selection(layer, names):
            self._pending[layer.id()] = None
        else:
            self._pending[layer.id()] = names

    def _is_default_selection(self, layer, names):
        return names == [f.name() for i, f in enumerate(layer.fields())
                         if not _is_hidden(layer, i)]

    def _on_layer_changed(self, layer):
        self._stash_current()
        self._current_layer = layer
        self.fields_list.clear()
        if layer is None:
            return
        if layer.id() in self._pending:
            chosen = self._pending[layer.id()]
        else:
            chosen = layer_field_names(layer)
        self._fill(layer, chosen)

    def _fill(self, layer, chosen):
        self.fields_list.clear()
        fields = layer.fields()
        all_names = [f.name() for f in fields]
        if chosen is None:
            order = all_names
            checked = {n for i, n in enumerate(all_names) if not _is_hidden(layer, i)}
        else:
            order = [n for n in chosen if n in all_names] + [n for n in all_names if n not in chosen]
            checked = set(chosen)
        for name in order:
            idx = fields.indexOf(name)
            alias = layer.attributeDisplayName(idx)
            label = name if alias == name else f"{alias}  ({name})"
            it = QListWidgetItem(label)
            it.setData(Qt.ItemDataRole.UserRole, name)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsDragEnabled)
            it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsDropEnabled)
            it.setCheckState(_CHECKED if name in checked else _UNCHECKED)
            self.fields_list.addItem(it)

    def _check_all(self, state):
        for i in range(self.fields_list.count()):
            self.fields_list.item(i).setCheckState(_CHECKED if state else _UNCHECKED)

    def _reset_layer(self):
        if self._current_layer is not None:
            self._fill(self._current_layer, None)

    # ------------------------------------------------------------------
    def accept(self):
        self._stash_current()
        project_layers = {}
        try:
            from qgis.core import QgsProject
            project_layers = QgsProject.instance().mapLayers()
        except Exception:
            pass
        for layer_id, names in self._pending.items():
            layer = project_layers.get(layer_id)
            if layer is not None:
                set_layer_field_names(layer, names)
        save_options({
            "show_header": self.header_chk.isChecked(),
            "hide_empty": self.empty_chk.isChecked(),
            "show_footer": self.footer_chk.isChecked(),
            "max_features": self.max_feat_sp.value(),
            "max_fields": self.max_fields_sp.value(),
        })
        if self._pending:
            try:
                from qgis.core import QgsProject
                QgsProject.instance().setDirty(True)
            except Exception:
                pass
        super().accept()


def _is_hidden(layer, idx):
    try:
        setup = layer.editorWidgetSetup(idx)
        return setup is not None and setup.type() == "Hidden"
    except Exception:
        return False
