# -----------------------------------------------------------------------------
# Floating Info Tool - QGIS plugin
# Copyright (C) 2026 Ian Hay
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# -----------------------------------------------------------------------------
"""Floating popup widget used to display feature attributes near the cursor.

Works with both Qt5 (QGIS 3.x) and Qt6 (QGIS 4.x). All Qt imports go through
qgis.PyQt and all enums use fully scoped names so the same code runs on both.
"""

import html
import re
from functools import partial

from qgis.PyQt.QtCore import Qt, QPoint, QUrl, QSize, pyqtSignal
from qgis.PyQt.QtGui import QColor, QDesktopServices, QFontMetrics
from qgis.PyQt.QtWidgets import (
    QButtonGroup,
    QFrame,
    QGraphicsDropShadowEffect,
    QHBoxLayout,
    QLabel,
    QLayout,
    QPushButton,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from .i18n import tr

# Anything that looks like a web URL, a file URL, a Windows drive path or a
# UNC share is treated as a hyperlink.
_URL_RE = re.compile(
    r"^(https?://\S+|www\.\S+|file://\S+|[A-Za-z]:[\\/]\S.*|\\\\\S.*)$",
    re.IGNORECASE,
)

_MAX_WIDTH = 380       # popup max width in px
_TEXT_WIDTH = 348      # document text width (max width minus padding)
_MAX_HEIGHT = 480      # popup max height before it scrolls
_CURSOR_OFFSET = QPoint(16, 20)

_TAB_MIN_WIDTH = 50    # minimum elided width of one layer tab, in px
_TAB_MAX_WIDTH = 120   # maximum elided width of one layer tab, in px
_TAB_SPACING = 4

_THEMES = {
    "light": {
        "frame_bg": "#ffffff",
        "frame_border": "#e2e5ea",
        "text": "#1f2937",
        "key": "#6b7280",
        "value": "#111827",
        "link": "#2563eb",
        "layer": "#0f172a",
        "geom": "#9ca3af",
        "muted": "#9ca3af",
        "pin": "#2563eb",
        "rule": "#eef0f3",
        "empty": "#c3c8cf",
        "shadow": QColor(15, 23, 42, 70),
        "scroll_handle": "#cbd5e1",
        "pill_bg": "#f3f4f6",
        "pill_border": "#d1d5db",
        "pill_text": "#374151",
    },
    "dark": {
        "frame_bg": "#111827",
        "frame_border": "#374151",
        "text": "#e5e7eb",
        "key": "#9ca3af",
        "value": "#f3f4f6",
        "link": "#60a5fa",
        "layer": "#f9fafb",
        "geom": "#6b7280",
        "muted": "#6b7280",
        "pin": "#60a5fa",
        "rule": "#374151",
        "empty": "#4b5563",
        "shadow": QColor(0, 0, 0, 130),
        "scroll_handle": "#4b5563",
        "pill_bg": "#1f2937",
        "pill_border": "#4b5563",
        "pill_text": "#d1d5db",
    },
}


def _widget_qss(t):
    return """
QFrame#fitFrame {{
    background-color: {frame_bg};
    border: 1px solid {frame_border};
    border-radius: 10px;
}}
QTextBrowser {{
    background: transparent;
    border: none;
    font-family: "Segoe UI", "Arial", sans-serif;
    font-size: 9pt;
    color: {text};
}}
QScrollBar:vertical {{
    background: transparent;
    width: 8px;
    margin: 2px;
}}
QScrollBar::handle:vertical {{
    background: {scroll_handle};
    border-radius: 4px;
    min-height: 24px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}
QLabel#pill {{
    border: 1px solid {pill_border};
    border-radius: 4px;
    background: {pill_bg};
    color: {pill_text};
    padding: 0px 5px 1px 5px;
    font-family: "Segoe UI", "Arial", sans-serif;
    font-size: 7.5pt;
    font-weight: 600;
}}
QPushButton#tabbtn {{
    border: none;
    border-bottom: 2px solid transparent;
    border-radius: 0px;
    background: transparent;
    color: {key};
    padding: 2px 6px 4px 6px;
    font-family: "Segoe UI", "Arial", sans-serif;
    font-size: 8pt;
    font-weight: 600;
    text-align: left;
}}
QPushButton#tabbtn:hover {{
    color: {value};
}}
QPushButton#tabbtn:checked {{
    color: {layer};
    border-bottom: 2px solid {pin};
}}
QWidget#tabBar {{
    border-bottom: 1px solid {rule};
}}
QLabel#hinttext {{
    color: {muted};
    font-family: "Segoe UI", "Arial", sans-serif;
    font-size: 7.5pt;
}}
QLabel#pintext {{
    color: {pin};
    font-family: "Segoe UI", "Arial", sans-serif;
    font-size: 7.5pt;
}}
""".format(**t)


def _doc_css(t):
    return """
    body {{ font-family: 'Segoe UI', Arial, sans-serif; color: {text}; }}
    table {{ border-collapse: collapse; }}
    td {{ padding: 2px 6px 2px 0; vertical-align: top; overflow-wrap: break-word; word-wrap: break-word; }}
    td.k {{ color: {key}; padding-right: 14px; white-space: nowrap; }}
    td.v {{ color: {value}; }}
    a {{ color: {link}; text-decoration: none; }}
    .layer {{ color: {layer}; font-weight: 600; font-size: 10pt; }}
    .geom {{ color: {geom}; font-size: 8pt; }}
    .more {{ color: {muted}; font-style: italic; }}
    .hint {{ color: {muted}; font-size: 7.5pt; }}
    .pin  {{ color: {pin}; font-size: 7.5pt; }}
    .empty {{ color: {empty}; }}
    hr {{ border: none; border-top: 1px solid {rule}; }}
""".format(**t)


def value_to_html(text):
    """Return HTML for one attribute value, turning URL-like text into a link."""
    if text is None:
        text = ""
    text = str(text)
    stripped = text.strip()
    if stripped and _URL_RE.match(stripped):
        if stripped.lower().startswith("www."):
            href = "http://" + stripped
        elif re.match(r"^[A-Za-z]:[\\/]", stripped) or stripped.startswith("\\\\"):
            href = QUrl.fromLocalFile(stripped).toString()
        else:
            href = stripped
        return '<a href="{0}">{1}</a>'.format(
            html.escape(href, quote=True), html.escape(stripped)
        )
    if stripped == "":
        return '<span class="empty">&#8212;</span>'
    return html.escape(text)


class FloatingInfoPopup(QWidget):
    """Floating attribute card, implemented as a plain child widget of the
    QGIS main window - deliberately NOT a top-level window. A top-level
    window with WindowStaysOnTopHint floats over every application on the
    OS; a child widget can never leave QGIS, moves and minimises with it,
    and simply disappears behind other applications on Alt+Tab.

    While unpinned it is transparent to mouse events (pure display); when
    pinned it becomes interactive so hyperlinks can be clicked, content
    scrolled, and layer tabs switched.
    """

    tab_changed = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._lang = "en"
        self._tabs = []          # list of {"label": str, "html": str}
        self._active_tab = 0
        self._tab_buttons = []
        # Click-through by default; set_interactive(True) when pinned.
        self.setAttribute(
            Qt.WidgetAttribute.WA_TransparentForMouseEvents, True
        )

        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)  # room for the drop shadow
        # The popup must always be exactly the size of its content: without
        # this, a child widget keeps its previous (larger) size and the
        # layout stretches the footer to fill the leftover space.
        outer.setSizeConstraint(QLayout.SizeConstraint.SetFixedSize)

        self._frame = QFrame(self)
        self._frame.setObjectName("fitFrame")
        inner = QVBoxLayout(self._frame)
        inner.setContentsMargins(14, 10, 14, 10)

        # Layer tab strip - one pill-style tab per layer, shown only when
        # a hover/pin result spans more than one layer (Ctrl mode).
        self._tab_bar = QWidget(self._frame)
        self._tab_bar.setObjectName("tabBar")
        self._tab_bar_layout = QHBoxLayout(self._tab_bar)
        self._tab_bar_layout.setContentsMargins(0, 0, 0, 6)
        self._tab_bar_layout.setSpacing(_TAB_SPACING)
        self._tab_button_group = QButtonGroup(self._tab_bar)
        self._tab_button_group.setExclusive(True)
        self._tab_bar.hide()
        inner.addWidget(self._tab_bar)

        self._browser = QTextBrowser(self._frame)
        self._browser.setOpenLinks(False)
        self._browser.setOpenExternalLinks(False)
        self._browser.anchorClicked.connect(self._on_anchor_clicked)
        self._browser.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self._browser.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self._browser.setFrameShape(QFrame.Shape.NoFrame)
        inner.addWidget(self._browser)

        # Fixed footer (never scrolls): hint text with key "pills".
        self._footer = QWidget(self._frame)
        self._footer_layout = QHBoxLayout(self._footer)
        self._footer_layout.setContentsMargins(0, 6, 0, 0)
        self._footer_layout.setSpacing(5)
        inner.addWidget(self._footer)

        outer.addWidget(self._frame)

        self._shadow = QGraphicsDropShadowEffect(self)
        self._shadow.setBlurRadius(22)
        self._shadow.setOffset(0, 4)
        self._frame.setGraphicsEffect(self._shadow)

        self.set_theme(dark=False)
        self.hide()

    # ------------------------------------------------------------ interaction
    def set_interactive(self, interactive):
        """Click-through while hovering; interactive (links, scroll, tabs)
        while pinned."""
        self.setAttribute(
            Qt.WidgetAttribute.WA_TransparentForMouseEvents, not interactive
        )

    # ------------------------------------------------------------------ theme
    def set_theme(self, dark):
        theme = _THEMES["dark" if dark else "light"]
        self.setStyleSheet(_widget_qss(theme))
        self._browser.document().setDefaultStyleSheet(_doc_css(theme))
        self._shadow.setColor(theme["shadow"])

    # --------------------------------------------------------------- language
    def set_language(self, lang):
        """Set the UI language ('en' or 'fr') used by the footer text. Does
        not by itself rebuild anything already on screen - the caller
        refreshes content/footer afterwards if something is showing."""
        self._lang = lang if lang in ("en", "fr") else "en"

    # ----------------------------------------------------------------- footer
    def set_footer_visible(self, visible):
        """Affiche ou masque l'aide clavier en bas de l'infobulle."""
        self._footer.setVisible(bool(visible))
        self.adjustSize()

    def set_footer(self, mode):
        """Rebuild the fixed footer.

        mode: 'normal' | 'multi' | 'pinned'.
        """
        layout = self._footer_layout
        while layout.count():
            item = layout.takeAt(0)
            child = item.widget()
            if child is not None:
                child.deleteLater()

        def pill(text):
            label = QLabel(text, self._footer)
            label.setObjectName("pill")
            return label

        def hint(text, name="hinttext"):
            label = QLabel(text, self._footer)
            label.setObjectName(name)
            return label

        lang = self._lang

        if mode == "pinned":
            layout.addWidget(hint("📌", "pintext"))
            layout.addWidget(hint(tr(lang, "footer_pin_label"), "pintext"))
            layout.addWidget(hint("•", "pintext"))
            layout.addWidget(pill("Shift"))
            layout.addWidget(hint(tr(lang, "footer_release"), "pintext"))
        elif mode == "multi":
            layout.addWidget(
                hint(tr(lang, "footer_multi_hint") + " •")
            )
            layout.addWidget(pill("Shift"))
            layout.addWidget(hint(tr(lang, "footer_pin_hint")))
        else:
            layout.addWidget(pill("Shift"))
            layout.addWidget(
                hint(tr(lang, "footer_pin_hint") + " •")
            )
            layout.addWidget(pill("Ctrl"))
            layout.addWidget(hint(tr(lang, "footer_ctrl_hint")))
        layout.addStretch(1)

    # -------------------------------------------------------------- tab strip
    def _rebuild_tab_bar(self):
        """Rebuild the layer-tab strip from self._tabs / self._active_tab."""
        layout = self._tab_bar_layout
        while layout.count():
            item = layout.takeAt(0)
            child = item.widget()
            if child is not None:
                self._tab_button_group.removeButton(child)
                child.deleteLater()
        self._tab_buttons = []

        if len(self._tabs) <= 1:
            self._tab_bar.hide()
            return

        per_tab_width = max(
            _TAB_MIN_WIDTH,
            min(
                _TAB_MAX_WIDTH,
                (_TEXT_WIDTH // len(self._tabs)) - _TAB_SPACING,
            ),
        )

        for index, tab in enumerate(self._tabs):
            button = QPushButton(self._tab_bar)
            button.setObjectName("tabbtn")
            button.setCheckable(True)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            metrics = QFontMetrics(button.font())
            elided = metrics.elidedText(
                tab.get("label", ""),
                Qt.TextElideMode.ElideRight,
                per_tab_width,
            )
            button.setText(elided)
            if elided != tab.get("label", ""):
                button.setToolTip(tab.get("label", ""))
            button.setChecked(index == self._active_tab)
            button.clicked.connect(partial(self._on_tab_clicked, index))
            self._tab_button_group.addButton(button)
            layout.addWidget(button)
            self._tab_buttons.append(button)

        layout.addStretch(1)
        self._tab_bar.show()

    def _on_tab_clicked(self, index):
        if index == self._active_tab or index >= len(self._tabs):
            return
        self._active_tab = index
        for button_index, button in enumerate(self._tab_buttons):
            button.setChecked(button_index == index)
        self.set_html(self._wrap_body(self._tabs[index]["html"]))
        self.tab_changed.emit(index)

    def _wrap_body(self, body_html):
        return "<html><body>{0}</body></html>".format(body_html)

    def set_content(self, tabs, mode, active_index=0):
        """Set the tabbed attribute content and the footer state together.

        tabs: list of {"label": str, "html": str}, one per layer (a single
        entry is the common case and shows no tab strip).
        """
        self._tabs = list(tabs) if tabs else []
        if self._tabs:
            self._active_tab = max(
                0, min(active_index, len(self._tabs) - 1)
            )
        else:
            self._active_tab = 0

        self._rebuild_tab_bar()

        if self._tabs:
            self.set_html(self._wrap_body(self._tabs[self._active_tab]["html"]))
        else:
            self.set_html(self._wrap_body(""))

        self.set_footer(mode)
        self.adjustSize()

    # ------------------------------------------------------------------ links
    def _on_anchor_clicked(self, url):
        if url and url.isValid():
            QDesktopServices.openUrl(url)

    # -------------------------------------------------------------- scrolling
    def can_scroll(self):
        scrollbar = self._browser.verticalScrollBar()
        return scrollbar is not None and scrollbar.maximum() > 0

    def scroll_by(self, wheel_delta_y):
        """Scroll the content by a wheel delta (typically +/-120 per notch)."""
        scrollbar = self._browser.verticalScrollBar()
        if scrollbar is not None:
            scrollbar.setValue(scrollbar.value() - int(wheel_delta_y / 2))

    # ---------------------------------------------------------------- content
    def set_html(self, body_html):
        self._browser.setHtml(body_html)
        # Force the QSS (incl. font-family/size) to be applied before we
        # measure anything below - otherwise the very first call measures
        # with the default application font instead of the styled one,
        # producing a too-narrow popup that only fixes itself afterwards.
        self._browser.ensurePolished()
        # Measure on a detached clone: the browser's own document is
        # re-laid out by QTextEdit at its current viewport width (tiny on
        # the very first call), which made the first popup far too narrow
        # and broke values letter by letter.
        doc = self._browser.document().clone()
        doc.setDefaultFont(self._browser.font())

        # Natural width of the content (capped), like an auto-sized table.
        doc.setTextWidth(_TEXT_WIDTH)
        content_width = min(max(int(doc.idealWidth()) + 4, 60), _TEXT_WIDTH)

        doc.setTextWidth(content_width)
        height = int(doc.documentLayout().documentSize().height()) + 6
        w = content_width + 2
        if height > _MAX_HEIGHT:
            # Leave room for the vertical scrollbar.
            scrollbar = self._browser.verticalScrollBar()
            w += scrollbar.sizeHint().width() if scrollbar is not None else 10
        h = min(height, _MAX_HEIGHT)
        self._browser.setFixedSize(QSize(max(w, 60), max(h, 20)))
        self.adjustSize()

    # --------------------------------------------------------------- position
    def show_at(self, global_pos):
        """Show near the cursor, kept inside the QGIS main window."""
        parent = self.parentWidget()
        if parent is None:
            return
        anchor = parent.mapFromGlobal(global_pos)
        pos = anchor + _CURSOR_OFFSET
        area = parent.rect()
        w = self.sizeHint().width()
        h = self.sizeHint().height()
        if pos.x() + w > area.right():
            pos.setX(anchor.x() - w - 8)
        if pos.y() + h > area.bottom():
            pos.setY(anchor.y() - h - 8)
        if pos.x() < area.left():
            pos.setX(area.left())
        if pos.y() < area.top():
            pos.setY(area.top())
        self.move(pos)
        if not self.isVisible():
            self.show()
        self.raise_()
