# -*- coding: utf-8 -*-
from contextlib import contextmanager

from qgis.PyQt.QtCore import Qt, QVariant
try:
    from qgis.PyQt.QtCore import QMetaType
except ImportError:  # pragma: no cover
    QMetaType = None
from qgis.PyQt.QtGui import QCursor
from qgis.PyQt.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QFormLayout,
    QLabel,
    QComboBox,
    QListWidget,
    QListWidgetItem,
    QSpinBox,
    QPushButton,
    QMessageBox,
    QCheckBox,
    QDialogButtonBox,
    QProgressDialog,
    QApplication,
)

from qgis.core import (
    QgsProject,
    QgsVectorLayer,
    QgsVectorDataProvider,
    QgsField,
    NULL,
    Qgis,
)

# Identifiants Qt des types numériques (identiques en QVariant et QMetaType) :
# Int=2, UInt=3, LongLong=4, ULongLong=5, Double=6
NUMERIC_TYPES = (2, 3, 4, 5, 6)
DOUBLE_TYPE = 6

_CAP = getattr(Qgis, "VectorProviderCapability", QgsVectorDataProvider)


def _type_id(field):
    t = field.type()
    return int(getattr(t, "value", t))


if QMetaType is not None and Qgis.QGIS_VERSION_INT >= 33800:
    _DOUBLE_FIELD = QMetaType.Type.Double
else:
    _DOUBLE_FIELD = QVariant.Double


class ArrondirChampsDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("Arrondir des champs numériques")
        self.setMinimumWidth(420)
        self._last_processed_fields = []
        self._build_ui()
        self._populate_layers()

        # Rafraîchir la liste des couches quand on (dé)coche une couche dans
        # la légende QGIS, si le filtre "couches actives" est actif.
        QgsProject.instance().layerTreeRoot().visibilityChanged.connect(
            self._on_layer_visibility_changed
        )

    def _on_layer_visibility_changed(self, node):
        if self.check_only_active_layers.isChecked():
            self._populate_layers()

    def closeEvent(self, event):
        try:
            QgsProject.instance().layerTreeRoot().visibilityChanged.disconnect(
                self._on_layer_visibility_changed
            )
        except (TypeError, RuntimeError):
            pass
        super().closeEvent(event)

    # ------------------------------------------------------------------
    # Construction de l'interface
    # ------------------------------------------------------------------
    def _build_ui(self):
        main_layout = QVBoxLayout(self)

        form = QFormLayout()

        self.combo_layers = QComboBox()
        self.combo_layers.currentIndexChanged.connect(self._populate_fields)
        form.addRow("Couche :", self.combo_layers)

        main_layout.addLayout(form)

        self.check_only_active_layers = QCheckBox(
            "N'afficher que les couches actives (cochées dans la légende)"
        )
        self.check_only_active_layers.setChecked(True)
        self.check_only_active_layers.toggled.connect(self._populate_layers)
        main_layout.addWidget(self.check_only_active_layers)

        main_layout.addWidget(QLabel("Champs numériques à arrondir :"))

        self.list_fields = QListWidget()
        self.list_fields.setSelectionMode(QListWidget.SelectionMode.NoSelection)
        main_layout.addWidget(self.list_fields)

        select_layout = QHBoxLayout()
        self.btn_select_all = QPushButton("Tout cocher")
        self.btn_select_all.clicked.connect(lambda: self._set_all_checked(True))
        self.btn_select_none = QPushButton("Tout décocher")
        self.btn_select_none.clicked.connect(lambda: self._set_all_checked(False))
        select_layout.addWidget(self.btn_select_all)
        select_layout.addWidget(self.btn_select_none)
        select_layout.addStretch()
        main_layout.addLayout(select_layout)

        decimals_layout = QHBoxLayout()
        decimals_layout.addWidget(QLabel("Nombre de décimales :"))
        self.spin_decimals = QSpinBox()
        self.spin_decimals.setRange(0, 15)
        self.spin_decimals.setValue(2)  # valeur par défaut demandée
        decimals_layout.addWidget(self.spin_decimals)
        decimals_layout.addStretch()
        main_layout.addLayout(decimals_layout)

        self.check_only_selected_features = QCheckBox(
            "N'arrondir que les entités sélectionnées (si une sélection existe)"
        )
        main_layout.addWidget(self.check_only_selected_features)

        self.status_label = QLabel("")
        self.status_label.setStyleSheet("color: #2563AA; font-style: italic; font-weight: bold;")
        main_layout.addWidget(self.status_label)

        # Boutons Appliquer / Voir le résultat / Fermer
        button_box = QDialogButtonBox()
        self.btn_apply = button_box.addButton(
            "Appliquer", QDialogButtonBox.ButtonRole.ActionRole
        )
        self.btn_apply.setToolTip(
            "Calcule les arrondis et les enregistre dans la couche."
        )
        self.btn_show_result = button_box.addButton(
            "Voir le résultat", QDialogButtonBox.ButtonRole.ActionRole
        )
        self.btn_show_result.setToolTip(
            "Ouvre la table attributaire de la couche, triée sur le dernier "
            "champ traité, pour vérifier le résultat de l'arrondi."
        )
        self.btn_close = button_box.addButton(QDialogButtonBox.StandardButton.Close)
        self.btn_apply.clicked.connect(self.apply_rounding)
        self.btn_show_result.clicked.connect(self.show_result)
        self.btn_close.clicked.connect(self.close)
        main_layout.addWidget(button_box)

    # ------------------------------------------------------------------
    # Peuplement des couches / champs
    # ------------------------------------------------------------------
    def _populate_layers(self):
        previously_selected = self.combo_layers.currentData()  # QgsVectorLayer ou None

        self.combo_layers.clear()
        root = QgsProject.instance().layerTreeRoot()
        only_active = self.check_only_active_layers.isChecked()

        all_vector_layers = [
            l
            for l in QgsProject.instance().mapLayers().values()
            if isinstance(l, QgsVectorLayer)
        ]

        if only_active:
            layers = []
            for l in all_vector_layers:
                node = root.findLayer(l.id())
                # Une couche sans nœud dans la légende (rare) est considérée active,
                # pour ne pas la masquer sans raison.
                if node is None or node.isVisible():
                    layers.append(l)
        else:
            layers = all_vector_layers

        if not layers:
            if only_active and all_vector_layers:
                self.combo_layers.addItem(
                    "Aucune couche active (décochez le filtre pour tout voir)", None
                )
            else:
                self.combo_layers.addItem("Aucune couche vecteur dans le projet", None)
            self.list_fields.clear()
            return

        # On essaie de conserver la couche actuellement choisie dans la liste
        # (utile quand le rafraîchissement est déclenché automatiquement par
        # un changement de visibilité dans la légende, pour ne pas perturber
        # l'utilisateur en cours de travail). À défaut, on retombe sur la
        # couche active de QGIS, puis sur la première de la liste.
        target_layer = None
        if previously_selected is not None and any(
            l.id() == previously_selected.id() for l in layers
        ):
            target_layer = previously_selected
        else:
            active = self.iface.activeLayer()
            if active is not None and any(l.id() == active.id() for l in layers):
                target_layer = active

        select_index = 0
        for i, layer in enumerate(layers):
            self.combo_layers.addItem(layer.name(), layer)
            if target_layer is not None and layer.id() == target_layer.id():
                select_index = i
        self.combo_layers.setCurrentIndex(select_index)
        self._populate_fields()

    def _populate_fields(self):
        self.list_fields.clear()
        layer = self.combo_layers.currentData()
        if layer is None:
            return

        for field in layer.fields():
            if _type_id(field) in NUMERIC_TYPES:
                label = f"{field.name()}  ({field.typeName()}"
                if _type_id(field) == DOUBLE_TYPE:
                    label += f", {field.precision()} décimale(s) actuellement"
                label += ")"
                item = QListWidgetItem(label)
                item.setData(Qt.ItemDataRole.UserRole, field.name())
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Unchecked)
                self.list_fields.addItem(item)

        if self.list_fields.count() == 0:
            item = QListWidgetItem("Aucun champ numérique trouvé dans cette couche")
            item.setFlags(Qt.ItemFlag.NoItemFlags)
            self.list_fields.addItem(item)

    def _set_all_checked(self, checked):
        state = Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked
        for i in range(self.list_fields.count()):
            item = self.list_fields.item(i)
            if item.flags() & Qt.ItemFlag.ItemIsUserCheckable:
                item.setCheckState(state)

    def _get_selected_fields(self):
        names = []
        for i in range(self.list_fields.count()):
            item = self.list_fields.item(i)
            if (item.flags() & Qt.ItemFlag.ItemIsUserCheckable) and item.checkState() == Qt.CheckState.Checked:
                names.append(item.data(Qt.ItemDataRole.UserRole))
        return names

    @contextmanager
    def _processing(self, message="Traitement en cours…"):
        """Affiche un indicateur de traitement en cours (curseur occupé + libellé
        dans la fenêtre + boutons désactivés) pendant toute la durée du bloc,
        même si celui-ci se termine par un `return` anticipé."""
        self.status_label.setText(message)
        self.btn_apply.setEnabled(False)
        self.btn_close.setEnabled(False)
        QApplication.setOverrideCursor(QCursor(Qt.CursorShape.WaitCursor))
        QApplication.processEvents()
        try:
            yield
        finally:
            QApplication.restoreOverrideCursor()
            self.status_label.setText("")
            self.btn_apply.setEnabled(True)
            self.btn_close.setEnabled(True)
            QApplication.processEvents()

    def _progress_dialog(self, label_text, maximum):
        """Barre de progression modale avec bouton Annuler, pour les boucles sur
        les entités (potentiellement longues sur de grosses couches)."""
        progress = QProgressDialog(label_text, "Annuler", 0, maximum, self)
        progress.setWindowTitle("Traitement en cours")
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.setMinimumDuration(0)
        progress.setValue(0)
        progress.show()
        QApplication.processEvents()
        return progress

    def _make_temp_field_name(self, layer, base_name):
        """Génère un nom de champ temporaire unique, compatible avec la limite
        de 10 caractères des Shapefiles (par précaution, quel que soit le format)."""
        base = base_name[:7] if len(base_name) > 7 else base_name
        candidate = (base + "_r")[:10]
        n = 1
        while layer.fields().indexOf(candidate) != -1:
            suffix = f"_r{n}"
            candidate = (base[: max(1, 10 - len(suffix))] + suffix)[:10]
            n += 1
        return candidate

    def _restructure_field(self, layer, old_name, decimals, only_selected, errors):
        """Recrée le champ `old_name` avec la précision `decimals`, en conservant
        au final son nom d'origine.

        Contrairement aux tentatives précédentes, on n'utilise PAS la session
        d'édition tamponnée (`layer.addAttribute()` / `startEditing()` /
        `commitChanges()`) pour les changements de STRUCTURE : c'est cette
        API qui se montrait peu fiable. On suit à la place le modèle officiel
        du cookbook PyQGIS, qui appelle directement le fournisseur de données
        (`layer.dataProvider().addAttributes()` / `.deleteAttributes()` /
        `.renameAttributes()`), sans passer par une session d'édition — ces
        appels s'appliquent immédiatement, sans possibilité de rollBack().

        Séquence, en 3 étapes indépendantes :
          A) créer un champ temporaire + y écrire les valeurs arrondies
          B) supprimer l'ancien champ
          C) renommer le champ temporaire vers le nom d'origine
        Si une étape échoue, les précédentes restent acquises : au pire, les
        valeurs arrondies restent disponibles sous le nom temporaire.

        Retourne le nombre de valeurs copiées, ou None en cas d'échec total
        (un message détaillé est alors ajouté à `errors`)."""
        provider = layer.dataProvider()

        if layer.isEditable():
            errors.append(
                f"{old_name} : la couche a des modifications en attente — "
                f"enregistrez-les ou annulez-les dans QGIS avant de recréer ce champ."
            )
            return None

        old_idx = layer.fields().indexOf(old_name)
        if old_idx == -1:
            errors.append(f"{old_name} : champ introuvable.")
            return None

        old_field = layer.fields().field(old_idx)
        length = old_field.length()
        if not length or length < decimals + 2:
            length = decimals + 12

        # Lire et arrondir TOUTES les valeurs avant de toucher au schéma
        to_write = []
        total = layer.selectedFeatureCount() if only_selected else layer.featureCount()
        progress = self._progress_dialog(f"Lecture des valeurs de « {old_name} »…", total)
        features = layer.getSelectedFeatures() if only_selected else layer.getFeatures()
        cancelled = False
        for i, feature in enumerate(features, start=1):
            if i % 500 == 0 or i == total:
                progress.setValue(i)
                QApplication.processEvents()
                if progress.wasCanceled():
                    cancelled = True
                    break
            value = feature[old_name]
            if value is None or value == NULL:
                continue
            try:
                rounded = round(float(value), decimals)
            except (TypeError, ValueError):
                continue
            to_write.append((feature.id(), rounded))
        progress.setValue(total)
        progress.close()

        if cancelled:
            errors.append(f"{old_name} : opération annulée pendant la lecture des valeurs.")
            return None

        temp_name = self._make_temp_field_name(layer, old_name)

        # --- ÉTAPE A : créer le champ temporaire directement sur le fournisseur
        self.status_label.setText(f"Création du champ temporaire « {temp_name} »…")
        QApplication.processEvents()
        if not provider.addAttributes([QgsField(temp_name, _DOUBLE_FIELD, "double", length, decimals)]):
            errors.append(
                f"{old_name} : le fournisseur a refusé la création du champ "
                f"temporaire '{temp_name}'."
            )
            return None
        layer.updateFields()

        temp_idx = layer.fields().indexOf(temp_name)
        if temp_idx == -1:
            errors.append(f"{old_name} : champ temporaire '{temp_name}' introuvable après création.")
            return None

        # Écrire les valeurs arrondies directement sur le fournisseur (un seul
        # appel groupé, comme recommandé pour les modifications en masse).
        self.status_label.setText(f"Écriture des valeurs arrondies dans « {temp_name} »…")
        QApplication.processEvents()
        count_values = 0
        if to_write:
            changes = {fid: {temp_idx: rounded} for fid, rounded in to_write}
            if provider.changeAttributeValues(changes):
                count_values = len(to_write)
            else:
                layer.updateFields()
                errors.append(
                    f"{old_name} : champ temporaire '{temp_name}' créé, mais "
                    f"échec de l'écriture des valeurs arrondies."
                )
                return 0

        # --- ÉTAPE B : supprimer l'ancien champ directement sur le fournisseur
        self.status_label.setText(f"Suppression de l'ancien champ « {old_name} »…")
        QApplication.processEvents()
        old_idx_now = layer.fields().indexOf(old_name)
        if old_idx_now == -1 or not provider.deleteAttributes([old_idx_now]):
            layer.updateFields()
            errors.append(
                f"{old_name} : valeurs arrondies disponibles dans '{temp_name}', mais "
                f"impossible de supprimer l'ancien champ '{old_name}'. Vous avez "
                f"donc temporairement les deux champs."
            )
            return count_values
        layer.updateFields()

        # --- ÉTAPE C : renommer le champ temporaire vers le nom d'origine
        self.status_label.setText(f"Renommage de « {temp_name} » en « {old_name} »…")
        QApplication.processEvents()
        temp_idx_now = layer.fields().indexOf(temp_name)
        if temp_idx_now == -1 or not provider.renameAttributes({temp_idx_now: old_name}):
            layer.updateFields()
            errors.append(
                f"{old_name} : valeurs arrondies disponibles dans le champ '{temp_name}' "
                f"(le renommage en '{old_name}' n'a pas fonctionné — non supporté par ce "
                f"fournisseur. Vous pouvez le renommer manuellement dans les propriétés "
                f"de la couche)."
            )
            return count_values
        layer.updateFields()

        return count_values

    def _refresh_attribute_table(self, layer):
        """Si la table attributaire de cette couche est déjà ouverte, on la referme
        et on la rouvre pour forcer un rafraîchissement complet (colonnes ET valeurs).
        Un simple repaint ne suffit pas toujours après un ajout/suppression/
        renommage de champ."""
        try:
            for dlg in self.iface.mainWindow().findChildren(QDialog):
                if dlg.__class__.__name__ != "QgsAttributeTableDialog":
                    continue
                get_layer = getattr(dlg, "layer", None)
                if get_layer is None:
                    continue
                try:
                    dlg_layer = get_layer()
                except TypeError:
                    continue
                if dlg_layer is not None and dlg_layer.id() == layer.id():
                    was_visible = dlg.isVisible()
                    geometry = dlg.geometry()
                    dlg.close()
                    if was_visible:
                        new_dlg = self.iface.showAttributeTable(layer)
                        if new_dlg is not None:
                            new_dlg.setGeometry(geometry)
        except Exception:
            # Le rafraîchissement de la table attributaire est un confort,
            # pas une étape critique : on ne bloque jamais dessus.
            pass

    def _refresh_identify_results(self):
        """Ferme la fenêtre/panneau « Résultats d'identification » si elle est
        ouverte. Contrairement à la table attributaire, ce panneau affiche un
        instantané figé des attributs au moment du clic et ne propose aucune
        API publique pour le rafraîchir ; le fermer évite au moins qu'il
        continue d'afficher des valeurs devenues obsolètes (un nouveau clic
        d'identification réaffichera les valeurs à jour)."""
        try:
            for w in self.iface.mainWindow().findChildren(QDialog):
                if w.__class__.__name__ == "QgsIdentifyResultsDialog" and w.isVisible():
                    w.close()
        except Exception:
            # Confort uniquement : on ne bloque jamais dessus.
            pass

    # ------------------------------------------------------------------
    # Traitement principal
    # ------------------------------------------------------------------
    def apply_rounding(self):
        with self._processing("Application des arrondis en cours…"):
            self._apply_rounding_impl()

    def _apply_rounding_impl(self):
        layer = self.combo_layers.currentData()
        if layer is None:
            QMessageBox.warning(self, "Aucune couche", "Veuillez choisir une couche vecteur valide.")
            return

        field_names = self._get_selected_fields()
        if not field_names:
            QMessageBox.warning(
                self, "Aucun champ", "Veuillez cocher au moins un champ numérique."
            )
            return

        decimals = self.spin_decimals.value()
        self._last_processed_fields = list(field_names)

        # --- Vérifications préalables --------------------------------
        provider = layer.dataProvider()
        caps = provider.capabilities() if provider else 0
        if not (caps & _CAP.ChangeAttributeValues):
            QMessageBox.critical(
                self,
                "Non supporté",
                "Le format de cette couche ne permet pas la modification des attributs "
                "(fournisseur de données en lecture seule ou non éditable).",
            )
            return

        field_indices = {name: layer.fields().indexOf(name) for name in field_names}
        field_indices = {n: i for n, i in field_indices.items() if i != -1}
        if not field_indices:
            QMessageBox.warning(
                self, "Champs introuvables", "Les champs sélectionnés sont introuvables sur cette couche."
            )
            return

        only_selected = (
            self.check_only_selected_features.isChecked()
            and layer.selectedFeatureCount() > 0
        )

        # --- Classement des champs : faut-il recréer le champ pour changer
        # sa précision déclarée (ex: Shapefile), ou suffit-il d'arrondir les
        # valeurs (précision déjà correcte, ou champ entier) ? -------------
        fields_needing_restructure = []
        fields_value_only = []
        for name, idx in field_indices.items():
            field = layer.fields().field(idx)
            if _type_id(field) == DOUBLE_TYPE and field.precision() != decimals:
                fields_needing_restructure.append(name)
            else:
                fields_value_only.append(name)

        struct_caps = (
            _CAP.AddAttributes
            | _CAP.DeleteAttributes
            | _CAP.RenameAttributes
        )
        can_restructure = (caps & struct_caps) == struct_caps

        restructure_unavailable_warning = False
        if fields_needing_restructure and not can_restructure:
            # On ne peut pas changer la précision déclarée sur ce format/fournisseur :
            # on se rabat sur un arrondi de la valeur uniquement (l'affichage pourra
            # rester inchangé si les décimales excédentaires étaient déjà à zéro).
            fields_value_only.extend(fields_needing_restructure)
            fields_needing_restructure = []
            restructure_unavailable_warning = True

        # --- Phase 1 : champs nécessitant une restructuration (précision figée) --
        # Traités en dehors de toute session d'édition partagée : chaque appel
        # gère ses propres commits (voir _restructure_field), donc ces champs
        # sont enregistrés sur le disque immédiatement, avant même de passer
        # à la phase 2.
        errors = []
        total_values_changed = 0
        restructured_fields = []
        partial_restructure_fields = []
        failed_restructure_fields = []

        for name in fields_needing_restructure:
            errors_before = len(errors)
            count = self._restructure_field(layer, name, decimals, only_selected, errors)
            had_issue = len(errors) > errors_before
            if count is None:
                failed_restructure_fields.append(name)
            elif had_issue:
                total_values_changed += count
                partial_restructure_fields.append(name)
            else:
                total_values_changed += count
                restructured_fields.append(name)

        # --- Phase 2 : champs pour lesquels on arrondit simplement les valeurs,
        # dans une session d'édition classique laissée en attente pour le
        # commit automatique en fin de phase. ------------------------------
        was_editable = layer.isEditable()
        count_features = 0

        if fields_value_only:
            if not was_editable:
                if not layer.startEditing():
                    self._show_apply_result(
                        total_values_changed, restructured_fields, partial_restructure_fields,
                        failed_restructure_fields, errors,
                        restructure_unavailable_warning, layer,
                        extra_error="Impossible de démarrer l'édition pour arrondir "
                                    "les valeurs des autres champs (couche verrouillée "
                                    "ou fournisseur non éditable).",
                    )
                    return

            layer.beginEditCommand("Arrondir champs numériques")
            try:
                value_field_indices = {
                    n: layer.fields().indexOf(n) for n in fields_value_only
                }
                value_field_indices = {
                    n: i for n, i in value_field_indices.items() if i != -1
                }
                to_update = []
                total = layer.selectedFeatureCount() if only_selected else layer.featureCount()
                progress = self._progress_dialog("Lecture et arrondi des valeurs…", total)
                features = (
                    layer.getSelectedFeatures() if only_selected else layer.getFeatures()
                )
                cancelled = False
                for feature in features:
                    count_features += 1
                    if count_features % 500 == 0 or count_features == total:
                        progress.setValue(count_features)
                        QApplication.processEvents()
                        if progress.wasCanceled():
                            cancelled = True
                            break
                    for name, idx in value_field_indices.items():
                        value = feature[name]
                        if value is None or value == NULL:
                            continue
                        try:
                            rounded = round(float(value), decimals)
                        except (TypeError, ValueError):
                            continue
                        if rounded != value:
                            to_update.append((feature.id(), idx, rounded))
                progress.setValue(total)
                progress.close()

                if cancelled:
                    layer.endEditCommand()
                    if not was_editable:
                        layer.rollBack()
                    self._show_apply_result(
                        total_values_changed, restructured_fields, partial_restructure_fields,
                        failed_restructure_fields, errors,
                        restructure_unavailable_warning, layer,
                        extra_error="Arrondi des valeurs annulé par l'utilisateur "
                                    "(les champs déjà recréés ci-dessus, eux, restent acquis).",
                    )
                    return

                for fid, idx, rounded in to_update:
                    if layer.changeAttributeValue(fid, idx, rounded):
                        total_values_changed += 1
            except Exception as e:
                layer.endEditCommand()
                layer.rollBack()
                self._show_apply_result(
                    total_values_changed, restructured_fields, partial_restructure_fields,
                    failed_restructure_fields, errors,
                    restructure_unavailable_warning, layer,
                    extra_error=f"Erreur pendant l'arrondi des valeurs : {e}",
                )
                return
            layer.endEditCommand()

            # Enregistrement automatique, uniquement si l'édition a été démarrée
            # par le plugin (sinon on laisse la session de l'utilisateur intacte).
            if not was_editable:
                if not layer.commitChanges():
                    commit_errors = "\n".join(layer.commitErrors())
                    layer.rollBack()
                    self._show_apply_result(
                        total_values_changed, restructured_fields, partial_restructure_fields,
                        failed_restructure_fields, errors,
                        restructure_unavailable_warning, layer,
                        extra_error=f"Échec de l'enregistrement des valeurs arrondies :\n{commit_errors}",
                    )
                    return

        self._show_apply_result(
            total_values_changed, restructured_fields, partial_restructure_fields,
            failed_restructure_fields, errors,
            restructure_unavailable_warning, layer,
        )

    def _show_apply_result(
        self, total_values_changed, restructured_fields, partial_restructure_fields,
        failed_restructure_fields, errors, restructure_unavailable_warning, layer,
        extra_error=None,
    ):
        if (
            total_values_changed == 0
            and not restructured_fields
            and not partial_restructure_fields
            and not failed_restructure_fields
            and not extra_error
        ):
            QMessageBox.information(
                self,
                "Rien à faire",
                "Aucune valeur ne nécessitait d'arrondi (déjà arrondies, ou champs vides).",
            )
            return

        layer.triggerRepaint()
        self.iface.mapCanvas().refresh()
        self._refresh_attribute_table(layer)
        self._refresh_identify_results()

        msg_parts = []
        if restructured_fields:
            msg_parts.append(
                "Champ(s) recréé(s) sous le même nom avec la précision "
                "demandée et enregistré(s) sur le disque (ils peuvent "
                "apparaître en fin de table attributaire) : "
                + ", ".join(restructured_fields) + "."
            )
        if partial_restructure_fields:
            msg_parts.append(
                "Champ(s) partiellement traité(s) (valeurs arrondies enregistrées, "
                "mais voir le détail ci-dessous) : "
                + ", ".join(partial_restructure_fields) + "."
            )
        msg_parts.append(
            f"{total_values_changed} valeur(s) arrondie(s) au total."
        )
        if failed_restructure_fields:
            msg_parts.append(
                "Échec de la recréation pour : " + ", ".join(failed_restructure_fields) + "."
            )
        if restructure_unavailable_warning:
            msg_parts.append(
                "Ce format ne permet pas de changer le nombre de décimales "
                "déclaré d'un champ : seules les valeurs ont été arrondies, "
                "l'affichage peut donc rester inchangé si les décimales "
                "excédentaires étaient déjà nulles."
            )
        if errors:
            msg_parts.append("Détails :\n- " + "\n- ".join(errors))
        if extra_error:
            msg_parts.append(extra_error)
        if layer.isEditable():
            msg_parts.append(
                "La couche était déjà en cours d'édition : les modifications "
                "restent en attente, enregistrez-les depuis QGIS."
            )

        icon = (
            QMessageBox.warning
            if (failed_restructure_fields or partial_restructure_fields or extra_error)
            else QMessageBox.information
        )
        icon(self, "Résultat", "\n\n".join(msg_parts))

    def show_result(self):
        """Ouvre la table attributaire de la couche sélectionnée, triée sur le
        dernier champ traité (s'il y en a un), pour vérifier facilement le
        résultat de l'arrondi."""
        layer = self.combo_layers.currentData()
        if layer is None:
            QMessageBox.warning(self, "Aucune couche", "Veuillez choisir une couche vecteur valide.")
            return

        # Ne garder que les champs traités qui existent encore réellement sur
        # la couche (un champ recréé peut avoir changé de position, mais son
        # nom reste valide ; par précaution on vérifie quand même).
        valid_fields = [
            name for name in self._last_processed_fields
            if layer.fields().indexOf(name) != -1
        ]

        if valid_fields:
            try:
                config = layer.attributeTableConfig()
                config.setSortExpression(f'"{valid_fields[-1]}"')
                layer.setAttributeTableConfig(config)
            except Exception:
                # Le tri est un confort, pas une étape critique.
                pass

        self.iface.showAttributeTable(layer)
