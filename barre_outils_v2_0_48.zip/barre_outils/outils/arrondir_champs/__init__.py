# -*- coding: utf-8 -*-
def classFactory(iface):
    from .arrondir_champs import ArrondirChampsPlugin
    return ArrondirChampsPlugin(iface)
