# -*- coding: utf-8 -*-
import os.path

try:
    from qgis.PyQt.QtWidgets import QAction
except ImportError:  # Qt6
    from qgis.PyQt.QtGui import QAction
from qgis.PyQt.QtGui import QIcon


class ArrondirChampsPlugin:
    """Plugin QGIS : arrondir les valeurs de champs numériques sélectionnés."""

    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None
        self.menu = "&Arrondir Champs"
        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(
            icon, "Arrondir champs numériques...", self.iface.mainWindow()
        )
        self.action.setWhatsThis(
            "Sélectionner des champs numériques et les arrondir"
        )
        self.action.setStatusTip("Arrondir un ou plusieurs champs numériques")
        self.action.triggered.connect(self.run)

        # Ajout dans le menu Extensions et dans la barre d'outils
        self.iface.addPluginToMenu(self.menu, self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        self.iface.removePluginMenu(self.menu, self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        # Import différé pour ne charger le dialogue qu'à l'utilisation
        from .arrondir_champs_dialog import ArrondirChampsDialog

        self.dialog = ArrondirChampsDialog(self.iface, self.iface.mainWindow())
        self.dialog.show()
        self.dialog.exec()
