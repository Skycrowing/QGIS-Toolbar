import os
try:
    from qgis.PyQt.QtGui import QAction, QIcon
except ImportError:
    from qgis.PyQt.QtGui import QIcon
    from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtXml import QDomDocument
from qgis.core import (QgsProject, QgsMapLayer, QgsFeatureRenderer, QgsReadWriteContext,
                       QgsMarkerSymbol, QgsLineSymbol, QgsVectorLayer)

from .panneau import Panneau

SCOPE = "ToujoursAffiche"
P_ACTIF = "toujours_afficher/actif"
P_ECHELLE = "toujours_afficher/echelle_active"
P_RENDU = "toujours_afficher/rendu_origine"
MENU = "Toujours affiché"


def vrai(v):
    return str(v).lower() in ("true", "1")


class ToujoursAffiche:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.panneau = None

    # ---------- interface ----------
    def initGui(self):
        fen = self.iface.mainWindow()
        self.panneau = Panneau(fen)
        self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.panneau)
        self.panneau.hide()

        self.action = QAction(QIcon(os.path.join(os.path.dirname(__file__), "icon.svg")),
                              "Toujours affiché", fen)
        self.action.setCheckable(True)
        self.panneau.setToggleVisibilityAction(self.action)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(MENU, self.action)

        p = self.panneau
        p.liste.itemChanged.connect(self.case_changee)
        p.btn_tout.clicked.connect(lambda: self.tout(True))
        p.btn_rien.clicked.connect(lambda: self.tout(False))
        p.chk_taille.toggled.connect(self.taille_changee)
        p.spin.valueChanged.connect(self.taille_changee)

        prj = QgsProject.instance()
        for s in (prj.readProject, prj.cleared, prj.layersAdded, prj.layersRemoved):
            s.connect(self.actualiser)
        self.actualiser()

    def unload(self):
        prj = QgsProject.instance()
        for s in (prj.readProject, prj.cleared, prj.layersAdded, prj.layersRemoved):
            try:
                s.disconnect(self.actualiser)
            except TypeError:
                pass
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu(MENU, self.action)
        self.iface.removeDockWidget(self.panneau)
        self.panneau.deleteLater()
        self.action = self.panneau = None

    def actualiser(self, *args):
        prj = QgsProject.instance()
        self.panneau.remplir(prj.mapLayers().values(), lambda c: vrai(c.customProperty(P_ACTIF, False)))
        self.panneau.regler_taille(prj.readBoolEntry(SCOPE, "taille_active", False)[0],
                                   prj.readDoubleEntry(SCOPE, "taille", 3.0)[0])

    # ---------- événements ----------
    def case_changee(self, item):
        couche = QgsProject.instance().mapLayer(item.data(Qt.ItemDataRole.UserRole))
        if couche is None:
            return
        if item.checkState() == Qt.CheckState.Checked:
            self.activer(couche)
        else:
            self.restaurer(couche)
        self.rafraichir([couche])

    def tout(self, etat):
        liste = self.panneau.liste
        cible = Qt.CheckState.Checked if etat else Qt.CheckState.Unchecked
        for i in range(liste.count()):
            liste.item(i).setCheckState(cible)  # déclenche case_changee

    def taille_changee(self, *args):
        prj = QgsProject.instance()
        prj.writeEntryBool(SCOPE, "taille_active", self.panneau.chk_taille.isChecked())
        prj.writeEntryDouble(SCOPE, "taille", self.panneau.spin.value())
        actives = [c for c in prj.mapLayers().values() if vrai(c.customProperty(P_ACTIF, False))]
        for c in actives:
            self.restaurer_rendu(c)
            self.appliquer_taille(c)
        self.rafraichir(actives)

    # ---------- logique ----------
    def activer(self, couche):
        couche.setCustomProperty(P_ACTIF, True)
        if couche.hasScaleBasedVisibility():
            couche.setCustomProperty(P_ECHELLE, True)
            couche.setScaleBasedVisibility(False)
        self.appliquer_taille(couche)

    def restaurer(self, couche):
        couche.removeCustomProperty(P_ACTIF)
        if vrai(couche.customProperty(P_ECHELLE, False)):
            couche.setScaleBasedVisibility(True)
            couche.removeCustomProperty(P_ECHELLE)
        self.restaurer_rendu(couche)

    def appliquer_taille(self, couche):
        if not self.panneau.chk_taille.isChecked():
            return
        if not isinstance(couche, QgsVectorLayer) or not couche.renderer():
            return
        if not couche.customProperty(P_RENDU, None):
            doc = QDomDocument()
            doc.appendChild(couche.renderer().save(doc, QgsReadWriteContext()))
            couche.setCustomProperty(P_RENDU, doc.toString())
        taille = self.panneau.spin.value()
        rendu = couche.renderer().clone()
        for item in rendu.legendSymbolItems():
            if item.symbol() is None:
                continue
            sym = item.symbol().clone()
            if isinstance(sym, QgsMarkerSymbol):
                sym.setSize(taille)
            elif isinstance(sym, QgsLineSymbol):
                sym.setWidth(taille)
            else:
                continue
            rendu.setLegendSymbolItem(item.ruleKey(), sym)
        couche.setRenderer(rendu)

    @staticmethod
    def restaurer_rendu(couche):
        xml = couche.customProperty(P_RENDU, None)
        if not xml:
            return
        doc = QDomDocument()
        doc.setContent(xml)
        rendu = QgsFeatureRenderer.load(doc.documentElement(), QgsReadWriteContext())
        if rendu:
            couche.setRenderer(rendu)
        couche.removeCustomProperty(P_RENDU)

    def rafraichir(self, couches):
        for c in couches:
            c.triggerRepaint()
            self.iface.layerTreeView().refreshLayerSymbology(c.id())
        self.iface.mapCanvas().refresh()
