def classFactory(iface):
    from .plugin import ToujoursAffiche
    return ToujoursAffiche(iface)
