from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
                                 QLabel, QCheckBox, QDoubleSpinBox, QPushButton)
from qgis.gui import QgsDockWidget


class Panneau(QgsDockWidget):
    """Fenêtre ancrable : liste de couches à cocher + taille."""

    def __init__(self, parent=None):
        super().__init__("Toujours affiché", parent)
        self.setObjectName("ToujoursAffichePanneau")
        w = QWidget()
        lay = QVBoxLayout(w)

        lay.addWidget(QLabel("Couches toujours affichées :"))
        self.liste = QListWidget()
        lay.addWidget(self.liste)

        b = QHBoxLayout()
        self.btn_tout = QPushButton("Tout cocher")
        self.btn_rien = QPushButton("Tout décocher")
        b.addWidget(self.btn_tout); b.addWidget(self.btn_rien); b.addStretch()
        lay.addLayout(b)

        t = QHBoxLayout()
        self.chk_taille = QCheckBox("Taille des symboles :")
        self.spin = QDoubleSpinBox()
        self.spin.setRange(0.1, 100); self.spin.setDecimals(1); self.spin.setSingleStep(0.5)
        self.spin.setSuffix(" mm"); self.spin.setKeyboardTracking(False)
        self.chk_taille.toggled.connect(self.spin.setEnabled)
        t.addWidget(self.chk_taille); t.addWidget(self.spin); t.addStretch()
        lay.addLayout(t)
        note = QLabel("<i>Points : diamètre · Lignes : épaisseur.<br>"
                      "Décocher une couche restaure ses échelles et sa symbologie.</i>")
        note.setWordWrap(True)
        lay.addWidget(note)
        self.setWidget(w)

    def remplir(self, couches, est_active):
        self.liste.blockSignals(True)
        self.liste.clear()
        for c in sorted(couches, key=lambda c: c.name().lower()):
            it = QListWidgetItem(c.name())
            it.setData(Qt.ItemDataRole.UserRole, c.id())
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked if est_active(c) else Qt.CheckState.Unchecked)
            self.liste.addItem(it)
        self.liste.blockSignals(False)

    def regler_taille(self, active, valeur):
        for w in (self.chk_taille, self.spin):
            w.blockSignals(True)
        self.chk_taille.setChecked(active)
        self.spin.setValue(valeur)
        self.spin.setEnabled(active)
        for w in (self.chk_taille, self.spin):
            w.blockSignals(False)
